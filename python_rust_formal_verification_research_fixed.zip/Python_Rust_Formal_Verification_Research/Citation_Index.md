# Citation index

A normalized index of links actually cited in the saved final report. See [Sources.md](Sources.md) for full titles and excerpts.

- [S04: Apex Verify — Formal verification for AI-generated code | Hyperion AI](https://hyperion-ai.com/products/apex#:~:text=Apex%20Turns%20your%20intent%20into,statements%20and%20routes%20each%20function)
- [S05: Formal verification — Deal documentation](https://deal.readthedocs.io/basic/verification.html#:~:text=Deal%20has%20a%20built,work%2C%20it%20finds%20actual%20bugs)
- [S13: Introduction — crosshair 0.0.112 documentation](https://crosshair.readthedocs.io/en/latest/introduction.html#:~:text=CrossHair%20works%20by%20repeatedly%20calling,sets%2C%20and%20custom%20mutable%20objects)
- [S19: GitHub - agentic-prover/aprover: AProver: Agentic Prover for AI-Generated Code — LLM agents + BMC for automated verification of systems software · GitHub](https://github.com/agentic-prover/aprover#:~:text=AProver%3A%20Agentic%20Prover%20for%20AI,automated%20verification%20of%20systems%20software)
- [S20: Neuro-Formal Verification: Agentic Language-Agnostic Formal Program Reasoning](https://arxiv.org/html/2608.21516v2#:~:text=We%20introduce%20neuro,precision)
- [S22: Introducing AutoProver: Agentic Formal Verification for Every Developer](https://www.certora.com/blog/autoprover-agentic-formal-verification#:~:text=For%20the%20past%20seven%20years%2C,art%20formal%20methods)
- [S23: Axiom Zero: AlphaZero-Style Reinforcement Learning for Automated Formal Verification of Python Programs](https://apartresearch.com/sprints/projects/axiom-zero-alphazerostyle-reinforcement-learning-for-automated-formal-verification-of-python-programs-aqr7#:~:text=behaves%20as%20intended,143%20unit%20tests%20pass%20across)
- [S24: Prusti – Programming Methodology Group | ETH Zurich](https://www.pm.inf.ethz.ch/research/prusti.html#:~:text=Prusti%20is%20an%20automated%20program,and%20verification%20of%20Rust%20programs)
- [S32: GitHub - model-checking/kani: A model checker for Rust programs. · GitHub](https://github.com/model-checking/kani#:~:text=More%20items)
