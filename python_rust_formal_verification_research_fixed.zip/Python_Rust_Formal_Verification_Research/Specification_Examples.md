# Specification Examples

*Conceptual illustration:*  
- **Python Contract (Deal):**  
  ```python
  @deal.pre(lambda x: x >= 0)
  @deal.post(lambda res, x: res >= x)
  def increment(x: int) -> int:
      return x + 1
  ```  
  Running `deal prove` will formally verify that `increment(x)` satisfies `res >= x` for all integer `x >= 0`[【5†L13-L21】](https://deal.readthedocs.io/basic/verification.html#:~:text=Deal%20has%20a%20built,work%2C%20it%20finds%20actual%20bugs).  
- **Concurrency (TLA+ via Apex):** One could write a TLA+ spec of a Python async function’s guarantees (e.g. “requests are atomic”). Apex uses TLA+ under the hood to check thread interleavings[【4†L119-L127】](https://hyperion-ai.com/products/apex#:~:text=Tests%20almost%20never%20catch%20a,write%20in%20a%20worker%20thread).  
- **Rust Proof Harness (Kani):**  
  ```rust
  #[kani::proof]
  fn check_property() {
      let x: i32 = kani::any();
      let y = some_rust_function(x);
      assert!(y == expected_result(x));
  }
  ```  
  Kani will attempt to prove the assertion for all inputs (subject to bounds)[【32†L285-L294】](https://github.com/model-checking/kani#:~:text=use%20my_crate%3A%3A).  

These illustrate how input-output relations and invariants serve as specs in code.
