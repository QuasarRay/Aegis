# Python and Rust Formal Verification — Recovered Deep Research

> **Recovery provenance:** This ZIP was reconstructed from the saved Deep Research report rather than retrieved as a previously generated ZIP. The research app did not create the requested ZIP: its packaging step remained pending. These chapters are the sections actually present in the saved report, with citation markers linked to their saved URLs. This is **not** the comprehensive, many-tool, deeply researched artifact originally requested.

See [Recovery_Notes.md](Recovery_Notes.md), [Sources.md](Sources.md), and [Original_Report.md](Original_Report.md).

## Recovered chapters

- [Overview](README.md)
- [Tool Inventory](Tools_Overview.md)
- [Tool Comparison](Tools_Comparison.md)
- [Python Tool Profiles](Python_Tools.md)
- [Rust/Multi-Language Profiles](Rust_Tools.md)
- [Agentic Pipelines](Agentic_Pipelines.md)
- [Aegis Integration](Aegis_Integration.md)
- [Specification Examples](Specification_Examples.md)
- [Limitations and Conclusion](Limitations_Conclusion.md)
- [Sources and citation metadata](Sources.md)
- [Original report, unmodified text](Original_Report.md)
- [Recovery notes and limitations](Recovery_Notes.md)

## Original overview

This deep research evaluates Python formal-verification tools against Aegis’s criteria: agentic/MCP integration, specification-driven development, high automation, multi-language (Python+Rust) support, and fit with Aegis. We surveyed academic papers, open-source projects, and industry tools. Key examples include Hyperion’s *Apex* (Lean4/TLA+ proofs with an agentic pipeline) and AI-assisted pipelines (e.g. Certora’s AutoProver)[【4†L105-L113】](https://hyperion-ai.com/products/apex#:~:text=Apex%20Turns%20your%20intent%20into,statements%20and%20routes%20each%20function)[【22†L26-L35】](https://www.certora.com/blog/autoprover-agentic-formal-verification#:~:text=For%20the%20past%20seven%20years%2C,art%20formal%20methods). The report is organized into sections (each as a Markdown file in the ZIP): an inventory of tools, a ranked comparison, detailed profiles, integration guidance, specification examples, limitations, and references.
