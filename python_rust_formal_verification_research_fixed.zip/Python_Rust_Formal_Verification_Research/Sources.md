# Sources recovered from the saved research report

These are **sources cited by the research report**, not independently revalidated during this archive recovery. Original source titles and URLs come from its saved citation metadata.

## S04. Apex Verify — Formal verification for AI-generated code | Hyperion AI

- URL: https://hyperion-ai.com/products/apex
- Citation location(s) in original source: 105–113, 119–127, 132–140, 201–209, 205–213
- Saved excerpt: Apex Turns your intent into formal statements and routes each function

## S05. Formal verification — Deal documentation

- URL: https://deal.readthedocs.io/basic/verification.html
- Citation location(s) in original source: 13–21, 26–34
- Saved excerpt: Deal has a built-in formal verifier. That means deal turns your code into a formal theorem and then proves that it is formally correct (or finds a counter- example when it is not). Turning wild Python code into mathematical expressions is hard, so application of the verifier is limited. Still, you should try it. It will work for only 1% of your code but when it does work, it finds actual bugs.

## S13. Introduction — crosshair 0.0.112 documentation

- URL: https://crosshair.readthedocs.io/en/latest/introduction.html
- Citation location(s) in original source: 17–23
- Saved excerpt: CrossHair works by repeatedly calling your functions with symbolic inputs. It uses an SMT solver (a kind of theorem prover) to explore viable execution paths and find counterexamples for you. This is not a new idea; an approach for Python was first described in this paper. However, to my knowledge, CrossHair is the most complete implementation of the idea: it supports symbolic lists, dictionaries, sets, and custom mutable objects.

## S19. GitHub - agentic-prover/aprover: AProver: Agentic Prover for AI-Generated Code — LLM agents + BMC for automated verification of systems software · GitHub

- URL: https://github.com/agentic-prover/aprover
- Citation location(s) in original source: 134–142
- Saved excerpt: AProver: Agentic Prover for AI-Generated Code — LLM agents + BMC for automated verification of systems software

## S20. Neuro-Formal Verification: Agentic Language-Agnostic Formal Program Reasoning

- URL: https://arxiv.org/html/2608.21516v2
- Citation location(s) in original source: 82–90
- Saved excerpt: We introduce neuro-formal verification (NFV), which harnesses that automation for developers of mainstream programming languages: an AI coding agent translates, an established verifier decides, and a question posed in a mainstream language is answered push-button, at empirical accuracy rather than soundness, with a machine-checked proof. Results on a dataset of correct and incorrect solutions to Python programming problems are encouraging compared to an llm-as-judge baseline: NFV returns a Dafny proof of correctness or of a bug on 57% of the entries at 92% precision, and a CBMC counterexample for 63% of the buggy programs at 90% precision.

## S22. Introducing AutoProver: Agentic Formal Verification for Every Developer

- URL: https://www.certora.com/blog/autoprover-agentic-formal-verification
- Citation location(s) in original source: 26–35, 74–84
- Saved excerpt: For the past seven years, Certora has helped secure some of the most critical protocols in DeFi through manual audits and formal verification. Today, we're bringing that experience into AutoProver: a system that reads your code and documentation, generates formal specifications and tests, and formally verifies your software using state-of-the-art formal methods.

## S23. Axiom Zero: AlphaZero-Style Reinforcement Learning for Automated Formal Verification of Python Programs

- URL: https://apartresearch.com/sprints/projects/axiom-zero-alphazerostyle-reinforcement-learning-for-automated-formal-verification-of-python-programs-aqr7
- Citation location(s) in original source: 63–72
- Saved excerpt: behaves as intended. We present Axiom Zero, a compiler and reinforcement learning system that translates Python/PyTorch source code into formal proofs verified by the Lean 4 proof assistant, using an AlphaZero-style agent to discover those proofs automatically without human-labelled examples. The system comprises four implemented phases: (1) a parse pipeline that converts Python source into a normalized intermediate representation with type and tensor-shape analysis; (2) a proof environment modelling theorem proving as a two-player game with 39 curated tactics across 10 categories; (3) a policy-plus-value network with MCTS tree search trained via self-play; and (4) a Python-to-Lean 4 compiler with difficulty-stratified proof-hole filling. All 143 unit tests pass across

## S24. Prusti – Programming Methodology Group | ETH Zurich

- URL: https://www.pm.inf.ethz.ch/research/prusti.html
- Citation location(s) in original source: 14–18, 28–34
- Saved excerpt: Prusti is an automated program verifier for Rust, based on the Viper infrastructure. It leverages Rust's strong type guarantees to simplify the specification and verification of Rust programs.

## S32. GitHub - model-checking/kani: A model checker for Rust programs. · GitHub

- URL: https://github.com/model-checking/kani
- Citation location(s) in original source: 255–260, 258–268, 285–294
- Saved excerpt: More items

