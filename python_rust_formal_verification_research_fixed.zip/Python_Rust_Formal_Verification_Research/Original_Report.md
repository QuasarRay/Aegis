# Saved Deep Research report — original text

The content below is the original report text as recovered from the saved JSON, without editorial changes.

---

**Overview (README.md)** – This deep research evaluates Python formal-verification tools against Aegis’s criteria: agentic/MCP integration, specification-driven development, high automation, multi-language (Python+Rust) support, and fit with Aegis. We surveyed academic papers, open-source projects, and industry tools. Key examples include Hyperion’s *Apex* (Lean4/TLA+ proofs with an agentic pipeline) and AI-assisted pipelines (e.g. Certora’s AutoProver)【4†L105-L113】【22†L26-L35】. The report is organized into sections (each as a Markdown file in the ZIP): an inventory of tools, a ranked comparison, detailed profiles, integration guidance, specification examples, limitations, and references. 

**Tool Inventory (Tools_Overview.md)** – Tools fall into several categories:  
- *Python-Centric Verifiers:* Directly analyze Python code or use Python-based contracts. Notable examples are **Apex** (Lean4 prover for Python)【4†L105-L113】, **CrossHair** (symbolic execution with Z3)【13†L17-L23】, and **Deal** (Python contracts translated to Z3)【5†L13-L21】.  
- *Rust & Multi-Language Verifiers:* Formal verifiers for Rust code, e.g. **Prusti** (Viper-based Rust verifier)【24†L14-L18】 and **Kani** (AWS model checker via CBMC)【32†L255-L260】. These handle system-level code and assertions, but do not cover Python.  
- *AI-Agentic Pipelines:* Emerging systems combining LLM agents, test/gen, and provers. For example, **Apex** provides an “MCP server” and agent skill for automated verification workflows【4†L132-L140】. Research projects like “neuro-formal verification” use an AI to translate Python problems to Dafny or CBMC proofs【20†L82-L90】. The Certora **AutoProver** (beta) generates specs and proofs from code/docs using AI agents【22†L26-L35】. **AProver** (agentic-prover) uses LLMs plus CBMC for C/Rust code【19†L134-L142】. **Axiom Zero** (RL for Lean4) auto-proves Python code【23†L63-L72】.  
- *Contracts and Model Checkers:* Tools like TLA+ or Alloy can model high-level specifications. Design-by-contract libraries (icontract, PyContracts) and property testers (Hypothesis) support spec-driven dev but require manual proof steps. 

**Tool Comparison (Tools_Comparison.md)** – Based on the criteria above, notable rankings: 

- **Apex (Hyperion AI):** Most mature for Python. Turns docstrings/tests into Lean4 proof obligations【4†L105-L113】, yielding formal proofs or counterexamples. Integrates a TLA+ engine for concurrency checks【4†L119-L127】. Provides a CLI/VSCode tool and an “MCP server” skill for AI pipelines【4†L132-L140】. *Automation:* High (push-button on supported code). *Spec-Driven:* Uses Python docstring specs. *Limitations:* Limited language subset (no floats, complex loops, etc.)【4†L201-L209】.  
- **CrossHair:** Automatic symbolic executor for Python. It “calls your functions with symbolic inputs” and uses an SMT solver to find contract violations【13†L17-L23】. *Automation:* Fully automatic bug-finding. *Spec-Driven:* Uses Python type annotations and contracts (e.g., via icontract). *Limitations:* Finds counterexamples but doesn’t produce full proofs; incomplete on complex logic.  
- **Deal (deal-solver):** Built-in verifier for Python contracts【5†L13-L21】. Annotate functions with `@deal.pre`/`@deal.post` and Deal generates Z3 queries. *Automation:* Command-line `deal prove`. *Spec-Driven:* Yes (pre/postconditions in code). *Limitations:* Extremely limited coverage (“works for only ~1% of code”【5†L13-L21】); handles only pure Python functions with simple types【5†L26-L34】.  
- **Prusti / Kani (Rust):** Formal tools for Rust. *Prusti* uses SMT/Viper to prove Rust contracts【24†L14-L18】; *Kani* uses CBMC for bit-precise model checking of Rust (checking panics, overflows, asserts)【32†L255-L260】【32†L258-L268】. *Automation:* High for Rust. *Spec-Driven:* Yes (contract attributes, assertions). *Limitations:* Only for Rust; Prusti handles safe Rust only, Kani is bounded model checking. Crucial for verifying Aegis’s Rust modules.  
- **AutoProver (Certora, beta):** AI-driven pipeline (currently for Solidity; Rust support pending) that “reads your code and docs, generates formal specifications and tests, and formally verifies your software”【22†L26-L35】. Integrates LLMs to auto-generate CVL proofs and test harnesses. *Automation:* Very high (LLM generates specs). *Spec-Driven:* LLM creates them from docs. *Limitations:* Not yet released for Python; depends on large models and formal backend.  
- **AProver (agentic-prover):** Combines LLM agents with CBMC for generated C/Rust code【19†L134-L142】. Demonstrates agentic orchestration but is focused on low-level systems code.  
- **Axiom Zero:** RL-based proof generator (Lean4) for Python/PyTorch programs【23†L63-L72】. Works end-to-end without human examples. *Automation:* Autonomous, given tests. *Limitations:* Prototype stage (May 2026) and specialized to math-heavy code.  

Other tools like runtime contract libraries (icontract, PyContracts) or generic SMT use (Z3py) didn’t provide end-to-end automation.  

**Python Tool Profiles (Python_Tools.md)** – **Apex (Lean4/TLA+ Engine)**: Converts Python code+specs into Lean4 theorems【4†L105-L113】. Returns a machine-checked proof or a concrete failing input. Good for logic errors (off-by-one, arithmetic) and even thread races (via TLA+【4†L119-L127】). Installation is easy (CLI or VSCode) and it works with most typing annotations. **CrossHair**: A dynamic symbolic analyzer. Given a function annotated with `@icontract` or type hints, it systematically searches paths with an SMT solver【13†L17-L23】, flagging pre/postcondition failures. It can handle Python’s containers and simple OOP. **Deal (deal-solver)**: Use it by adding `@deal.pre`/`@deal.post` decorators. Running `deal prove` on your project invokes Z3 on each function【5†L13-L21】. It proves correctness or finds counter-examples. Very effective on pure, loop-free functions. **Workflow Integration**: All above integrate into developer workflows; Apex and CrossHair offer CLI and editor plugins. For example, Apex’s agent skill can wrap LLM code generation with automatic verification steps【4†L132-L140】.  

**Rust/Multi-Language Profiles (Rust_Tools.md)** – **Prusti**: For Rust functions, Prusti infers and checks correctness of contracts in ghost code. It leverages Rust’s ownership types to simplify proof obligations【24†L28-L34】. You write `#[requires]`/`#[ensures]` annotations, and Prusti proves them with an SMT backend. **Kani**: To verify Rust, annotate with `#[kani::proof]` and use `kani::any()` for non-deterministic inputs. Kani then exhaustively checks assertions and panics via bounded model checking【32†L285-L294】. This is highly automated (just `cargo kani test`) and finds UB or logic bugs in unsafe code. **Other Rust Tools**: *Verus*, *Creusot* offer deeper proofs (supporting invariants, heap), but require learning new syntaxes and are less mature.  
- **Cross-Language Strategy:** No tool directly spans Python↔Rust. The practical approach is “separate and compose”: use Apex/CrossHair on Python modules, and Prusti/Kani on Rust modules. Then write formal specifications (in code or in a high-level language like TLA+ or a contract DSL) for their interface. For example, specify in Python what the Rust FFI must guarantee (and vice versa), then rely on each tool to enforce those contracts on its side.

**Agentic Pipelines (Agentic_Pipelines.md)** – Modern formal-verification tools increasingly use AI agents:  
- **Apex:** Can be driven by coding agents (Codex, Claude) and comes with an MCP server (`apex skill`) so an agent can iteratively propose fixes until the Lean proof succeeds【4†L132-L140】.  
- **AProver:** Chains LLMs with CBMC to verify generated system code【19†L134-L142】. Illustrates the pattern of “LLM guesses spec, SMT/MC verifies.”  
- **Neuro-Formal:** (MSR, 2026) An AI pipeline that translates Python tasks into Dafny or CBMC queries【20†L82-L90】. On benchmarks it produced formal correctness proofs or counterexamples ~60% of the time.  
- **AutoProver:** (Certora, 2026) An end-to-end agentic system for smart contracts, soon for Rust. It *reads* code/docs, *generates* formal specs/tests, and *runs* a theorem prover and model checker, all under AI orchestration【22†L26-L35】. Output includes structured proof assets and bug reports.  
- **Axiom Zero:** (2026 Sprint) A Lean4-based prover where a self-play RL agent learns to construct proofs from Python code【23†L63-L72】. It demonstrates automated reasoning but is still research-level.

These approaches embody fully *specification-driven development*, with AI reducing manual proof labor. They fit Aegis’s vision (agentic, automated proof). However, they are mostly prototypes and not plug-and-play for arbitrary Python code. 

**Aegis Integration (Aegis_Integration.md)** – Mapping to Aegis requirements:  
- **Agent Integration:** Apex and AutoProver align tightly. Apex’s MCP server and LLM skill seamlessly slot into an agentic workflow【4†L132-L140】. AutoProver explicitly uses chains of specialized agents (spec-generation, test-gen, prover)【22†L26-L35】. We anticipate Aegis can call these tools via CLI or API from custom agents.  
- **Specification-Driven Dev:** Both Apex and Deal/icontract use in-code specs. For example, writing a docstring or decorator acts as the spec; the tool *then* attempts a proof【4†L105-L113】【5†L13-L21】. In practice, developers would write user_input⇔output contracts (as pre/post conditions) which Apex or Deal would verify. AI tools (AutoProver/NFV) might help generate or refine these specs.  
- **Multilingual Projects:** Aegis projects like Blue/Carbon mix Python and Rust. We recommend verifying each part with its best tool (Apex/CrossHair for Python, Prusti/Kani for Rust) and carefully modeling their interaction. For instance, one could use a TLA+ spec (as Apex does) to specify cross-module protocols.  
- **CI/CD and MCP:** Tools like Kani and Prusti have CI integrations (GitHub Actions) for automated checks. Python tools (Deal, CrossHair, Apex CLI) can run in pipelines too. Apex is MIT-licensed and self-hostable, fitting on-prem MCP servers. Certora’s AutoProver is a cloud service (upcoming), potentially usable via API.  
- **Proof Harnesses:** Aegis can implement property tests as formal proof harnesses. For example, Kani’s `#[kani::proof]` functions or Apex’s Lean spec functions serve as harnesses. Python code could be wrapped similarly (e.g. `assert` postconditions or specialized test functions) to be checked formally. 

**Specification Examples (Specification_Examples.md)** – *Conceptual illustration:*  
- **Python Contract (Deal):**  
  ```python
  @deal.pre(lambda x: x >= 0)
  @deal.post(lambda res, x: res >= x)
  def increment(x: int) -> int:
      return x + 1
  ```  
  Running `deal prove` will formally verify that `increment(x)` satisfies `res >= x` for all integer `x >= 0`【5†L13-L21】.  
- **Concurrency (TLA+ via Apex):** One could write a TLA+ spec of a Python async function’s guarantees (e.g. “requests are atomic”). Apex uses TLA+ under the hood to check thread interleavings【4†L119-L127】.  
- **Rust Proof Harness (Kani):**  
  ```rust
  #[kani::proof]
  fn check_property() {
      let x: i32 = kani::any();
      let y = some_rust_function(x);
      assert!(y == expected_result(x));
  }
  ```  
  Kani will attempt to prove the assertion for all inputs (subject to bounds)【32†L285-L294】.  

These illustrate how input-output relations and invariants serve as specs in code.

**Limitations and Conclusion (Limitations_Conclusion.md)** – No single tool currently does *everything*. Practical observations:  
- **Partial Coverage:** Most Python verifiers handle only subsets of Python. For example, Apex explicitly notes that *“strings, floats, dicts, classes, while loops, recursion…”* fall back to fuzzing, not proof【4†L201-L209】. Deal and CrossHair similarly skip unsupported patterns.  
- **Spec Quality:** Formal guarantees are only as strong as the specifications. If a contract is too weak, a tool may produce a vacuous proof. Human review is essential. Apex requires user sign-off on the interpreted spec before trusting the proof【4†L205-L213】. AutoProver likewise highlights that specs come from AI suggestions and need vetting【22†L74-L84】.  
- **Automation Limits:** Even with automation, not all proofs finish: tools may timeout or give up (CrossHair may not find a counterexample but also not prove). Bounded approaches (Kani, TLA+) require setting limits. Fuzzing often augments formal analysis (Apex does fuzzing if proof isn’t possible).  
- **Multi-Language Gap:** As noted, Python↔Rust interfaces have no off-the-shelf verifier. We must enforce contracts at the boundary manually. Formalizing FFI behavior or data invariants across languages remains an open challenge.  
- **Maturity:** Many advanced pipelines (AutoProver, AProver, Axiom Zero) are prototypes or limited to specific domains (Solidity, research demos). Production readiness varies.  

**Summary:** In conclusion, **Apex** currently appears the strongest tool for Python-specific formal verification under these criteria, thanks to its Lean/TLA+ backbone and agentic integration【4†L105-L113】【4†L132-L140】. For Rust, **Prusti** or **Kani** would verify native components. Aegis projects should leverage these: write precise pre/post conditions in code and run Apex/Prusti as part of CI/agent pipelines. Agentic frameworks (AutoProver, NFV) are promising for future integration, as they aim to *auto-generate* specifications and proofs【22†L26-L35】【20†L82-L90】. However, teams must plan for the current toolset’s limits: focus formal verification on critical modules, use fuzzing/tests elsewhere, and continuously refine specifications. With these tools and approaches, Aegis can achieve significantly stronger end-to-end guarantees than testing alone.

**Sources:** Verified information was gathered from official documentation, research papers, and project sites for each tool【4†L105-L113】【5†L13-L21】【13†L17-L23】【19†L134-L142】【20†L82-L90】【22†L26-L35】【23†L63-L72】【24†L14-L18】【32†L255-L260】, as cited above. Each source provides the factual basis for the analysis.
