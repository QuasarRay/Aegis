# 08 — Implementation roadmap, acceptance and rollback

This plan deliberately avoids replacing the Aegis control plane all at once. Every stage must have a small, independent acceptance and a rollback path. No phase starts by changing an active Blue/Destiny Goal's rules.

| Phase | Engineering scope | Acceptance | Rollback |
|---|---|---|---|
| 0 — Governance baseline | Snapshot Aegis, current laws and Blue source contract | Existing Aegis release checks pass; drift-free baseline | Return to pinned Aegis release |
| 1 — Skill packaging | Reviewed `SKILL.md`, metadata, lockfile, no whole-book prompt | Skill discovered; tool-use trace; immutable governance maintained | Uninstall/revert skill artifact |
| 2 — Source-preserving ingestion | Copy originals, hash, parse, offsets | Source bytes verified; malformed math/code detected and labeled | Remove only generated index |
| 3 — Read-only MCP | `search_exact`, `read_span`, `read_adjacent`, manifest | Retrieval passes fixed source queries; no filesystem writes | Disable MCP in provider config |
| 4 — Context economics | FTS5/Tantivy, bounded snippets, receipts | Measured token reduction vs direct reference reads, no reduction in recall | Remove budget route |
| 5 — Independent inventory | Clang/Python/Go/Java/Rust extractors | Required configuration identities enumerated; explicit unknowns | Keep previous inventory and failure receipts |
| 6 — Mapping gate | Canonical target group, method ownership, graph relations | Missing/merged objects produce deterministic failure | Disable integration only for read-only pilot; don't waive production invariant |
| 7 — Kani-from-tests | Source-test parser, traceable bounded harnesses | Every assumption/assertion maps to original tests; Kani results scoped | Revert generated harnesses |
| 8 — Optional semantic search | Qdrant, Haystack/reranker or alternative | Demonstrated higher recall on fixed benchmark, acceptable operations cost | Return to lexical-only |
| 9 — Provider adapters | Native documented Goal/Plan operations, effective model observations | Capability truth verified in actual Codex session | Restore prior adapter |
| 10 — Architecture documentation | CPGSchema, 42010 viewpoints | Only post-verification; source link traceability | Regenerate from pinned graph |

## Stage 1 minimal deliverables

1. `skills.lock.json` with content digests and license/source references.
2. One `book-reference-search` skill containing only a workflow.
3. Immutable corpus snapshots for two sources (one programming book and one official API manual).
4. MCP server with only safe read operations.
5. Corpus extraction/index manifest and 20–50 *retrieval* validation questions, independently reviewed.
6. Aegis evidence records showing skill invoked and source snippets actually returned.

## Stage 5 minimal deliverables

- C++ Clang compile database and configuration matrix.
- Python test/source AST inventories with duplicates/shadowing.
- Rust target semantic inventory including macro expansion.
- Canonical per-object mapping; reject many-to-one without an explicit distinct source identity for every target group.
- Source snapshot/hash audit and missing-obligation report.

## No premature success

Separate denominators:
- source-file coverage;
- exact source declaration coverage;
- canonical target-group coverage;
- original-test result coverage;
- Kani generated-harness *traceability* and *proven bounded obligations*;
- package/runtime integration coverage.

Never replace one with another. Six passing original tests do not imply full Blue source equivalence, even if the current reported six are useful milestones.

## Acceptance management

The Aegis constitution currently requires test-first/property-first cycles. The user asks that application Kani harnesses originate only from existing source tests and that new behavior not be invented. Evaluate whether independent framework verification can be added while application behavioral tests remain unchanged. If not, obtain an explicit governance design decision; do not weaken Aegis hard gates or silently overrule original-test-only source contracts.
