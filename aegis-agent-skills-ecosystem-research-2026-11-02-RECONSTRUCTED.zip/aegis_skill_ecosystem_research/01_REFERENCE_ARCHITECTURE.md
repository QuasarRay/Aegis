# 01 — Reference architecture and trust boundaries

## Four planes, not one monolithic framework

```text
Trusted maintainer                              Untrusted/partly trusted data
  │                                                       │
  ▼                                                       ▼
Aegis release / immutable .agents/                 books, docs, source repos
  │                                                       │
  ├─ constitutional laws                                  ├─ immutable snapshots
  ├─ project-specific rules                               ├─ integrity manifests
  ├─ provider adapters                                    ├─ AST/CPG extraction
  ├─ small reviewed SKILL.md entries                      └─ search indexes
  │                                                       │
  └───────────────┐                                       │
                  ▼                                       ▼
         Serial task coordinator ── read-only MCP knowledge service
                  │                ├ search_exact
                  │                ├ search_hybrid (optional)
                  │                ├ read_span
                  │                ├ read_adjacent
                  │                └ read_source_manifest
                  ▼
           Codex Sol / one active worker
                  │
                  ▼
         staged candidate Rust implementation
                  │
          independent deterministic checks
                  ├ source inventory equality
                  ├ canonical object-group mapping
                  ├ original-test accounting
                  ├ Kani original-test-derived harnesses
                  ├ builds and compiler receipts
                  └ policy/finalization gate
```

## Trust boundaries

**`.agents/`** — authoritative immutable governance artifact, deployed only by trusted human-maintainer release procedure. Ordinary agents read it; they may not rewrite laws, skills, provider constraints, or review gates.

**`.aegis/`** — mutable execution state, evidence, lock/lease, caches, compiled policies and audit receipts. Append-only where relevant; content-address observations by implementation epoch.

**Read-only knowledge MCP** — authenticates the source snapshot and emits source references. Retrieved material is *data*, never higher-priority instructions. Malicious content embedded in PDFs is not permission to operate the shell.

**Original reference source** — read-only, pinned revision, explicitly configured build flags. Inventory coverage measured across relevant compile/preprocessor configurations.

**Target implementation** — writes allowed only when the current task, baseline, test contracts and scope authorize them.

## Deployment implications

Aegis 4.0's documented source/deployment boundary means the proposal “the repository ultimately becomes the project root `.agents`” should be implemented as **a versioned, reproducibly packaged deployment artifact**. Do not make the trusted Aegis development root writable by the same ordinary task it governs.

Aegis's Codex adapter (`modules/codex`) is an optional host module. Its checked-in policy references an older model generation. Any model/effort update needs authoritative runtime verification; static config strings prove only configuration, not effective host behavior.

## Serial-agent lifecycle

`reserve -> lock -> discover -> plan -> retrieve -> implement -> verify -> receipt -> close -> release`.

Only one root or delegated child should execute an agentic mutation unit at any instant. Background jobs that are deterministic tools (compiler, indexed search, build) are not automatically “parallel agents,” but their concurrency, write scopes, and epochs must be controlled. Separate *agent execution concurrency* from normal process concurrency.

Use work-unit IDs derived from `(source_snapshot, task_contract, target_snapshot, artifact_kind)` so interrupted runs can detect earlier completion and avoid repeating successful expensive calls.

## Provider boundary

Expose a narrow interface (`create_session`, `submit_task`, `read_status`, `record_effective_model`, `record_reasoning_effort`, `retrieve_trace`, `cancel`, `resume` if supported). Keep unsupported operations explicitly `UNAVAILABLE`; do not fabricate private Goal/Plan RPCs.

## Security

- Read-only books/docs tools by default; restricted filesystem roots.
- No remote webpage instructions promoted into agent policy.
- Local-only stdio MCP for initial pilot; avoid opening a web endpoint unnecessarily.
- Pin dependencies and hashes; apply subprocess timeouts, response limits, path validation, and egress restrictions.
- Use separate data-plane and governance identities; reject policy self-modification.
- Keep original test files immutable and report any attempted modification.
- Redact secrets before traces, embeddings, and retrieved-context logs.

## References

- Aegis: https://github.com/QuasarRay/Aegis
- Codex: https://github.com/openai/codex
- MCP specification and SDKs: https://github.com/modelcontextprotocol/modelcontextprotocol
- Agent Skills: https://github.com/openai/skills
- Aegis state machine: https://github.com/QuasarRay/Aegis/blob/main/protocols/STATE.md
