# Aegis agent-skills ecosystem — recovered research bundle

**Research subject:** Aegis governance, Codex, Agent Skills, MCP, book-backed knowledge, context engineering, single-agent workflows, one-to-one Rust migrations, and Kani.

**Snapshot:** 2026-11-02. **Bundle status:** RECONSTRUCTED REPLACEMENT (not the byte-for-byte original Deep Research ZIP).

## Important recovery disclosure

The Deep Research completion message named an archive and an 11-file numbered report set, but the archive and individual Markdown files were **not present in this session's working files**. The Deep Research narrative *was* available. This collection reconstructs the deliverable using that narrative, the original 12-point project requirements, and additional GitHub metadata retrieved during the recovery operation. It **does not claim** to reproduce unpublished text in the original ZIP. Its checksum will differ from the original reported checksum.

The 161-entry atlas uses live GitHub repository metadata for **85 entries** checked on 2026-11-02. The remaining entries are **candidate references with unverified star counts and/or repository status**, not invented star data. Readiness and assurance labels are *engineering assessments*, not audited certifications.

## Contents

- `00_EXECUTIVE_SUMMARY.md` — decisions and Aegis fit.
- `01_REFERENCE_ARCHITECTURE.md` — source of authority, boundaries and components.
- `02_PROJECT_CATALOG.md` — full 161-project index organized by niche and star tier.
- `03_SKILLS_AND_CODEX.md` — skill representation, Codex/provider integration, progressive disclosure.
- `04_MCP_AND_PROVIDER_ADAPTERS.md` — MCP design, permissioning and adapters.
- `05_CONTEXT_MEMORY_AND_RAG.md` — lossless book-corpus architecture and retrieval.
- `06_ORCHESTRATION_ASSURANCE_AND_COST.md` — sequential workflows, evidence and cost.
- `07_ONE_TO_ONE_RUST_MIGRATION.md` — deterministic inventory, canonical groups and Kani.
- `08_IMPLEMENTATION_ROADMAP.md` — ordered development plan and acceptance criteria.
- `09_RISK_REGISTER.md` — supervision risks, threat model, rollback and policy conflicts.
- `10_SOURCES.md` — primary references and repository URL directory.
- `projects.csv`, `projects.json` — machine-readable project catalog.
- `SHA256SUMS.txt` — checksums for each file (excludes itself).

## How to use

Begin with the executive summary and roadmap; browse the catalog by niche and verified star tier. Treat all recommendations as candidates subject to version pinning, license review, a small integration pilot, and independent acceptance evidence.

The biggest implementation recommendation is **not** a new model or a full-framework rewrite. It is a source-preserving read-only skills/MCP knowledge service, plus deterministic one-to-one correspondence checks layered into Aegis's existing state/evidence infrastructure.

### Key original project requirements preserved

1. Cross-language-to-Rust migration with low token waste.
2. Aegis as reusable `.agents` governance payload.
3. No discarded output and no duplicate work.
4. One active agent/subagent globally; **no parallel agents**.
5. Kani/Bolero harnesses derived **only from original tests** for user-visible domain contracts in the initial phase.
6. Pervasive CGP orientation in produced Rust architecture.
7. Strict canonical one-to-one object identity, hierarchy, relationships, methods, naming.
8. CPGSchema/ISO/IEC/IEEE 42010 documentation *after* verified implementation.
9. Book-backed agent skills with zero loss of stored authoritative source information.
10. Max reasoning as configured and verifiable, to the extent supported by the provider.
11. Integration with supported Codex Goal and Plan interfaces, without inventing unsupported APIs.
12. Modularize Aegis; evaluate LangGraph, LangChain and Unpythonic without prematurely rewriting its control plane.
