# 04 — MCP servers and provider adapters

## Recommended initial MCP design

Use an established, version-pinned official MCP SDK or FastMCP. The first service can run **locally over stdio**, accept only read operations, and expose a small static tool vocabulary:

| Tool | Input | Output |
|---|---|---|
| `knowledge.search_exact` | query, corpus IDs, version, max hits | ranked stable span IDs |
| `knowledge.read_span` | corpus ID, source digest, span ID, limit | exact passage + location + digest |
| `knowledge.read_adjacent` | span ID, before/after | neighboring spans and links |
| `knowledge.find_symbol` | language, qualified symbol, version | ranked references and canonical source IDs |
| `knowledge.manifest` | corpus ID | edition/version/hash/license/path info |
| `migration.lookup_mapping` | source ID | declared Rust object group or unresolved status |
| `migration.report_missing` | source and target graph hashes | deterministic missing/duplicate correspondence lists |

Tool responses must be bounded, schema-validated, and provenance-rich. All APIs should support explicit `NOT_FOUND`, `AMBIGUOUS`, `STALE_SOURCE`, `BLOCKED` and `UNVERIFIED` states.

### Avoid early design traps

- Do not provide a general unrestricted shell tool to a document server.
- Do not give retrieval services write access to `.agents/`.
- Do not use embeddings as the sole lookup mechanism for exact symbols and mathematical notation.
- Do not silently fetch “latest” documentation; pin book edition/commit tag and disclose version.
- Do not let the MCP server invent application acceptance criteria.
- Do not use an MCP “tool success” boolean as proof that the Codex host actually used the returned context.

## Language options

| Implementation | Advantage | Project examples |
|---|---|---|
| Python | Fastest adaptation of Aegis stdlib/control-plane implementation | `modelcontextprotocol/python-sdk`, `PrefectHQ/fastmcp` |
| Rust | Static safety and shared ecosystem with final migrated systems | `modelcontextprotocol/rust-sdk`, `rust-mcp-stack/rust-mcp-sdk` |
| TypeScript | Mature tooling around Codex/skills/web clients | `modelcontextprotocol/typescript-sdk` |
| Go | Simple deployment and concurrency primitives | `modelcontextprotocol/go-sdk`, `mark3labs/mcp-go` |
| Java / C# / Kotlin / Swift | Enterprise platform interoperability | official MCP SDK organization projects; verify their current support |

Production readiness depends on SDK protocol revision compatibility, not repository star count. Run protocol conformance tests before deploying an unfamiliar server framework.

## Provider adapter contracts

Provider adapter should implement only documented operations. Suggested data schema:

```json
{
  "provider": "codex",
  "capabilities": {
    "skills": "supported",
    "mcp_stdio": "supported",
    "goal_plugin_rpc": "unverified",
    "plan_plugin_rpc": "unverified",
    "reasoning_max": "model-dependent",
    "parallel_subagents": "forbidden-by-aegis"
  },
  "active_agent_limit": 1
}
```

Aegis should gate `reasoning_max` on effective host observation when available, otherwise report capability uncertainty. Claims about private Codex Goal/Plan endpoints require direct evidence.

## Security and reliability checklist

- Least privilege; explicitly allowed filesystem roots; read-only by default.
- Transport isolation and authentication if moving beyond local stdio.
- Tool name allowlist; prevent dynamic tool schemas without review.
- Timeouts, retries for idempotent reads, size limits, maximum recursion depth.
- Protect from prompt injection: book text and tool responses are untrusted content.
- Exact audit receipts: tool name, input hash, source digest, output hash, worker ID and task epoch.
- Single-agent execution lease remains above every provider; a provider cannot override Aegis's serial execution policy.
- Version-pin SDKs and validate protocol handshake at startup.

## Project references

- https://github.com/modelcontextprotocol/modelcontextprotocol
- https://github.com/modelcontextprotocol/servers
- https://github.com/modelcontextprotocol/python-sdk
- https://github.com/modelcontextprotocol/rust-sdk
- https://github.com/modelcontextprotocol/typescript-sdk
- https://github.com/modelcontextprotocol/go-sdk
- https://github.com/PrefectHQ/fastmcp
- https://github.com/mark3labs/mcp-go
- https://github.com/rust-mcp-stack/rust-mcp-sdk

Note: an MCP skills-extension proposal has appeared in the MCP repository; verify its adoption and protocol status before making it a hard production dependency.
