# 10 — Source index, primary references, and evidence limitations

**Snapshot date:** 2026-11-02.

## Provenance of this recovery

The original Deep Research report narrative was visible in the research widget. Its named ZIP and numbered Markdown attachments were not present in `/mnt/data`, and no matching generated-file record was found by Files search. This replacement was therefore reconstructed rather than extracted byte-for-byte. Original reported ZIP hash (unverified in this session because the archive is missing):

`3392f1ad46172a7b6c4e74de4aa6330ca74f31761a2144c30d968898ecf0d0d5`

**The replacement archive has a different hash and different wording.** Treat it as a usable research recovery, not proof of recovering the lost exact bytes.

## Primary source documents and specifications

- Aegis project: https://github.com/QuasarRay/Aegis
- Aegis README: https://github.com/QuasarRay/Aegis/blob/main/README.md
- Aegis constitution: https://github.com/QuasarRay/Aegis/blob/main/core/00-charter.md
- Aegis policy/README: https://github.com/QuasarRay/Aegis/blob/main/INDEX.md
- Aegis source protocol: https://github.com/QuasarRay/Aegis/blob/main/protocols/STATE.md
- Aegis laws: https://github.com/QuasarRay/Aegis/blob/main/protocols/LAW_TESTS.md
- Aegis Codex adapter: https://github.com/QuasarRay/Aegis/tree/main/modules/codex
- Aegis mutation/TDD workflow: https://github.com/QuasarRay/Aegis/blob/main/core/06-execution-workflow.md
- Aegis test requirements: https://github.com/QuasarRay/Aegis/blob/main/core/08-testing-and-laws.md
- Codex official repository: https://github.com/openai/codex
- Codex skills catalog: https://github.com/openai/skills
- Agent Skills format: https://agentskills.io/
- AGENTS.md convention: https://agents.md/
- Model Context Protocol specification: https://github.com/modelcontextprotocol/modelcontextprotocol
- MCP Python SDK: https://github.com/modelcontextprotocol/python-sdk
- MCP Rust SDK: https://github.com/modelcontextprotocol/rust-sdk
- MCP TypeScript SDK: https://github.com/modelcontextprotocol/typescript-sdk
- MCP Go SDK: https://github.com/modelcontextprotocol/go-sdk
- MCP Skills extension proposal (verify normative status): https://github.com/modelcontextprotocol/modelcontextprotocol/blob/main/docs/seps/2640-skills-extension.mdx
- OpenAI reasoning API guide (version-sensitive): https://developers.openai.com/api/docs/guides/reasoning
- Codex model effort types: https://github.com/openai/codex/blob/main/codex-rs/protocol/src/openai_models.rs
- Codex config source: https://github.com/openai/codex/blob/main/codex-rs/config/src/config_toml.rs
- OpenAI skills tutorial: https://learn.chatgpt.com/docs/build-skills
- Agent plugin/skill concepts: https://developers.openai.com/plugins/concepts/skills
- Aegis target source and current Blue migration: https://github.com/QuasarRay/blue/tree/blue-rs-dev
- Blue migration continuation: https://github.com/QuasarRay/blue/blob/blue-rs-dev/migration/CONTINUATION.md
- Kani reference: https://model-checking.github.io/kani/
- Bolero: https://github.com/bolero-rs/bolero (canonical status and current Kani backend must be verified)
- ISO 42010 landing: https://www.iso.org/standard/50508.html (edition may be superseded; verify current publication)
- Original Unlimiformer research code: https://github.com/abertsch72/unlimiformer
- Unlimiformer paper: https://arxiv.org/abs/2305.01625

## Catalog evidence

For **85** catalog entries, the recovery call used GitHub repository API metadata and captured star count on 2026-11-02. Other fields in the atlas are analytical classification. Many catalog URLs were identified from the prior Deep Research narrative or well-known upstream project names but **were not individually validated**. The CSV `stars_verified` and `status` columns distinguish them.

GitHub stars are volatile. Re-run a metadata crawler if exact current ordering or decision-grade comparisons are required.

## Full GitHub/GitLab project URL index

The following URL directory indexes candidate GitHub repositories. A few paths require independent verification as explicitly stated above; listing does not equal endorsement.

- **Skills / standards / Codex**: [openai/codex](https://github.com/openai/codex) — Native Codex coding agent and configuration; stars: 132,792
- **Skills / standards / Codex**: [openai/skills](https://github.com/openai/skills) — Curated Codex skills and skill authoring; stars: 28,454
- **Skills / standards / Codex**: [anthropics/skills](https://github.com/anthropics/skills) — Agent Skills examples and portable conventions; stars: 186,472
- **Skills / standards / Codex**: [vercel-labs/skills](https://github.com/vercel-labs/skills) — Multi-agent skill installation/management; stars: 37,683
- **Skills / standards / Codex**: [vercel-labs/agent-skills](https://github.com/vercel-labs/agent-skills) — skills / standards / codex; stars: unverified
- **Skills / standards / Codex**: [wshobson/agents](https://github.com/wshobson/agents) — Cross-harness skill and agent source generation; stars: 42,092
- **Skills / standards / Codex**: [agentsmd/agents.md](https://github.com/agentsmd/agents.md) — Repository instruction convention; stars: 25,270
- **Skills / standards / Codex**: [microsoft/skills](https://github.com/microsoft/skills) — skills / standards / codex; stars: unverified
- **Skills / standards / Codex**: [JetBrains/skills](https://github.com/JetBrains/skills) — skills / standards / codex; stars: unverified
- **Skills / standards / Codex**: [skill-one/agents-skills](https://github.com/skill-one/agents-skills) — skills / standards / codex; stars: unverified
- **Skills / standards / Codex**: [cortesi/agentsmd](https://github.com/cortesi/agentsmd) — skills / standards / codex; stars: unverified
- **MCP server infrastructure**: [modelcontextprotocol/modelcontextprotocol](https://github.com/modelcontextprotocol/modelcontextprotocol) — MCP standard and specification; stars: unverified
- **MCP server infrastructure**: [modelcontextprotocol/servers](https://github.com/modelcontextprotocol/servers) — MCP server examples; stars: unverified
- **MCP server infrastructure**: [modelcontextprotocol/python-sdk](https://github.com/modelcontextprotocol/python-sdk) — Official Python MCP SDK; stars: 24,735
- **MCP server infrastructure**: [modelcontextprotocol/typescript-sdk](https://github.com/modelcontextprotocol/typescript-sdk) — Official TypeScript MCP SDK; stars: 13,694
- **MCP server infrastructure**: [modelcontextprotocol/rust-sdk](https://github.com/modelcontextprotocol/rust-sdk) — Official Rust MCP SDK; stars: 4,083
- **MCP server infrastructure**: [modelcontextprotocol/go-sdk](https://github.com/modelcontextprotocol/go-sdk) — Official Go MCP SDK; stars: 5,298
- **MCP server infrastructure**: [modelcontextprotocol/java-sdk](https://github.com/modelcontextprotocol/java-sdk) — mcp server infrastructure; stars: unverified
- **MCP server infrastructure**: [modelcontextprotocol/csharp-sdk](https://github.com/modelcontextprotocol/csharp-sdk) — mcp server infrastructure; stars: unverified
- **MCP server infrastructure**: [modelcontextprotocol/kotlin-sdk](https://github.com/modelcontextprotocol/kotlin-sdk) — mcp server infrastructure; stars: unverified
- **MCP server infrastructure**: [modelcontextprotocol/swift-sdk](https://github.com/modelcontextprotocol/swift-sdk) — mcp server infrastructure; stars: unverified
- **MCP server infrastructure**: [PrefectHQ/fastmcp](https://github.com/PrefectHQ/fastmcp) — Rapid Python MCP development; stars: 28,269
- **MCP server infrastructure**: [mark3labs/mcp-go](https://github.com/mark3labs/mcp-go) — mcp server infrastructure; stars: 9,213
- **MCP server infrastructure**: [rust-mcp-stack/rust-mcp-sdk](https://github.com/rust-mcp-stack/rust-mcp-sdk) — Rust MCP SDK with reported conformance evidence; stars: 199
- **MCP server infrastructure**: [punkpeye/awesome-mcp-servers](https://github.com/punkpeye/awesome-mcp-servers) — mcp server infrastructure; stars: unverified
- **MCP server infrastructure**: [qdrant/mcp-server-qdrant](https://github.com/qdrant/mcp-server-qdrant) — mcp server infrastructure; stars: unverified
- **MCP server infrastructure**: [docling-project/docling-mcp](https://github.com/docling-project/docling-mcp) — mcp server infrastructure; stars: unverified
- **Agent harness / frameworks**: [All-Hands-AI/OpenHands](https://github.com/All-Hands-AI/OpenHands) — agent harness / frameworks; stars: unverified
- **Agent harness / frameworks**: [letta-ai/letta](https://github.com/letta-ai/letta) — agent harness / frameworks; stars: 25,319
- **Agent harness / frameworks**: [letta-ai/letta-code](https://github.com/letta-ai/letta-code) — Stateful coding harness and memory; stars: 3,758
- **Agent harness / frameworks**: [langchain-ai/langgraph](https://github.com/langchain-ai/langgraph) — Stateful graph-driven agent orchestration; stars: 44,308
- **Agent harness / frameworks**: [langchain-ai/langchain](https://github.com/langchain-ai/langchain) — agent harness / frameworks; stars: 148,858
- **Agent harness / frameworks**: [langchain-ai/deepagents](https://github.com/langchain-ai/deepagents) — agent harness / frameworks; stars: unverified
- **Agent harness / frameworks**: [deepset-ai/haystack](https://github.com/deepset-ai/haystack) — Composable retrieval pipelines and skill routing; stars: 26,905
- **Agent harness / frameworks**: [crewAIInc/crewAI](https://github.com/crewAIInc/crewAI) — agent harness / frameworks; stars: 60,403
- **Agent harness / frameworks**: [microsoft/autogen](https://github.com/microsoft/autogen) — agent harness / frameworks; stars: 61,670
- **Agent harness / frameworks**: [microsoft/semantic-kernel](https://github.com/microsoft/semantic-kernel) — agent harness / frameworks; stars: 28,725
- **Agent harness / frameworks**: [microsoft/agent-framework](https://github.com/microsoft/agent-framework) — agent harness / frameworks; stars: unverified
- **Agent harness / frameworks**: [pydantic/pydantic-ai](https://github.com/pydantic/pydantic-ai) — agent harness / frameworks; stars: 20,992
- **Agent harness / frameworks**: [huggingface/smolagents](https://github.com/huggingface/smolagents) — agent harness / frameworks; stars: 30,184
- **Agent harness / frameworks**: [mastra-ai/mastra](https://github.com/mastra-ai/mastra) — agent harness / frameworks; stars: 29,268
- **Agent harness / frameworks**: [langgenius/dify](https://github.com/langgenius/dify) — agent harness / frameworks; stars: 160,193
- **Agent harness / frameworks**: [infiniflow/ragflow](https://github.com/infiniflow/ragflow) — Document-centric RAG and knowledge compilation; stars: 93,325
- **Agent harness / frameworks**: [run-llama/llama_index](https://github.com/run-llama/llama_index) — agent harness / frameworks; stars: 52,779
- **Agent harness / frameworks**: [stanfordnlp/dspy](https://github.com/stanfordnlp/dspy) — agent harness / frameworks; stars: 38,882
- **Agent harness / frameworks**: [BerriAI/litellm](https://github.com/BerriAI/litellm) — agent harness / frameworks; stars: unverified
- **Agent harness / frameworks**: [openai/openai-agents-python](https://github.com/openai/openai-agents-python) — agent harness / frameworks; stars: unverified
- **Agent harness / frameworks**: [google/adk-python](https://github.com/google/adk-python) — agent harness / frameworks; stars: unverified
- **Agent harness / frameworks**: [google-gemini/gemini-cli](https://github.com/google-gemini/gemini-cli) — agent harness / frameworks; stars: unverified
- **Agent harness / frameworks**: [anthropics/claude-code](https://github.com/anthropics/claude-code) — agent harness / frameworks; stars: unverified
- **Agent harness / frameworks**: [Aider-AI/aider](https://github.com/Aider-AI/aider) — agent harness / frameworks; stars: unverified
- **Agent harness / frameworks**: [continuedev/continue](https://github.com/continuedev/continue) — agent harness / frameworks; stars: unverified
- **Agent harness / frameworks**: [sst/opencode](https://github.com/sst/opencode) — agent harness / frameworks; stars: unverified
- **Agent harness / frameworks**: [cline/cline](https://github.com/cline/cline) — agent harness / frameworks; stars: unverified
- **Agent harness / frameworks**: [RooCodeInc/Roo-Code](https://github.com/RooCodeInc/Roo-Code) — agent harness / frameworks; stars: unverified
- **Document ingest / source fidelity**: [docling-project/docling](https://github.com/docling-project/docling) — Structured scholarly-document extraction; stars: 69,980
- **Document ingest / source fidelity**: [VikParuchuri/marker](https://github.com/VikParuchuri/marker) — document ingest / source fidelity; stars: unverified
- **Document ingest / source fidelity**: [opendatalab/MinerU](https://github.com/opendatalab/MinerU) — Scientific PDF and layout parsing; stars: 82,970
- **Document ingest / source fidelity**: [Unstructured-IO/unstructured](https://github.com/Unstructured-IO/unstructured) — document ingest / source fidelity; stars: 15,669
- **Document ingest / source fidelity**: [kermitt2/grobid](https://github.com/kermitt2/grobid) — Scholarly document structural markup; stars: unverified
- **Document ingest / source fidelity**: [apache/tika](https://github.com/apache/tika) — document ingest / source fidelity; stars: 4,121
- **Document ingest / source fidelity**: [jgm/pandoc](https://github.com/jgm/pandoc) — Document format conversion; stars: 46,781
- **Document ingest / source fidelity**: [pymupdf/PyMuPDF](https://github.com/pymupdf/PyMuPDF) — document ingest / source fidelity; stars: unverified
- **Document ingest / source fidelity**: [pypdfium2-team/pypdfium2](https://github.com/pypdfium2-team/pypdfium2) — document ingest / source fidelity; stars: unverified
- **Document ingest / source fidelity**: [docling-project/docling-pipelines](https://github.com/docling-project/docling-pipelines) — document ingest / source fidelity; stars: unverified
- **Document ingest / source fidelity**: [OCRmyPDF/OCRmyPDF](https://github.com/OCRmyPDF/OCRmyPDF) — document ingest / source fidelity; stars: unverified
- **Document ingest / source fidelity**: [facebookresearch/nougat](https://github.com/facebookresearch/nougat) — document ingest / source fidelity; stars: unverified
- **Search / vector / graphs**: [tantivy-search/tantivy](https://github.com/tantivy-search/tantivy) — Rust full-text search/indexing; stars: unverified
- **Search / vector / graphs**: [meilisearch/meilisearch](https://github.com/meilisearch/meilisearch) — Easy operational text search; stars: 59,750
- **Search / vector / graphs**: [typesense/typesense](https://github.com/typesense/typesense) — Operational typo-tolerant text search; stars: 27,075
- **Search / vector / graphs**: [elastic/elasticsearch](https://github.com/elastic/elasticsearch) — search / vector / graphs; stars: unverified
- **Search / vector / graphs**: [opensearch-project/OpenSearch](https://github.com/opensearch-project/OpenSearch) — search / vector / graphs; stars: unverified
- **Search / vector / graphs**: [vespa-engine/vespa](https://github.com/vespa-engine/vespa) — Large-scale hybrid retrieval and ranking; stars: unverified
- **Search / vector / graphs**: [qdrant/qdrant](https://github.com/qdrant/qdrant) — Rust vector and hybrid retrieval; stars: 35,377
- **Search / vector / graphs**: [milvus-io/milvus](https://github.com/milvus-io/milvus) — search / vector / graphs; stars: 46,556
- **Search / vector / graphs**: [weaviate/weaviate](https://github.com/weaviate/weaviate) — search / vector / graphs; stars: 16,934
- **Search / vector / graphs**: [lancedb/lancedb](https://github.com/lancedb/lancedb) — search / vector / graphs; stars: 11,826
- **Search / vector / graphs**: [chroma-core/chroma](https://github.com/chroma-core/chroma) — search / vector / graphs; stars: 29,620
- **Search / vector / graphs**: [pgvector/pgvector](https://github.com/pgvector/pgvector) — PostgreSQL vector indexes; stars: 23,565
- **Search / vector / graphs**: [redis/redis](https://github.com/redis/redis) — search / vector / graphs; stars: unverified
- **Search / vector / graphs**: [facebookresearch/faiss](https://github.com/facebookresearch/faiss) — search / vector / graphs; stars: 41,246
- **Search / vector / graphs**: [microsoft/graphrag](https://github.com/microsoft/graphrag) — Graph-enhanced knowledge retrieval; stars: 36,528
- **Search / vector / graphs**: [HKUDS/LightRAG](https://github.com/HKUDS/LightRAG) — Lightweight graph-based retrieval; stars: 40,475
- **Search / vector / graphs**: [unum-cloud/usearch](https://github.com/unum-cloud/usearch) — search / vector / graphs; stars: unverified
- **Search / vector / graphs**: [Neo4j/neo4j](https://github.com/Neo4j/neo4j) — search / vector / graphs; stars: unverified
- **Search / vector / graphs**: [quickwit-oss/quickwit](https://github.com/quickwit-oss/quickwit) — search / vector / graphs; stars: unverified
- **Persistent agent memory**: [mem0ai/mem0](https://github.com/mem0ai/mem0) — Persistent agent memory; stars: 68,261
- **Persistent agent memory**: [getzep/graphiti](https://github.com/getzep/graphiti) — Temporal knowledge graph memory; stars: 32,426
- **Persistent agent memory**: [getzep/zep](https://github.com/getzep/zep) — persistent agent memory; stars: 4,985
- **Persistent agent memory**: [topoteretes/cognee](https://github.com/topoteretes/cognee) — persistent agent memory; stars: 32,994
- **Persistent agent memory**: [MemTensor/MemOS](https://github.com/MemTensor/MemOS) — persistent agent memory; stars: unverified
- **Persistent agent memory**: [agno-agi/agno](https://github.com/agno-agi/agno) — persistent agent memory; stars: unverified
- **Sequential workflow / recovery**: [temporalio/temporal](https://github.com/temporalio/temporal) — Durable, replayable workflow execution; stars: 24,127
- **Sequential workflow / recovery**: [temporalio/sdk-python](https://github.com/temporalio/sdk-python) — sequential workflow / recovery; stars: unverified
- **Sequential workflow / recovery**: [PrefectHQ/prefect](https://github.com/PrefectHQ/prefect) — Operationally managed Python workflows; stars: 24,106
- **Sequential workflow / recovery**: [dagster-io/dagster](https://github.com/dagster-io/dagster) — sequential workflow / recovery; stars: 16,361
- **Sequential workflow / recovery**: [kestra-io/kestra](https://github.com/kestra-io/kestra) — sequential workflow / recovery; stars: 30,115
- **Sequential workflow / recovery**: [apache/airflow](https://github.com/apache/airflow) — sequential workflow / recovery; stars: 47,345
- **Sequential workflow / recovery**: [windmill-labs/windmill](https://github.com/windmill-labs/windmill) — sequential workflow / recovery; stars: 18,357
- **Sequential workflow / recovery**: [n8n-io/n8n](https://github.com/n8n-io/n8n) — sequential workflow / recovery; stars: 209,325
- **Sequential workflow / recovery**: [hatchet-dev/hatchet](https://github.com/hatchet-dev/hatchet) — sequential workflow / recovery; stars: unverified
- **Sequential workflow / recovery**: [inngest/inngest](https://github.com/inngest/inngest) — sequential workflow / recovery; stars: unverified
- **Sequential workflow / recovery**: [Arize-ai/phoenix](https://github.com/Arize-ai/phoenix) — Open-source LLM observability; stars: 12,096
- **Assurance / policy / evaluation**: [open-policy-agent/opa](https://github.com/open-policy-agent/opa) — Explicit policy-as-code with Rego; stars: 12,419
- **Assurance / policy / evaluation**: [cedar-policy/cedar](https://github.com/cedar-policy/cedar) — Typed authorization policies; stars: 1,831
- **Assurance / policy / evaluation**: [casbin/casbin](https://github.com/casbin/casbin) — RBAC/ABAC policy enforcement; stars: unverified
- **Assurance / policy / evaluation**: [guardrails-ai/guardrails](https://github.com/guardrails-ai/guardrails) — assurance / policy / evaluation; stars: unverified
- **Assurance / policy / evaluation**: [NVIDIA-NeMo/Guardrails](https://github.com/NVIDIA-NeMo/Guardrails) — assurance / policy / evaluation; stars: 7,409
- **Assurance / policy / evaluation**: [promptfoo/promptfoo](https://github.com/promptfoo/promptfoo) — Agent evaluation and adversarial testing; stars: 26,725
- **Assurance / policy / evaluation**: [confident-ai/deepeval](https://github.com/confident-ai/deepeval) — LLM and RAG evaluations; stars: 19,236
- **Assurance / policy / evaluation**: [truera/trulens](https://github.com/truera/trulens) — assurance / policy / evaluation; stars: unverified
- **Assurance / policy / evaluation**: [openai/evals](https://github.com/openai/evals) — assurance / policy / evaluation; stars: unverified
- **Assurance / policy / evaluation**: [UKGovernmentBEIS/inspect_ai](https://github.com/UKGovernmentBEIS/inspect_ai) — Audit-friendly model evaluations; stars: unverified
- **Assurance / policy / evaluation**: [langfuse/langfuse](https://github.com/langfuse/langfuse) — Agent execution tracing and cost tracking; stars: 36,859
- **Assurance / policy / evaluation**: [mlflow/mlflow](https://github.com/mlflow/mlflow) — assurance / policy / evaluation; stars: 28,625
- **Assurance / policy / evaluation**: [open-telemetry/opentelemetry-collector](https://github.com/open-telemetry/opentelemetry-collector) — assurance / policy / evaluation; stars: 7,728
- **Assurance / policy / evaluation**: [grafana/grafana](https://github.com/grafana/grafana) — assurance / policy / evaluation; stars: unverified
- **Assurance / policy / evaluation**: [explodinggradients/ragas](https://github.com/explodinggradients/ragas) — assurance / policy / evaluation; stars: unverified
- **Assurance / policy / evaluation**: [ProtectAI/llm-guard](https://github.com/ProtectAI/llm-guard) — assurance / policy / evaluation; stars: 3,219
- **Assurance / policy / evaluation**: [microsoft/presidio](https://github.com/microsoft/presidio) — assurance / policy / evaluation; stars: unverified
- **Assurance / policy / evaluation**: [invariantlabs-ai/invariant](https://github.com/invariantlabs-ai/invariant) — assurance / policy / evaluation; stars: unverified
- **Assurance / policy / evaluation**: [JaidedAI/EasyOCR](https://github.com/JaidedAI/EasyOCR) — assurance / policy / evaluation; stars: unverified
- **Compiler / CPG / translation**: [llvm/llvm-project](https://github.com/llvm/llvm-project) — Authoritative C/C++ AST and compiler infrastructure; stars: 41,295
- **Compiler / CPG / translation**: [tree-sitter/tree-sitter](https://github.com/tree-sitter/tree-sitter) — Incremental multi-language parsing; stars: 27,354
- **Compiler / CPG / translation**: [joernio/joern](https://github.com/joernio/joern) — Code property graphs; stars: 3,614
- **Compiler / CPG / translation**: [github/codeql](https://github.com/github/codeql) — Semantic code queries and graph analysis; stars: 10,290
- **Compiler / CPG / translation**: [semgrep/semgrep](https://github.com/semgrep/semgrep) — compiler / cpg / translation; stars: 17,401
- **Compiler / CPG / translation**: [rust-lang/rust-analyzer](https://github.com/rust-lang/rust-analyzer) — Rust source semantic analysis; stars: 16,964
- **Compiler / CPG / translation**: [rust-lang/rust](https://github.com/rust-lang/rust) — compiler / cpg / translation; stars: unverified
- **Compiler / CPG / translation**: [immunant/c2rust](https://github.com/immunant/c2rust) — Conservative C-to-Rust transpilation; stars: 4,832
- **Compiler / CPG / translation**: [Cpp2Rust/cpp2rust](https://github.com/Cpp2Rust/cpp2rust) — Research C++-to-Rust migration; stars: 318
- **Compiler / CPG / translation**: [facebookresearch/TransCoder](https://github.com/facebookresearch/TransCoder) — compiler / cpg / translation; stars: 1,728
- **Compiler / CPG / translation**: [python/cpython](https://github.com/python/cpython) — compiler / cpg / translation; stars: unverified
- **Compiler / CPG / translation**: [golang/go](https://github.com/golang/go) — compiler / cpg / translation; stars: unverified
- **Compiler / CPG / translation**: [eclipse-jdt/eclipse.jdt.core](https://github.com/eclipse-jdt/eclipse.jdt.core) — compiler / cpg / translation; stars: unverified
- **Compiler / CPG / translation**: [srcML/srcML](https://github.com/srcML/srcML) — compiler / cpg / translation; stars: unverified
- **Compiler / CPG / translation**: [kastor-io/konveyor-analyzer-lsp](https://github.com/kastor-io/konveyor-analyzer-lsp) — compiler / cpg / translation; stars: unverified
- **Formal verification / Rust**: [model-checking/kani](https://github.com/model-checking/kani) — Rust bounded model checking; stars: 3,627
- **Formal verification / Rust**: [bolero-rs/bolero](https://github.com/bolero-rs/bolero) — Property-testing harnesses and backends; stars: unverified
- **Formal verification / Rust**: [verus-lang/verus](https://github.com/verus-lang/verus) — Deductive Rust verification; stars: 3,536
- **Formal verification / Rust**: [viperproject/prusti-dev](https://github.com/viperproject/prusti-dev) — formal verification / rust; stars: unverified
- **Formal verification / Rust**: [creusot-rs/creusot](https://github.com/creusot-rs/creusot) — Rust deductive verification; stars: 1,951
- **Formal verification / Rust**: [rust-lang/miri](https://github.com/rust-lang/miri) — formal verification / rust; stars: 6,707
- **Formal verification / Rust**: [diffblue/cbmc](https://github.com/diffblue/cbmc) — formal verification / rust; stars: 1,157
- **Formal verification / Rust**: [GaloisInc/crucible](https://github.com/GaloisInc/crucible) — formal verification / rust; stars: 781
- **Formal verification / Rust**: [GaloisInc/crux](https://github.com/GaloisInc/crux) — formal verification / rust; stars: 1
- **Formal verification / Rust**: [GaloisInc/saw-script](https://github.com/GaloisInc/saw-script) — formal verification / rust; stars: unverified
- **Formal verification / Rust**: [facebookresearch/pyrefly](https://github.com/facebookresearch/pyrefly) — formal verification / rust; stars: unverified
- **CGP / Rust metaprogramming**: [contextgeneric/cgp](https://github.com/contextgeneric/cgp) — cgp / rust metaprogramming; stars: unverified
- **CGP / Rust metaprogramming**: [jeffersonlamb/derive-deftly](https://github.com/jeffersonlamb/derive-deftly) — cgp / rust metaprogramming; stars: unverified
- **CGP / Rust metaprogramming**: [dtolnay/syn](https://github.com/dtolnay/syn) — cgp / rust metaprogramming; stars: unverified
- **CGP / Rust metaprogramming**: [dtolnay/quote](https://github.com/dtolnay/quote) — cgp / rust metaprogramming; stars: unverified
- **CGP / Rust metaprogramming**: [dtolnay/proc-macro2](https://github.com/dtolnay/proc-macro2) — cgp / rust metaprogramming; stars: unverified
- **CGP / Rust metaprogramming**: [bevyengine/bevy](https://github.com/bevyengine/bevy) — Rust ECS and game engine; stars: unverified
- **CGP / Rust metaprogramming**: [PyO3/pyo3](https://github.com/PyO3/pyo3) — Python/Rust interop; stars: unverified
- **Architecture description**: [structurizr/dsl](https://github.com/structurizr/dsl) — architecture description; stars: unverified
- **Architecture description**: [likec4/likec4](https://github.com/likec4/likec4) — Architecture-as-code and C4 diagrams; stars: 6,004
- **Architecture description**: [mermaid-js/mermaid](https://github.com/mermaid-js/mermaid) — Documentation-native diagrams; stars: 90,969
- **Architecture description**: [plantuml/plantuml](https://github.com/plantuml/plantuml) — architecture description; stars: 13,392
- **Architecture description**: [arc42/arc42-template](https://github.com/arc42/arc42-template) — architecture description; stars: 1,317
- **Architecture description**: [structurizr/java](https://github.com/structurizr/java) — architecture description; stars: unverified

## Interpretation rules

- Read originals before relying on a secondary summary for formal logic, Rust unsafety, or model-verifier preconditions.
- A link to source code is evidence of a project location, not proof that every capability in this report is supported at a specific release.
- For proposals (architecture and schemas), the content is an engineering recommendation, not a statement that the project already implements it.
