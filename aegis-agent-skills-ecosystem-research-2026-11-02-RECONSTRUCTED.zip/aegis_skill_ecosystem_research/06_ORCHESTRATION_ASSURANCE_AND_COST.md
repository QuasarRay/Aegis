# 06 — Orchestration, assurance and token/credit optimization

## Structural approach

Reuse Aegis's existing control plane for policy, state and receipts. A new large agent framework is not a prerequisite for a reliable skills system.

**Serial agent guarantee:** enforce one active agentic worker with an out-of-model process lease and refuse host requests for concurrent delegation. A graph framework, if used, must execute agent nodes serially; a dependency graph does not imply parallel agents.

**Deterministic tool concurrency:** separate independent compiler/search/index jobs from simultaneous *agent reasoning* processes. Protect mutable source and evidence files with write scopes and atomic transactions.

### Required durable task record

```json
{
  "work_unit_id": "sha256(source|contract|target|phase)",
  "phase": "implement",
  "parent_goal_id": "host-identity-or-unavailable",
  "agent_lease_id": "exclusive-global-lease",
  "source_ref": "sha256-of-pinned-reference",
  "target_revision": "git-tree-id",
  "required_skill_digests": [],
  "evidence_refs": [],
  "cost": {"prompt_tokens": null, "completion_tokens": null, "cached_tokens": null},
  "state": "running"
}
```

This is a suggested schema, not a claim that existing Aegis uses these exact field names.

## Prevent duplicate work

- Normalize unit keys from immutable source/contract/target tuples.
- Check for already verified matching receipts before recomputing.
- Reuse content-addressed retrieval snippets and expanded context.
- Invalidate downstream evidence whenever relevant source, configuration or target changes.
- Make writes idempotent or transactional; reject re-application after altered predecessors.
- Track semantic task intent, not only filenames; avoid two agents independently translating the same original class.
- Keep unverified partial implementations in explicit staging state, not “done.”

## Token efficiency

Compute a baseline *per work unit*, not only total bill. Track: input tokens, cached input tokens, reasoning/output tokens where reported, tool calls, snippets read, unsuccessful attempts, repeated reads, rework due to changed contracts, and verified source identities delivered.

Prefer **proof of required evidence per token** over merely minimizing output text. A task consuming fewer tokens but requiring a complete rewrite has higher eventual cost.

Sample budget policy:
- Step-specific maximum retrieved passages and token budget.
- Exact/cheap lexical search before semantic reranking.
- Two-stage exploration: metadata/outline before full chapter.
- Do not re-read same unchanged excerpt unless needed for a changed task.
- Escalate ambiguity to an explicit `BLOCKED` state instead of repeating speculative generation.
- Never downgrade a requested reasoning level silently to reduce token cost.

## Assurance layers

| Layer | Concrete check | What it does NOT prove |
|---|---|---|
| Aegis constitution | Scope/approval/frozen contracts/evidence | Domain correctness on its own |
| OPA/Cedar/Casbin | Executable access policy | That reasoning is accurate |
| Source inventory | Original identity completeness under configurations | Correct behavior |
| Rust mapping checker | One canonical group per source identity | Semantic fidelity of body |
| Build/compiler | Well-formed target under selected toolchain | Full behavior or memory safety across `unsafe` |
| Original tests | Sampled original user-facing behaviors | Exhaustive correctness |
| Kani | Bounded model-checking claims for harnessed cases | Unlimited E2E behavior/concurrency absence |
| Independent falsification | Counterexample search/review | Mathematical certainty |
| Tracing | Actual execution and cost visibility | Intrinsic accuracy |

## Orchestration ecosystem choices

**LangGraph:** useful if the existing workflow logic can be represented by explicit serial nodes/checkpoints; avoid an immediate migration because Aegis already has state and evidence semantics.

**Temporal:** most compelling when crash recovery and durable work history exceed what the current local Aegis code can maintain reliably; adds service orchestration and deployment burden.

**Prefect/Dagster/Kestra:** valuable for ingestion, indexing, CI and scheduled data pipelines. Their orchestration features do not automatically enforce no-parallel-agents or domain correctness.

**Unpythonic:** metaprogramming toolkit, not a replacement for the Python language or a durable workflow runtime. Keep optional, capability-scoped; prioritize comprehensible recovery-critical Python over replacing it wholesale.

## Metrics and gates

- `distinct_verified_source_identity_count`
- `source_inventory_coverage_by_configuration`
- `unique_mapping_fraction`
- `original_test_count_total_pass_fail_skip_blocked`
- `harnesses_with_original_test_provenance`
- `proven_harness_conditions_vs_unspecified_conditions`
- `tokens_per_verified_source_identity`
- `duplicate_work_units_prevented`
- `source_hash_staleness_rejections`
- `retrieval_top_k_exact_symbol_recall`
- `agent_lease_violation_count` (must be zero)

## References

https://github.com/QuasarRay/Aegis · https://github.com/langchain-ai/langgraph · https://github.com/temporalio/temporal · https://github.com/PrefectHQ/prefect · https://github.com/open-policy-agent/opa · https://github.com/cedar-policy/cedar · https://github.com/langfuse/langfuse
