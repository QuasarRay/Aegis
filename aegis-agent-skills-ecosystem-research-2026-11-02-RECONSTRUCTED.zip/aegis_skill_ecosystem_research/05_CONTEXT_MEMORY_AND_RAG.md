# 05 — Context, memory, RAG and zero-loss book skills

## What “zero information loss” can and cannot mean

**Achievable:** preserve the authoritative source document byte-for-byte, content hashes, source section/page structure, exact code, tables, diagrams and mathematical expressions where recoverable; maintain raw original bytes even where extraction fails; expose a `read_original` or exact-span retrieval route for contested parts.

**Not achievable as a blanket guarantee:** a finite-context model will remember, attend to, retrieve and apply *all* information from every book during every task. Summarization, embedding and semantic recall are lossy. A parser may misread PDF math, tables or scan order. The audit should say “source retained and retrieval verified,” never “all source meaning guaranteed to be in model.”

## Source ingestion plan

| Stage | Tools to evaluate | Non-negotiable receipt |
|---|---|---|
| Original bytes | git clone/archive, licensed PDF/EPUB/HTML | SHA-256, title, edition, license, publication/revision |
| Structural extraction | Docling, GROBID, Pandoc, Apache Tika, Marker, MinerU | parser revision and confidence/errors |
| Code/math segmentation | language-aware parsers and format-preserving extraction | literal code bytes, math source if available |
| Lexical index | SQLite FTS5, Tantivy, Meilisearch, Typesense | indexed span IDs and source digest |
| Hybrid/vector (optional) | Qdrant, Haystack, LlamaIndex, Vespa | embedding model+version, recall results |
| Graph links (optional) | Microsoft GraphRAG, LightRAG, Joern, CodeQL | relation extraction provenance |
| Tool serving | MCP SDK, FastMCP | read-only contract, source references |
| Agent skill | `SKILL.md`, topic router, narrow scripts | reviewed instructions and content hash |

Keep licensed full-text source material *private*, and distribute only your own indexing procedures, manifests and permissible derived metadata where book licenses restrict redistribution. Do not package copyrighted book contents into public skills by default.

## Technical corpus priorities

| Authoritative corpus | Primary task skill | Special concerns |
|---|---|---|
| *Learning Rust with Entirely Too Many Linked Lists* | ownership and unsafe structural patterns | examples and edition must match |
| *Rust Atomics and Locks* | memory order/synchronization semantics | preserve precise preconditions |
| CGP pattern book + official docs | provider/delegation and type-level design | exact trait names, crate version |
| Kani Book | original-test-to-Kani harnesses | bounded semantics, unsupported operations |
| derive-deftly official docs | derive macros and templates | proc macro expansion/version |
| Agones official docs | source API and lifecycle migration | API version and test provenance |
| Bevy official docs | systems, resources, events, world ownership | ECS version and runtime semantics |
| Rust Book + Rust Reference | syntax and language guarantees | reference is authoritative over tutorial explanations |
| PyO3 official docs | Python-visible APIs, ownership, free-threading | interpreter version and GIL-disabled contract |
| Bolero official docs | test harness operation and backend selection | current Kani backend support |

## Query pipeline

1. Parse request into structured `domain`, `library/version`, `symbols`, `expected_output`, and `verification need`.
2. Search **exact symbols and identifiers first**; use BM25/FTS indexing for punctuation-heavy Rust APIs.
3. Retrieve matched spans and adjacent context when a definition depends on prior prerequisites.
4. If lexical retrieval has low recall, use semantic search; rerank while retaining source spans.
5. Deliver a small source-backed context bundle, with citation metadata.
6. Identify ambiguity or absence explicitly; do not invent an API.
7. Record queries and source hashes so later tasks can reuse successful retrieval without duplicating tokens.

## Test the retrieval system, not the target project

Prepare independent reference queries for:
- exact definition retrieval;
- similarly named type disambiguation;
- version-sensitive API lookup;
- inequality/inference rule with side conditions;
- transcribed code blocks retaining punctuation;
- missing or contradictory sources;
- adversarial text that attempts to override system policy.

Scoring: top-k **answer-bearing passage recall**, citation precision, exact byte/string match on source spans, version correctness, abstention on missing evidence, retrieval latency and tokens delivered. Source traceability is part of the score.

## Why not Unlimiformer now

The original Unlimiformer project modifies model-level attention/retrieval for compatible transformer architectures. Codex's hosted models do not expose an API to replace their attention layers. A separate Unlimiformer model is possible, but would create another model and evaluation burden. The original code has not had frequent main-branch updates in the prior inspection. This is research for a separate local-model program, not a production dependency for Aegis's Codex skills.

## Memory and caching are different

- **Book knowledge**: versioned, immutable source corpus and index.
- **Task memory**: current project artifacts, decisions, missing objects, review findings.
- **Execution memory**: resume tokens, leases, receipts, hashes and budget ledger.
- **Summarized model memory**: useful but untrusted hints; never authority for source correctness.

Letta, Mem0, Graphiti/Zep and Cognee target different persistent-memory patterns. Keep these as options until a clear task demonstrates the need to move beyond Aegis's current durable context ledger.

## Sources

- https://github.com/docling-project/docling
- https://github.com/deepset-ai/haystack
- https://github.com/infiniflow/ragflow
- https://github.com/qdrant/qdrant
- https://github.com/tantivy-search/tantivy
- https://github.com/microsoft/graphrag
- https://github.com/HKUDS/LightRAG
- https://github.com/letta-ai/letta-code
- https://github.com/abertsch72/unlimiformer
