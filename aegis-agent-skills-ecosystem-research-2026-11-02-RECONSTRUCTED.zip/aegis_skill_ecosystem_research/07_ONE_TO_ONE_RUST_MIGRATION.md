# 07 — Strict one-to-one Rust migration infrastructure

## Invariants

Let **S** be all original, required, configuration-scoped source identities. Let **T** be the set of canonical target Rust object groups. The mapping **f:S→T** must be injective and total over S (one target group for every required original identity; no two distinct source identities collapse into the same target group).

The target group may contain a bounded set of Rust `struct`, `trait`, `enum`, and `impl` elements representing one original class. Every member declares:
- target canonical object group ID;
- original source identity;
- semantic role (data, behavior, inherited interface, state owner);
- declaring owner for each method;
- source revision, path, canonical signature, and configuration.

An original C++ class may require several Rust declarations; *that permission does not permit a second original class to reuse its canonical target identity*. Generic CGP providers and Bevy infrastructure may be shared, but **canonical public object identities remain distinct**.

## Authoritative denominator extraction

- C/C++: Clang LibTooling AST, compile database, template specialization, conditional compilation, macro expansion/source references. Enumerate **all required configurations**, not merely the default preprocessing branch.
- Go: `go/packages`, `go/types`, AST + build tags. Keep embedded methods, interfaces and generated sources.
- Java: semantic compiler frontends/JDT or JavaParser with symbol resolution. Include default methods, inheritance, overloads and annotations.
- Python: `ast`, runtime-visible classes, decorators, imports, protocol implementations, conditional definitions and shadowed names where relevant; source analysis cannot safely infer all dynamic behavior.
- Rust target: rust-analyzer semantic model and compiler/rustdoc metadata; macro-generated types require expansion-aware inspection.

Joern/CPG and CodeQL complement compiler ASTs with calls, dependencies and data-flow relationships. They should not replace the authoritative parser/configuration inventory.

## Minimal correspondence schema

```json
{
  "source": {
    "repo": "blue", "revision": "<sha>", "configuration": "linux-with-python",
    "qualified_id": "MemStream", "kind": "class", "signature": "<canonical>",
    "owner": null, "declaration_path": "<path>", "source_span": [28, 107]
  },
  "target": {
    "group_id": "blue::MemStream", "elements": [
      {"path": "blue::streams::MemStream", "role": "data-owner"},
      {"path": "blue::streams::IBlueMemStream", "role": "interface"},
      {"path": "<impl>", "role": "method-owner"}
    ],
    "unique_original_owner": "blue::MemStream"
  },
  "method_map": [],
  "relationships": [],
  "disposition": "BLUE_SPECIFIC",
  "status": "PARTIAL",
  "evidence": []
}
```

This is illustrative. Where a trait is **itself** a distinct original interface, it must retain its own canonical source-to-target correspondence identity; cross-object references do not merge identities. Build explicit relationship links instead of implying ownership from nesting.

## Mechanical audits

1. Inventory hash and source configuration set immutable for the task.
2. Independently re-extract S at completion; compare against initial S and mapping table.
3. Fail on unknown/unmapped required source IDs; statuses are explicit `UNRESOLVED`, `EXTERNAL_BOUNDARY`, `NATIVE_RUST_MECHANISM`, or an approved exclusion.
4. Fail on duplicate canonical target group for multiple distinct source IDs.
5. Compare declared method ownership, arity, naming and signatures with documented translation rules.
6. Compare class inheritance/interface graph edges with Rust trait/composition/delegation edges; review Rust mechanisms that do not structurally match directly.
7. Verify the implementation actually compiles and runs the original test suite without test edits.
8. Record semantic uncertainty instead of declaring full parity because names match.

No automated check can prove that arbitrary C++ and Rust code are behaviorally equivalent for every possible input, especially under UB, concurrency, FFI and platform-specific behavior. Keep claims appropriately scoped.

## Original-test-derived Kani harnesses

Desired workflow:
`original test -> AST/test manifest -> extracted setup/input/visible output/oracles -> generated bounded Rust harness -> traceability receipt -> Kani check`.

Every Kani harness assertion, assumption, allowed input and expected output must trace to the original **existing** test(s). A harness with a fabricated assertion fails provenance review. A missing or unexpressible behavior must be reported, not silently replaced by a weaker check.

Kani can verify assertions of a finite bounded Rust model, but a whole-process Python/C++/network/Bevy E2E execution is generally not directly symbolic inside Kani. Use a Rust core model exposing the externally visible input/output contract and explicitly prove or test the connection between that core model and application boundary. Do not call that full E2E formal proof without supporting evidence.

**Initial phase exclusions:** do not introduce Kani concurrency proofs, performance proofs, or auxiliary technical safety contracts as replacements for domain behavior. Those can be introduced in later authorized phases. This restriction is user policy, not an assertion that Kani supports all those domains.

Bolero can support property/fuzz testing and compatible verification backends; verify its **current** Kani-backend capabilities in the pinned version rather than asserting any particular integration works generically.

## CGP and modernization

CGP should be pervasive inside the Rust implementation: component providers, delegation and replaceable modules. The invariant is that *internal implementation abstraction may change*, but public canonical object identities, responsibility ownership, naming conventions and relationships remain source-traceable.

Migration sequence: inventory first, then canonical mapping, then mechanically generated shells where safe, then semantic implementations, then original tests/Kani, then documentation from CPGSchema and ISO/IEC/IEEE 42010 viewpoints. Do not generate architecture documentation from a partial inventory and present it as final.

## Relevant sources

- https://github.com/llvm/llvm-project
- https://github.com/joernio/joern
- https://github.com/github/codeql
- https://github.com/tree-sitter/tree-sitter
- https://github.com/rust-lang/rust-analyzer
- https://github.com/immunant/c2rust
- https://github.com/Cpp2Rust/cpp2rust
- https://github.com/model-checking/kani
- https://github.com/verus-lang/verus
- https://github.com/bevyengine/bevy
- https://github.com/PyO3/pyo3
