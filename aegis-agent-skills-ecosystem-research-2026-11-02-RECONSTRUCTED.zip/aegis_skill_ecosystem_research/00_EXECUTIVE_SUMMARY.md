# 00 — Executive summary

## Bottom line

**Deploy books as immutable, searchable reference corpora; deploy skills as small executable procedures for retrieving and applying those corpora.** Attach them to Codex through supported skills and read-only MCP tools. Keep the Aegis policy compiler, evidence ledger, immutable governance, and sequential-agent lease outside the LLM.

For **one-to-one Rust migration**, build the independent source inventory and correspondence checker before investing in more sophisticated agent-memory or agent-orchestration features. Semantic equivalence evidence and object-model correspondence are *separate* acceptance obligations.

### Why

- `SKILL.md` is an instruction entry point, not a lossless book representation. If the original EPUB/PDF/HTML/docs snapshot is retained immutably and retrieval returns verifiable passages, *storage* is lossless while the model's active context remains bounded. No method can guarantee that the model attends to every stored fact in every turn.
- Codex and other coding agents can use skill progressive disclosure. MCP can expose search and read endpoints, reducing prompt expansion. Avoid modifying hidden model attention internals or forking Codex unless a documented external interface is demonstrably insufficient.
- Aegis 4.0 already has constitutional policy, task state, content-addressed evidence, TDD gates, independent review, `REIMPLEMENTATION` class, and a Codex adapter. Preserve those foundations.
- Initial Aegis implementation should be **read-only against existing Blue and Destiny Goals**, not install new governance into an active run.
- Star counts measure community interest only. The repository atlas tracks source-verifiable stars separately from assurance and production-readiness assessments.

## Decisions by phase

| Decision | Now | Later | Reason |
|---|---|---|---|
| Native Agent Skills in `.agents/skills/` | Yes | — | Low coupling; supported discovery |
| Immutable source corpus + manifest | Yes | — | Enforces provenance and zero-loss storage |
| Exact lexical search: SQLite FTS5/Tantivy | Yes | — | Auditable and inexpensive |
| Read-only MCP documentation server | Yes | — | Clear separation of agent and source knowledge |
| Hybrid vector/reranking (Qdrant/Haystack) | Pilot if recall requires | Yes | Adds infrastructure and tuning burden |
| Source-side Clang/Python/Rust extraction | Yes | — | Builds missing denominator for one-to-one claims |
| Kani harnesses generated from original tests | Pilot | Expand | Harness origin must remain traceable |
| LangGraph for orchestration | Not required | Optional | Replace custom state machine only with demonstrated benefit |
| Temporal durable workflows | Not required | Optional | Helpful at scale; separate operational cost |
| Unlimiformer / altered model attention | No | Research | Unsupported as Codex plug-in; high supervisory cost |
| Parallel subagents | Never under this policy | Never | Hard user requirement |

## Most useful projects by Aegis function

| Function | Representative candidates | Constraint |
|---|---|---|
| Skill format and installation | openai/skills, vercel-labs/skills, wshobson/agents | Skill content can include unsafe instructions; lint and review |
| MCP implementation | modelcontextprotocol/python-sdk, modelcontextprotocol/rust-sdk, PrefectHQ/fastmcp | Use read-only tools first |
| Technical document ingestion | docling-project/docling, GROBID, Pandoc, Apache Tika | Verify math and code blocks against originals |
| Knowledge routing | SQLite FTS5, tantivy, Haystack, Qdrant | Exact source references and evaluation |
| Agent lifecycle | Existing Aegis; LangGraph or Temporal if justified | One global lease, no fan-out |
| Evidence and observability | langfuse/langfuse, Arize-ai/phoenix, OpenTelemetry | Redact secrets and avoid duplicate traces |
| Cross-language source identity | llvm/llvm-project, joernio/joern, tree-sitter, rust-analyzer | Macro/configuration completeness |
| Formal domain contracts | model-checking/kani, Bolero | Bounded proofs; no claims beyond original tests |
| Policy enforcement | Aegis, OPA, Cedar | Trust-boundary enforcement must be executable |

## Non-negotiable factual limitations

1. The original GitHub README of Aegis 4.0 says agents cannot modify deployed `.agents/`; trusted maintainers release packages into it. New generated skills should be staged and deployed under that boundary.
2. Aegis's constitutional test-first and property-first rules can conflict with the Blue contract's restriction on new tests. This is a *policy conflict*, not a feature toggle to bypass.
3. The official `modelcontextprotocol/...` and Codex projects evolve rapidly; version-lock APIs and protocol revisions before implementation.
4. Current public Codex support for Goal/Plan extensions must be established from supported interfaces; do not treat opaque internal plugins as open extension APIs.
5. Neither static correspondence checks nor bounded model checking alone proves complete domain behavioral equivalence.

## Immediate pilot recommendation

Use one small, fixed book/doc set; one read-only MCP server; one single-agent Codex run; one source-correspondence comparison for a small Blue subsystem. Freeze input hashes, test retrieval recall, measure prompt tokens, and review every false positive and false negative before expanding.
