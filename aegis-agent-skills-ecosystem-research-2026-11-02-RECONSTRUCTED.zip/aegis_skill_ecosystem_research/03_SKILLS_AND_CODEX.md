# 03 — Skills, Codex, and reusable procedural knowledge

## Definition of a skill

A good `SKILL.md` encodes **when the agent should act, which tools to call, what evidence is required, and how to detect failure**. It is not an unversioned dump of a textbook.

Suggested skill family:
- `source-inventory`: compiler/Python AST/CPG extraction and completeness accounting.
- `one-to-one-rust-object-mapping`: identity-preserving translation workflow and canonical target groups.
- `cgp-design`: CGP providers, delegation, trait boundaries and proof obligations.
- `kani-from-original-tests`: preserve original test provenance and reject invented assertions.
- `book-reference-search`: exact and adjacent reference lookup.
- `bevy-runtime-mapping`: real ECS semantics, not registration-only.
- `pyo3-interop`: Python-visible names and ownership.
- `evidence-finalization`: content hashes, receipts, contract compliance.

### Per-skill directory

```text
.agents/skills/cgp-design/
  SKILL.md                  # workflow, bounded entrypoint
  metadata.json             # canonical skill ID, version, source hashes, capabilities
  references/INDEX.md       # routing topics only
  scripts/check_contract.py # deterministic validators
  tests/                    # tests of the skill/tool, not new app behavior contracts
```

Avoid sending the entire book as a model-visible skill body. For zero loss of *stored information*, retain the untouched original document and an auditable extraction with source maps; retrieved excerpts are temporary working sets.

## Progressive disclosure and task matching

Store only small catalog metadata in the initial agent skill list. Trigger the appropriate procedure based on:
- task phase and work-unit contract;
- source language and target Rust APIs;
- exact symbols from compiler diagnostics;
- semantic concepts (only as a second-stage fallback);
- authoritative source edition, feature flags, and version.

Implement `skill lock` entries with: `skill_id`, `content_sha256`, `source_digest`, `declared_tools`, `version`, `verification_status`, `owner`, and `capability_requirements`.

## Skill generation procedure

1. Ingest authoritative sources and preserve original bytes.
2. Extract topic outline/sections with offsets and `page` or `source_line` links.
3. Draft a small skill that tells the agent how to search, how to identify version conflicts, and when to request independent review.
4. Analyze skill code and dependencies; do not trust generated shell commands.
5. Run a fixed, human-reviewed set of *skill retrieval* checks: exact API lookup, ambiguous query, obsolete version, missing source and malicious prompt-injection example.
6. Freeze a skill package manifest and independent review receipt.
7. Publish with a trusted release and reversible version.

The user preference against new Blue **behavioral** tests need not ban testing of the independent retrieval infrastructure; nevertheless, preserve the Aegis constitution and request an explicit project-policy resolution if their scope conflicts.

## Cross-host examples and integration priorities

- `https://github.com/openai/skills` — Codex-centric packages and authoring exemplars.
- `https://github.com/anthropics/skills` — other implementation of portable Agent Skills.
- `https://github.com/vercel-labs/skills` — host-agnostic installation management.
- `https://github.com/wshobson/agents` — shared definitions rendered into multiple agent hosts.
- `https://github.com/agentsmd/agents.md` — repository-wide instruction structure.
- `https://github.com/JetBrains/skills` — curated IDE-related skill sources.
- `https://github.com/microsoft/skills` — skills with SDK/tool grounding.
- `https://github.com/skill-one/agents-skills` — Rust skills-management candidate (verify before production).

Aegis's existing adapter should validate the *effective* model configuration when the host exposes it. The words “max reasoning” in an instruction are not executable enforcement. Aegis must not assume every model exposes a literal `max` effort level.

## Codex Goal and Plan integration

Use native documented Codex lifecycle and session APIs where present. Goal and Plan features as exposed through particular hosts/connectors may not have a public programmatic API. Maintain provider-specific capability declarations:
- `goals.read`, `goals.create`, `goals.update`, `goals.complete`;
- `plans.read`, `plans.update`;
- `reasoning.select`, `reasoning.observe`;
- `agent.spawn`, `agent.cancel`, `agent.resume`.

Set unsupported capability to `UNAVAILABLE`, not a simulated success. Avoid building a separate “Goal clone” that silently diverges from the host's native lifecycle.

## Efficiency rules

- Task-first retrieve; maximum context budget by step.
- Cache content-addressed exact excerpts by `(source_digest, query_type, span)`.
- Reuse diagnostic lookup rather than reprompting with complete book chapters.
- Store a concise context ledger; never silently discard unresolved obligations.
- Include citations in every retrieval result, not only in final prose.
