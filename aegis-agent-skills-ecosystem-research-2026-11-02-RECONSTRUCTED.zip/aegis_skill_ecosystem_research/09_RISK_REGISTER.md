# 09 — Risk register and supervision constraints

Severity levels are qualitative engineering judgments, not standardized vulnerability scores.

| Risk | Severity | Evidence/trigger | Mitigation |
|---|---|---|---|
| Full book converted into a summarizing skill | High | Book details discarded or unstated | Immutable source bytes, exact-span tools, retrieval audit |
| PDF math/code extraction corrupts meaning | High | Dropped symbols, wrong layout | Original view, parsers with layout evidence, exact text comparison |
| Prompt injection in retrieved material | High | Source text instructs agent to ignore policy | Treat text as untrusted data, rigid policy hierarchy, tool allowlist |
| Silent unsupported Goal/Plan extension | High | Simulated RPC success | Capability probe and explicit `UNAVAILABLE` |
| `max` reasoning silently downgraded | High | Effective host differs from config | Observe effective model/effort, fail closed where possible |
| Parallel worker escapes lease | High | Two agent tasks write concurrently | Single global process lease, independent lock audit |
| New harness behavior fabricated | High | Assertion no source test reference | Provenance per assumption/assertion |
| Source inventory incomplete | Critical | Unparsed configurations/macros | Independent re-extraction and unresolved registry |
| Different original classes merged into one Rust group | Critical | Duplicate target canonical ID | Deterministic one-to-one mapping gate |
| “Kani passed” overstated as full E2E proof | High | Model checked but integration untested | Explicit bounded-model and boundary coverage labels |
| CGP shared providers obscure original responsibility | High | No distinct public canonical object identity | Explicit source graph node and target object group |
| Runtime version drift | High | Retrieval docs inconsistent with installed APIs | Pinned versions; hashes, config metadata |
| Duplicate/repeated LLM work | Medium–high | Same unit reprocessed | Content-addressed work IDs, receipts, resumed state |
| Framework rewrite destroys existing assurance | Critical | LangGraph migration bypasses laws | Keep Aegis control plane until parity verified |
| Aegis hard policy conflicts with Blue contract | High | New app tests demanded despite user prohibition | Resolve policy conflict before deployment |
| Dynamic plugin/skill changes active governance | Critical | Agent modifies `.agents` | Human-only packaging and immutable deploy |
| Logging leaks tokens/secrets/source books | High | Trace contains private keys or copyrighted text | Redaction, access control and retention rules |
| License noncompliance for book or code corpus | High | Distributed unlicensed material | Retain private sources and publish only lawful metadata |
| Archived project relied upon as maintained | Medium | Obsolete dependency and security patching | Inspect maintenance, record archived status, choose maintained alternatives |
| High star count mistaken for proof | Medium | Unreviewed project auto-adopted | Score assurance independent of popularity |
| Unlimiformer inference modification | High now | Unsupported closed-model layer integration | Defer; separate research only |

## Detectability/assurance

Most of Aegis's dangerous failure modes are *silent* (undocumented omissions, unauthorized contract changes, fabricated evidence, source parser incompleteness). The most useful controls convert silence into a **hard failure with source ID, evidence hash, and precise location**.

## Policy conflict needing explicit design

Aegis README and `core/08-testing-and-laws.md` require executable, test-first, property-focused assurance. Blue's current execution contract forbids added behavioral tests and requests original tests unchanged. Before deploying Aegis into Blue, decide which *separately scoped* verification suites are permissible (framework tools vs application behavior), and whether Aegis's constitutional rules can be satisfied without introducing unapproved application requirements. Do not “just disable” the hard policy.

## Fallback

Retain the working Codex Goals and migration branches. New Aegis skill/MCP components are read-only add-ons initially. Roll back by removing their provider registration; original projects remain unchanged. Only after a successful controlled pilot promote mapping-law checks into immutable project governance.
