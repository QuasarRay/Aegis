# 02 — Project catalog (161 projects)

**Recovery status:** This catalog has been reconstructed from the completed research narrative and supplemented with GitHub repository metadata obtained during the recovery session. It is not represented as an exact original Deep Research file.

**Verified stars:** 85 / 161 repository rows have GitHub-reported star counts captured on 2026-11-02. A missing value is deliberately marked `—` rather than estimated.

**Stars are not assurance.** Production readiness and assurance below are *qualitative implementation-screening judgments*, not proof, certification, security audit, service-level guarantees or claims of proven safe use in Aegis.

## Scoring and grouping methodology

- **Stars:** direct GitHub API metadata for a subset; snapshot date 2026-11-02. Star bands: 100k+, 50k–99k, 10k–49k, 1k–9k, <1k and not verified.
- **Production readiness:** `Established component; verify integration` indicates infrastructure maturity or recognized production use, not a claim that this particular fork/version has passed Aegis acceptance. `Adoption evidence` requires version, license and deployment review. `Research/experimental` means do not auto-deploy.
- **Assurance contribution:** `High` for tools with enforceable machine checks in their supported domain; `Medium` for evidence generation or evaluation; `Indirect/unassessed` for tools whose assurance depends on configuration. **High does not mean formally verified implementation**.
- **Priority:** P0 = small read-only pilot, P1 = near-term candidate, `Reference/later` = research or optional alternative.
- **Niche:** primary reason to consider the repo. For nonspecialized entries the group name is used as an approximate placeholder and must be reviewed.
- **Status:** entries without retrieved GitHub metadata are unverified references; their URL and maintenance status should be checked before adoption.

## Verified GitHub star-tier index

### 100k+ — 5 repositories

[n8n-io/n8n](https://github.com/n8n-io/n8n) (209,325), [anthropics/skills](https://github.com/anthropics/skills) (186,472), [langgenius/dify](https://github.com/langgenius/dify) (160,193), [langchain-ai/langchain](https://github.com/langchain-ai/langchain) (148,858), [openai/codex](https://github.com/openai/codex) (132,792)

### 50k–99k — 9 repositories

[infiniflow/ragflow](https://github.com/infiniflow/ragflow) (93,325), [mermaid-js/mermaid](https://github.com/mermaid-js/mermaid) (90,969), [opendatalab/MinerU](https://github.com/opendatalab/MinerU) (82,970), [docling-project/docling](https://github.com/docling-project/docling) (69,980), [mem0ai/mem0](https://github.com/mem0ai/mem0) (68,261), [microsoft/autogen](https://github.com/microsoft/autogen) (61,670), [crewAIInc/crewAI](https://github.com/crewAIInc/crewAI) (60,403), [meilisearch/meilisearch](https://github.com/meilisearch/meilisearch) (59,750), [run-llama/llama_index](https://github.com/run-llama/llama_index) (52,779)

### 10k–49k — 47 repositories

[apache/airflow](https://github.com/apache/airflow) (47,345), [jgm/pandoc](https://github.com/jgm/pandoc) (46,781), [milvus-io/milvus](https://github.com/milvus-io/milvus) (46,556), [langchain-ai/langgraph](https://github.com/langchain-ai/langgraph) (44,308), [wshobson/agents](https://github.com/wshobson/agents) (42,092), [llvm/llvm-project](https://github.com/llvm/llvm-project) (41,295), [facebookresearch/faiss](https://github.com/facebookresearch/faiss) (41,246), [HKUDS/LightRAG](https://github.com/HKUDS/LightRAG) (40,475), [stanfordnlp/dspy](https://github.com/stanfordnlp/dspy) (38,882), [vercel-labs/skills](https://github.com/vercel-labs/skills) (37,683), [langfuse/langfuse](https://github.com/langfuse/langfuse) (36,859), [microsoft/graphrag](https://github.com/microsoft/graphrag) (36,528), [qdrant/qdrant](https://github.com/qdrant/qdrant) (35,377), [topoteretes/cognee](https://github.com/topoteretes/cognee) (32,994), [getzep/graphiti](https://github.com/getzep/graphiti) (32,426), [huggingface/smolagents](https://github.com/huggingface/smolagents) (30,184), [kestra-io/kestra](https://github.com/kestra-io/kestra) (30,115), [chroma-core/chroma](https://github.com/chroma-core/chroma) (29,620), [mastra-ai/mastra](https://github.com/mastra-ai/mastra) (29,268), [microsoft/semantic-kernel](https://github.com/microsoft/semantic-kernel) (28,725), [mlflow/mlflow](https://github.com/mlflow/mlflow) (28,625), [openai/skills](https://github.com/openai/skills) (28,454), [PrefectHQ/fastmcp](https://github.com/PrefectHQ/fastmcp) (28,269), [tree-sitter/tree-sitter](https://github.com/tree-sitter/tree-sitter) (27,354), [typesense/typesense](https://github.com/typesense/typesense) (27,075), [deepset-ai/haystack](https://github.com/deepset-ai/haystack) (26,905), [promptfoo/promptfoo](https://github.com/promptfoo/promptfoo) (26,725), [letta-ai/letta](https://github.com/letta-ai/letta) (25,319), [agentsmd/agents.md](https://github.com/agentsmd/agents.md) (25,270), [modelcontextprotocol/python-sdk](https://github.com/modelcontextprotocol/python-sdk) (24,735), [temporalio/temporal](https://github.com/temporalio/temporal) (24,127), [PrefectHQ/prefect](https://github.com/PrefectHQ/prefect) (24,106), [pgvector/pgvector](https://github.com/pgvector/pgvector) (23,565), [pydantic/pydantic-ai](https://github.com/pydantic/pydantic-ai) (20,992), [confident-ai/deepeval](https://github.com/confident-ai/deepeval) (19,236), [windmill-labs/windmill](https://github.com/windmill-labs/windmill) (18,357), [semgrep/semgrep](https://github.com/semgrep/semgrep) (17,401), [rust-lang/rust-analyzer](https://github.com/rust-lang/rust-analyzer) (16,964), [weaviate/weaviate](https://github.com/weaviate/weaviate) (16,934), [dagster-io/dagster](https://github.com/dagster-io/dagster) (16,361), [Unstructured-IO/unstructured](https://github.com/Unstructured-IO/unstructured) (15,669), [modelcontextprotocol/typescript-sdk](https://github.com/modelcontextprotocol/typescript-sdk) (13,694), [plantuml/plantuml](https://github.com/plantuml/plantuml) (13,392), [open-policy-agent/opa](https://github.com/open-policy-agent/opa) (12,419), [Arize-ai/phoenix](https://github.com/Arize-ai/phoenix) (12,096), [lancedb/lancedb](https://github.com/lancedb/lancedb) (11,826), [github/codeql](https://github.com/github/codeql) (10,290)

### 1k–9k — 20 repositories

[mark3labs/mcp-go](https://github.com/mark3labs/mcp-go) (9,213), [open-telemetry/opentelemetry-collector](https://github.com/open-telemetry/opentelemetry-collector) (7,728), [NVIDIA-NeMo/Guardrails](https://github.com/NVIDIA-NeMo/Guardrails) (7,409), [rust-lang/miri](https://github.com/rust-lang/miri) (6,707), [likec4/likec4](https://github.com/likec4/likec4) (6,004), [modelcontextprotocol/go-sdk](https://github.com/modelcontextprotocol/go-sdk) (5,298), [getzep/zep](https://github.com/getzep/zep) (4,985), [immunant/c2rust](https://github.com/immunant/c2rust) (4,832), [apache/tika](https://github.com/apache/tika) (4,121), [modelcontextprotocol/rust-sdk](https://github.com/modelcontextprotocol/rust-sdk) (4,083), [letta-ai/letta-code](https://github.com/letta-ai/letta-code) (3,758), [model-checking/kani](https://github.com/model-checking/kani) (3,627), [joernio/joern](https://github.com/joernio/joern) (3,614), [verus-lang/verus](https://github.com/verus-lang/verus) (3,536), [ProtectAI/llm-guard](https://github.com/ProtectAI/llm-guard) (3,219), [creusot-rs/creusot](https://github.com/creusot-rs/creusot) (1,951), [cedar-policy/cedar](https://github.com/cedar-policy/cedar) (1,831), [facebookresearch/TransCoder](https://github.com/facebookresearch/TransCoder) (1,728), [arc42/arc42-template](https://github.com/arc42/arc42-template) (1,317), [diffblue/cbmc](https://github.com/diffblue/cbmc) (1,157)

### <1k — 4 repositories

[GaloisInc/crucible](https://github.com/GaloisInc/crucible) (781), [Cpp2Rust/cpp2rust](https://github.com/Cpp2Rust/cpp2rust) (318), [rust-mcp-stack/rust-mcp-sdk](https://github.com/rust-mcp-stack/rust-mcp-sdk) (199), [GaloisInc/crux](https://github.com/GaloisInc/crux) (1)

### not verified — 76 repositories

[vercel-labs/agent-skills](https://github.com/vercel-labs/agent-skills), [microsoft/skills](https://github.com/microsoft/skills), [JetBrains/skills](https://github.com/JetBrains/skills), [skill-one/agents-skills](https://github.com/skill-one/agents-skills), [cortesi/agentsmd](https://github.com/cortesi/agentsmd), [modelcontextprotocol/modelcontextprotocol](https://github.com/modelcontextprotocol/modelcontextprotocol), [modelcontextprotocol/servers](https://github.com/modelcontextprotocol/servers), [modelcontextprotocol/java-sdk](https://github.com/modelcontextprotocol/java-sdk), [modelcontextprotocol/csharp-sdk](https://github.com/modelcontextprotocol/csharp-sdk), [modelcontextprotocol/kotlin-sdk](https://github.com/modelcontextprotocol/kotlin-sdk), [modelcontextprotocol/swift-sdk](https://github.com/modelcontextprotocol/swift-sdk), [punkpeye/awesome-mcp-servers](https://github.com/punkpeye/awesome-mcp-servers), [qdrant/mcp-server-qdrant](https://github.com/qdrant/mcp-server-qdrant), [docling-project/docling-mcp](https://github.com/docling-project/docling-mcp), [All-Hands-AI/OpenHands](https://github.com/All-Hands-AI/OpenHands), [langchain-ai/deepagents](https://github.com/langchain-ai/deepagents), [microsoft/agent-framework](https://github.com/microsoft/agent-framework), [BerriAI/litellm](https://github.com/BerriAI/litellm), [openai/openai-agents-python](https://github.com/openai/openai-agents-python), [google/adk-python](https://github.com/google/adk-python), [google-gemini/gemini-cli](https://github.com/google-gemini/gemini-cli), [anthropics/claude-code](https://github.com/anthropics/claude-code), [Aider-AI/aider](https://github.com/Aider-AI/aider), [continuedev/continue](https://github.com/continuedev/continue), [sst/opencode](https://github.com/sst/opencode), [cline/cline](https://github.com/cline/cline), [RooCodeInc/Roo-Code](https://github.com/RooCodeInc/Roo-Code), [VikParuchuri/marker](https://github.com/VikParuchuri/marker), [kermitt2/grobid](https://github.com/kermitt2/grobid), [pymupdf/PyMuPDF](https://github.com/pymupdf/PyMuPDF), [pypdfium2-team/pypdfium2](https://github.com/pypdfium2-team/pypdfium2), [docling-project/docling-pipelines](https://github.com/docling-project/docling-pipelines), [OCRmyPDF/OCRmyPDF](https://github.com/OCRmyPDF/OCRmyPDF), [facebookresearch/nougat](https://github.com/facebookresearch/nougat), [tantivy-search/tantivy](https://github.com/tantivy-search/tantivy), [elastic/elasticsearch](https://github.com/elastic/elasticsearch), [opensearch-project/OpenSearch](https://github.com/opensearch-project/OpenSearch), [vespa-engine/vespa](https://github.com/vespa-engine/vespa), [redis/redis](https://github.com/redis/redis), [unum-cloud/usearch](https://github.com/unum-cloud/usearch), [Neo4j/neo4j](https://github.com/Neo4j/neo4j), [quickwit-oss/quickwit](https://github.com/quickwit-oss/quickwit), [MemTensor/MemOS](https://github.com/MemTensor/MemOS), [agno-agi/agno](https://github.com/agno-agi/agno), [temporalio/sdk-python](https://github.com/temporalio/sdk-python), [hatchet-dev/hatchet](https://github.com/hatchet-dev/hatchet), [inngest/inngest](https://github.com/inngest/inngest), [casbin/casbin](https://github.com/casbin/casbin), [guardrails-ai/guardrails](https://github.com/guardrails-ai/guardrails), [truera/trulens](https://github.com/truera/trulens), [openai/evals](https://github.com/openai/evals), [UKGovernmentBEIS/inspect_ai](https://github.com/UKGovernmentBEIS/inspect_ai), [grafana/grafana](https://github.com/grafana/grafana), [explodinggradients/ragas](https://github.com/explodinggradients/ragas), [microsoft/presidio](https://github.com/microsoft/presidio), [invariantlabs-ai/invariant](https://github.com/invariantlabs-ai/invariant), [JaidedAI/EasyOCR](https://github.com/JaidedAI/EasyOCR), [rust-lang/rust](https://github.com/rust-lang/rust), [python/cpython](https://github.com/python/cpython), [golang/go](https://github.com/golang/go), [eclipse-jdt/eclipse.jdt.core](https://github.com/eclipse-jdt/eclipse.jdt.core), [srcML/srcML](https://github.com/srcML/srcML), [kastor-io/konveyor-analyzer-lsp](https://github.com/kastor-io/konveyor-analyzer-lsp), [bolero-rs/bolero](https://github.com/bolero-rs/bolero), [viperproject/prusti-dev](https://github.com/viperproject/prusti-dev), [GaloisInc/saw-script](https://github.com/GaloisInc/saw-script), [facebookresearch/pyrefly](https://github.com/facebookresearch/pyrefly), [contextgeneric/cgp](https://github.com/contextgeneric/cgp), [jeffersonlamb/derive-deftly](https://github.com/jeffersonlamb/derive-deftly), [dtolnay/syn](https://github.com/dtolnay/syn), [dtolnay/quote](https://github.com/dtolnay/quote), [dtolnay/proc-macro2](https://github.com/dtolnay/proc-macro2), [bevyengine/bevy](https://github.com/bevyengine/bevy), [PyO3/pyo3](https://github.com/PyO3/pyo3), [structurizr/dsl](https://github.com/structurizr/dsl), [structurizr/java](https://github.com/structurizr/java)

## Classified by strongest niche

### Skills / standards / Codex — 11 projects

| Project | GitHub stars | Production readiness | Assurance contribution | Strongest niche | Priority |
|---|---:|---|---|---|---|
| [anthropics/skills](https://github.com/anthropics/skills) | 186,472 | Established* | Unassessed | Agent Skills examples and portable conventions | Reference / later |
| [openai/codex](https://github.com/openai/codex) | 132,792 | Established* | Unassessed | Native Codex coding agent and configuration | P0 |
| [wshobson/agents](https://github.com/wshobson/agents) | 42,092 | Review needed | Unassessed | Cross-harness skill and agent source generation | Reference / later |
| [vercel-labs/skills](https://github.com/vercel-labs/skills) | 37,683 | Established* | Unassessed | Multi-agent skill installation/management | Reference / later |
| [openai/skills](https://github.com/openai/skills) | 28,454 | Established* | Unassessed | Curated Codex skills and skill authoring | P0 |
| [agentsmd/agents.md](https://github.com/agentsmd/agents.md) | 25,270 | Established* | Unassessed | Repository instruction convention | Reference / later |
| [vercel-labs/agent-skills](https://github.com/vercel-labs/agent-skills) | — (unverified) | Unverified | Unassessed | skills / standards / codex | Reference / later |
| [microsoft/skills](https://github.com/microsoft/skills) | — (unverified) | Unverified | Unassessed | skills / standards / codex | Reference / later |
| [JetBrains/skills](https://github.com/JetBrains/skills) | — (unverified) | Unverified | Unassessed | skills / standards / codex | Reference / later |
| [skill-one/agents-skills](https://github.com/skill-one/agents-skills) | — (unverified) | Unverified | Unassessed | skills / standards / codex | Reference / later |
| [cortesi/agentsmd](https://github.com/cortesi/agentsmd) | — (unverified) | Unverified | Unassessed | skills / standards / codex | Reference / later |

*Established = operationally plausible candidate, subject to your own independent security, version, license and capability testing.*

### MCP server infrastructure — 16 projects

| Project | GitHub stars | Production readiness | Assurance contribution | Strongest niche | Priority |
|---|---:|---|---|---|---|
| [PrefectHQ/fastmcp](https://github.com/PrefectHQ/fastmcp) | 28,269 | Established* | Unassessed | Rapid Python MCP development | P0 |
| [modelcontextprotocol/python-sdk](https://github.com/modelcontextprotocol/python-sdk) | 24,735 | Established* | Medium | Official Python MCP SDK | P0 |
| [modelcontextprotocol/typescript-sdk](https://github.com/modelcontextprotocol/typescript-sdk) | 13,694 | Established* | Medium | Official TypeScript MCP SDK | Reference / later |
| [mark3labs/mcp-go](https://github.com/mark3labs/mcp-go) | 9,213 | Established* | Unassessed | mcp server infrastructure | Reference / later |
| [modelcontextprotocol/go-sdk](https://github.com/modelcontextprotocol/go-sdk) | 5,298 | Established* | Unassessed | Official Go MCP SDK | Reference / later |
| [modelcontextprotocol/rust-sdk](https://github.com/modelcontextprotocol/rust-sdk) | 4,083 | Established* | Medium | Official Rust MCP SDK | P1 |
| [rust-mcp-stack/rust-mcp-sdk](https://github.com/rust-mcp-stack/rust-mcp-sdk) | 199 | Review needed | Unassessed | Rust MCP SDK with reported conformance evidence | Reference / later |
| [modelcontextprotocol/modelcontextprotocol](https://github.com/modelcontextprotocol/modelcontextprotocol) | — (unverified) | Unverified | Unassessed | MCP standard and specification | Reference / later |
| [modelcontextprotocol/servers](https://github.com/modelcontextprotocol/servers) | — (unverified) | Unverified | Unassessed | MCP server examples | Reference / later |
| [modelcontextprotocol/java-sdk](https://github.com/modelcontextprotocol/java-sdk) | — (unverified) | Unverified | Unassessed | mcp server infrastructure | Reference / later |
| [modelcontextprotocol/csharp-sdk](https://github.com/modelcontextprotocol/csharp-sdk) | — (unverified) | Unverified | Unassessed | mcp server infrastructure | Reference / later |
| [modelcontextprotocol/kotlin-sdk](https://github.com/modelcontextprotocol/kotlin-sdk) | — (unverified) | Unverified | Unassessed | mcp server infrastructure | Reference / later |
| [modelcontextprotocol/swift-sdk](https://github.com/modelcontextprotocol/swift-sdk) | — (unverified) | Unverified | Unassessed | mcp server infrastructure | Reference / later |
| [punkpeye/awesome-mcp-servers](https://github.com/punkpeye/awesome-mcp-servers) | — (unverified) | Unverified | Unassessed | mcp server infrastructure | Reference / later |
| [qdrant/mcp-server-qdrant](https://github.com/qdrant/mcp-server-qdrant) | — (unverified) | Unverified | Unassessed | mcp server infrastructure | Reference / later |
| [docling-project/docling-mcp](https://github.com/docling-project/docling-mcp) | — (unverified) | Unverified | Unassessed | mcp server infrastructure | Reference / later |

*Established = operationally plausible candidate, subject to your own independent security, version, license and capability testing.*

### Agent harness / frameworks — 28 projects

| Project | GitHub stars | Production readiness | Assurance contribution | Strongest niche | Priority |
|---|---:|---|---|---|---|
| [langgenius/dify](https://github.com/langgenius/dify) | 160,193 | Review needed | Unassessed | agent harness / frameworks | Reference / later |
| [langchain-ai/langchain](https://github.com/langchain-ai/langchain) | 148,858 | Established* | Unassessed | agent harness / frameworks | Reference / later |
| [infiniflow/ragflow](https://github.com/infiniflow/ragflow) | 93,325 | Established* | Unassessed | Document-centric RAG and knowledge compilation | Reference / later |
| [microsoft/autogen](https://github.com/microsoft/autogen) | 61,670 | Established* | Unassessed | agent harness / frameworks | Reference / later |
| [crewAIInc/crewAI](https://github.com/crewAIInc/crewAI) | 60,403 | Review needed | Unassessed | agent harness / frameworks | Reference / later |
| [run-llama/llama_index](https://github.com/run-llama/llama_index) | 52,779 | Established* | Unassessed | agent harness / frameworks | Reference / later |
| [langchain-ai/langgraph](https://github.com/langchain-ai/langgraph) | 44,308 | Established* | Unassessed | Stateful graph-driven agent orchestration | P1 |
| [stanfordnlp/dspy](https://github.com/stanfordnlp/dspy) | 38,882 | Review needed | Unassessed | agent harness / frameworks | Reference / later |
| [huggingface/smolagents](https://github.com/huggingface/smolagents) | 30,184 | Review needed | Unassessed | agent harness / frameworks | Reference / later |
| [mastra-ai/mastra](https://github.com/mastra-ai/mastra) | 29,268 | Review needed | Unassessed | agent harness / frameworks | Reference / later |
| [microsoft/semantic-kernel](https://github.com/microsoft/semantic-kernel) | 28,725 | Established* | Unassessed | agent harness / frameworks | Reference / later |
| [deepset-ai/haystack](https://github.com/deepset-ai/haystack) | 26,905 | Established* | Medium | Composable retrieval pipelines and skill routing | P1 |
| [letta-ai/letta](https://github.com/letta-ai/letta) | 25,319 | Review needed | Unassessed | agent harness / frameworks | Reference / later |
| [pydantic/pydantic-ai](https://github.com/pydantic/pydantic-ai) | 20,992 | Established* | Unassessed | agent harness / frameworks | Reference / later |
| [letta-ai/letta-code](https://github.com/letta-ai/letta-code) | 3,758 | Review needed | Unassessed | Stateful coding harness and memory | Reference / later |
| [All-Hands-AI/OpenHands](https://github.com/All-Hands-AI/OpenHands) | — (unverified) | Unverified | Unassessed | agent harness / frameworks | Reference / later |
| [langchain-ai/deepagents](https://github.com/langchain-ai/deepagents) | — (unverified) | Unverified | Unassessed | agent harness / frameworks | Reference / later |
| [microsoft/agent-framework](https://github.com/microsoft/agent-framework) | — (unverified) | Unverified | Unassessed | agent harness / frameworks | Reference / later |
| [BerriAI/litellm](https://github.com/BerriAI/litellm) | — (unverified) | Unverified | Unassessed | agent harness / frameworks | Reference / later |
| [openai/openai-agents-python](https://github.com/openai/openai-agents-python) | — (unverified) | Unverified | Unassessed | agent harness / frameworks | Reference / later |
| [google/adk-python](https://github.com/google/adk-python) | — (unverified) | Unverified | Unassessed | agent harness / frameworks | Reference / later |
| [google-gemini/gemini-cli](https://github.com/google-gemini/gemini-cli) | — (unverified) | Unverified | Unassessed | agent harness / frameworks | Reference / later |
| [anthropics/claude-code](https://github.com/anthropics/claude-code) | — (unverified) | Unverified | Unassessed | agent harness / frameworks | Reference / later |
| [Aider-AI/aider](https://github.com/Aider-AI/aider) | — (unverified) | Unverified | Unassessed | agent harness / frameworks | Reference / later |
| [continuedev/continue](https://github.com/continuedev/continue) | — (unverified) | Unverified | Unassessed | agent harness / frameworks | Reference / later |
| [sst/opencode](https://github.com/sst/opencode) | — (unverified) | Unverified | Unassessed | agent harness / frameworks | Reference / later |
| [cline/cline](https://github.com/cline/cline) | — (unverified) | Unverified | Unassessed | agent harness / frameworks | Reference / later |
| [RooCodeInc/Roo-Code](https://github.com/RooCodeInc/Roo-Code) | — (unverified) | Unverified | Unassessed | agent harness / frameworks | Reference / later |

*Established = operationally plausible candidate, subject to your own independent security, version, license and capability testing.*

### Document ingest / source fidelity — 12 projects

| Project | GitHub stars | Production readiness | Assurance contribution | Strongest niche | Priority |
|---|---:|---|---|---|---|
| [opendatalab/MinerU](https://github.com/opendatalab/MinerU) | 82,970 | Review needed | Unassessed | Scientific PDF and layout parsing | Reference / later |
| [docling-project/docling](https://github.com/docling-project/docling) | 69,980 | Established* | Unassessed | Structured scholarly-document extraction | P0 |
| [jgm/pandoc](https://github.com/jgm/pandoc) | 46,781 | Established* | Unassessed | Document format conversion | Reference / later |
| [Unstructured-IO/unstructured](https://github.com/Unstructured-IO/unstructured) | 15,669 | Established* | Unassessed | document ingest / source fidelity | Reference / later |
| [apache/tika](https://github.com/apache/tika) | 4,121 | Established* | Unassessed | document ingest / source fidelity | Reference / later |
| [VikParuchuri/marker](https://github.com/VikParuchuri/marker) | — (unverified) | Unverified | Unassessed | document ingest / source fidelity | Reference / later |
| [kermitt2/grobid](https://github.com/kermitt2/grobid) | — (unverified) | Unverified | Unassessed | Scholarly document structural markup | Reference / later |
| [pymupdf/PyMuPDF](https://github.com/pymupdf/PyMuPDF) | — (unverified) | Unverified | Unassessed | document ingest / source fidelity | Reference / later |
| [pypdfium2-team/pypdfium2](https://github.com/pypdfium2-team/pypdfium2) | — (unverified) | Unverified | Unassessed | document ingest / source fidelity | Reference / later |
| [docling-project/docling-pipelines](https://github.com/docling-project/docling-pipelines) | — (unverified) | Unverified | Unassessed | document ingest / source fidelity | Reference / later |
| [OCRmyPDF/OCRmyPDF](https://github.com/OCRmyPDF/OCRmyPDF) | — (unverified) | Unverified | Unassessed | document ingest / source fidelity | Reference / later |
| [facebookresearch/nougat](https://github.com/facebookresearch/nougat) | — (unverified) | Unverified | Unassessed | document ingest / source fidelity | Reference / later |

*Established = operationally plausible candidate, subject to your own independent security, version, license and capability testing.*

### Search / vector / graphs — 19 projects

| Project | GitHub stars | Production readiness | Assurance contribution | Strongest niche | Priority |
|---|---:|---|---|---|---|
| [meilisearch/meilisearch](https://github.com/meilisearch/meilisearch) | 59,750 | Established* | Unassessed | Easy operational text search | Reference / later |
| [milvus-io/milvus](https://github.com/milvus-io/milvus) | 46,556 | Established* | Unassessed | search / vector / graphs | Reference / later |
| [facebookresearch/faiss](https://github.com/facebookresearch/faiss) | 41,246 | Established* | Unassessed | search / vector / graphs | Reference / later |
| [HKUDS/LightRAG](https://github.com/HKUDS/LightRAG) | 40,475 | Review needed | Unassessed | Lightweight graph-based retrieval | Reference / later |
| [microsoft/graphrag](https://github.com/microsoft/graphrag) | 36,528 | Review needed | Unassessed | Graph-enhanced knowledge retrieval | Reference / later |
| [qdrant/qdrant](https://github.com/qdrant/qdrant) | 35,377 | Established* | Medium | Rust vector and hybrid retrieval | P1 |
| [chroma-core/chroma](https://github.com/chroma-core/chroma) | 29,620 | Established* | Unassessed | search / vector / graphs | Reference / later |
| [typesense/typesense](https://github.com/typesense/typesense) | 27,075 | Established* | Unassessed | Operational typo-tolerant text search | Reference / later |
| [pgvector/pgvector](https://github.com/pgvector/pgvector) | 23,565 | Established* | Unassessed | PostgreSQL vector indexes | Reference / later |
| [weaviate/weaviate](https://github.com/weaviate/weaviate) | 16,934 | Established* | Unassessed | search / vector / graphs | Reference / later |
| [lancedb/lancedb](https://github.com/lancedb/lancedb) | 11,826 | Established* | Unassessed | search / vector / graphs | Reference / later |
| [tantivy-search/tantivy](https://github.com/tantivy-search/tantivy) | — (unverified) | Unverified | Unassessed | Rust full-text search/indexing | Reference / later |
| [elastic/elasticsearch](https://github.com/elastic/elasticsearch) | — (unverified) | Unverified | Unassessed | search / vector / graphs | Reference / later |
| [opensearch-project/OpenSearch](https://github.com/opensearch-project/OpenSearch) | — (unverified) | Unverified | Unassessed | search / vector / graphs | Reference / later |
| [vespa-engine/vespa](https://github.com/vespa-engine/vespa) | — (unverified) | Unverified | Unassessed | Large-scale hybrid retrieval and ranking | Reference / later |
| [redis/redis](https://github.com/redis/redis) | — (unverified) | Unverified | Unassessed | search / vector / graphs | Reference / later |
| [unum-cloud/usearch](https://github.com/unum-cloud/usearch) | — (unverified) | Unverified | Unassessed | search / vector / graphs | Reference / later |
| [Neo4j/neo4j](https://github.com/Neo4j/neo4j) | — (unverified) | Unverified | Unassessed | search / vector / graphs | Reference / later |
| [quickwit-oss/quickwit](https://github.com/quickwit-oss/quickwit) | — (unverified) | Unverified | Unassessed | search / vector / graphs | Reference / later |

*Established = operationally plausible candidate, subject to your own independent security, version, license and capability testing.*

### Persistent agent memory — 6 projects

| Project | GitHub stars | Production readiness | Assurance contribution | Strongest niche | Priority |
|---|---:|---|---|---|---|
| [mem0ai/mem0](https://github.com/mem0ai/mem0) | 68,261 | Review needed | Unassessed | Persistent agent memory | Reference / later |
| [topoteretes/cognee](https://github.com/topoteretes/cognee) | 32,994 | Review needed | Unassessed | persistent agent memory | Reference / later |
| [getzep/graphiti](https://github.com/getzep/graphiti) | 32,426 | Review needed | Unassessed | Temporal knowledge graph memory | Reference / later |
| [getzep/zep](https://github.com/getzep/zep) | 4,985 | Review needed | Unassessed | persistent agent memory | Reference / later |
| [MemTensor/MemOS](https://github.com/MemTensor/MemOS) | — (unverified) | Unverified | Unassessed | persistent agent memory | Reference / later |
| [agno-agi/agno](https://github.com/agno-agi/agno) | — (unverified) | Unverified | Unassessed | persistent agent memory | Reference / later |

*Established = operationally plausible candidate, subject to your own independent security, version, license and capability testing.*

### Sequential workflow / recovery — 11 projects

| Project | GitHub stars | Production readiness | Assurance contribution | Strongest niche | Priority |
|---|---:|---|---|---|---|
| [n8n-io/n8n](https://github.com/n8n-io/n8n) | 209,325 | Established* | Unassessed | sequential workflow / recovery | Reference / later |
| [apache/airflow](https://github.com/apache/airflow) | 47,345 | Established* | Unassessed | sequential workflow / recovery | Reference / later |
| [kestra-io/kestra](https://github.com/kestra-io/kestra) | 30,115 | Established* | Unassessed | sequential workflow / recovery | Reference / later |
| [temporalio/temporal](https://github.com/temporalio/temporal) | 24,127 | Established* | Medium | Durable, replayable workflow execution | P1 |
| [PrefectHQ/prefect](https://github.com/PrefectHQ/prefect) | 24,106 | Established* | Unassessed | Operationally managed Python workflows | Reference / later |
| [windmill-labs/windmill](https://github.com/windmill-labs/windmill) | 18,357 | Established* | Unassessed | sequential workflow / recovery | Reference / later |
| [dagster-io/dagster](https://github.com/dagster-io/dagster) | 16,361 | Established* | Unassessed | sequential workflow / recovery | Reference / later |
| [Arize-ai/phoenix](https://github.com/Arize-ai/phoenix) | 12,096 | Established* | Medium | Open-source LLM observability | Reference / later |
| [temporalio/sdk-python](https://github.com/temporalio/sdk-python) | — (unverified) | Unverified | Unassessed | sequential workflow / recovery | Reference / later |
| [hatchet-dev/hatchet](https://github.com/hatchet-dev/hatchet) | — (unverified) | Unverified | Unassessed | sequential workflow / recovery | Reference / later |
| [inngest/inngest](https://github.com/inngest/inngest) | — (unverified) | Unverified | Unassessed | sequential workflow / recovery | Reference / later |

*Established = operationally plausible candidate, subject to your own independent security, version, license and capability testing.*

### Assurance / policy / evaluation — 19 projects

| Project | GitHub stars | Production readiness | Assurance contribution | Strongest niche | Priority |
|---|---:|---|---|---|---|
| [langfuse/langfuse](https://github.com/langfuse/langfuse) | 36,859 | Established* | Medium | Agent execution tracing and cost tracking | P1 |
| [mlflow/mlflow](https://github.com/mlflow/mlflow) | 28,625 | Established* | Medium | assurance / policy / evaluation | Reference / later |
| [promptfoo/promptfoo](https://github.com/promptfoo/promptfoo) | 26,725 | Established* | Medium | Agent evaluation and adversarial testing | P1 |
| [confident-ai/deepeval](https://github.com/confident-ai/deepeval) | 19,236 | Review needed | Medium | LLM and RAG evaluations | Reference / later |
| [open-policy-agent/opa](https://github.com/open-policy-agent/opa) | 12,419 | Established* | High | Explicit policy-as-code with Rego | P1 |
| [open-telemetry/opentelemetry-collector](https://github.com/open-telemetry/opentelemetry-collector) | 7,728 | Review needed | Unassessed | assurance / policy / evaluation | Reference / later |
| [NVIDIA-NeMo/Guardrails](https://github.com/NVIDIA-NeMo/Guardrails) | 7,409 | Review needed | Unassessed | assurance / policy / evaluation | Reference / later |
| [ProtectAI/llm-guard](https://github.com/ProtectAI/llm-guard) | 3,219 | Archived | Unassessed | assurance / policy / evaluation | Reference / later |
| [cedar-policy/cedar](https://github.com/cedar-policy/cedar) | 1,831 | Established* | High | Typed authorization policies | Reference / later |
| [casbin/casbin](https://github.com/casbin/casbin) | — (unverified) | Unverified | High | RBAC/ABAC policy enforcement | Reference / later |
| [guardrails-ai/guardrails](https://github.com/guardrails-ai/guardrails) | — (unverified) | Unverified | Unassessed | assurance / policy / evaluation | Reference / later |
| [truera/trulens](https://github.com/truera/trulens) | — (unverified) | Unverified | Unassessed | assurance / policy / evaluation | Reference / later |
| [openai/evals](https://github.com/openai/evals) | — (unverified) | Unverified | Unassessed | assurance / policy / evaluation | Reference / later |
| [UKGovernmentBEIS/inspect_ai](https://github.com/UKGovernmentBEIS/inspect_ai) | — (unverified) | Unverified | Medium | Audit-friendly model evaluations | Reference / later |
| [grafana/grafana](https://github.com/grafana/grafana) | — (unverified) | Unverified | Unassessed | assurance / policy / evaluation | Reference / later |
| [explodinggradients/ragas](https://github.com/explodinggradients/ragas) | — (unverified) | Unverified | Unassessed | assurance / policy / evaluation | Reference / later |
| [microsoft/presidio](https://github.com/microsoft/presidio) | — (unverified) | Unverified | Unassessed | assurance / policy / evaluation | Reference / later |
| [invariantlabs-ai/invariant](https://github.com/invariantlabs-ai/invariant) | — (unverified) | Unverified | Unassessed | assurance / policy / evaluation | Reference / later |
| [JaidedAI/EasyOCR](https://github.com/JaidedAI/EasyOCR) | — (unverified) | Unverified | Unassessed | assurance / policy / evaluation | Reference / later |

*Established = operationally plausible candidate, subject to your own independent security, version, license and capability testing.*

### Compiler / CPG / translation — 15 projects

| Project | GitHub stars | Production readiness | Assurance contribution | Strongest niche | Priority |
|---|---:|---|---|---|---|
| [llvm/llvm-project](https://github.com/llvm/llvm-project) | 41,295 | Established* | High | Authoritative C/C++ AST and compiler infrastructure | P1 |
| [tree-sitter/tree-sitter](https://github.com/tree-sitter/tree-sitter) | 27,354 | Established* | High | Incremental multi-language parsing | P0 |
| [semgrep/semgrep](https://github.com/semgrep/semgrep) | 17,401 | Established* | Unassessed | compiler / cpg / translation | Reference / later |
| [rust-lang/rust-analyzer](https://github.com/rust-lang/rust-analyzer) | 16,964 | Established* | High | Rust source semantic analysis | P0 |
| [github/codeql](https://github.com/github/codeql) | 10,290 | Established* | High | Semantic code queries and graph analysis | P1 |
| [immunant/c2rust](https://github.com/immunant/c2rust) | 4,832 | Review needed | Unassessed | Conservative C-to-Rust transpilation | Reference / later |
| [joernio/joern](https://github.com/joernio/joern) | 3,614 | Established* | High | Code property graphs | P1 |
| [facebookresearch/TransCoder](https://github.com/facebookresearch/TransCoder) | 1,728 | Archived | Unassessed | compiler / cpg / translation | Reference / later |
| [Cpp2Rust/cpp2rust](https://github.com/Cpp2Rust/cpp2rust) | 318 | Review needed | Unassessed | Research C++-to-Rust migration | Reference / later |
| [rust-lang/rust](https://github.com/rust-lang/rust) | — (unverified) | Established* | Unassessed | compiler / cpg / translation | Reference / later |
| [python/cpython](https://github.com/python/cpython) | — (unverified) | Unverified | Unassessed | compiler / cpg / translation | Reference / later |
| [golang/go](https://github.com/golang/go) | — (unverified) | Unverified | Unassessed | compiler / cpg / translation | Reference / later |
| [eclipse-jdt/eclipse.jdt.core](https://github.com/eclipse-jdt/eclipse.jdt.core) | — (unverified) | Unverified | Unassessed | compiler / cpg / translation | Reference / later |
| [srcML/srcML](https://github.com/srcML/srcML) | — (unverified) | Unverified | Unassessed | compiler / cpg / translation | Reference / later |
| [kastor-io/konveyor-analyzer-lsp](https://github.com/kastor-io/konveyor-analyzer-lsp) | — (unverified) | Unverified | Unassessed | compiler / cpg / translation | Reference / later |

*Established = operationally plausible candidate, subject to your own independent security, version, license and capability testing.*

### Formal verification / Rust — 11 projects

| Project | GitHub stars | Production readiness | Assurance contribution | Strongest niche | Priority |
|---|---:|---|---|---|---|
| [rust-lang/miri](https://github.com/rust-lang/miri) | 6,707 | Established* | High | formal verification / rust | Reference / later |
| [model-checking/kani](https://github.com/model-checking/kani) | 3,627 | Established* | High | Rust bounded model checking | P0 |
| [verus-lang/verus](https://github.com/verus-lang/verus) | 3,536 | Review needed | High | Deductive Rust verification | Reference / later |
| [creusot-rs/creusot](https://github.com/creusot-rs/creusot) | 1,951 | Review needed | High | Rust deductive verification | Reference / later |
| [diffblue/cbmc](https://github.com/diffblue/cbmc) | 1,157 | Review needed | High | formal verification / rust | Reference / later |
| [GaloisInc/crucible](https://github.com/GaloisInc/crucible) | 781 | Review needed | Unassessed | formal verification / rust | Reference / later |
| [GaloisInc/crux](https://github.com/GaloisInc/crux) | 1 | Review needed | Unassessed | formal verification / rust | Reference / later |
| [bolero-rs/bolero](https://github.com/bolero-rs/bolero) | — (unverified) | Unverified | Unassessed | Property-testing harnesses and backends | Reference / later |
| [viperproject/prusti-dev](https://github.com/viperproject/prusti-dev) | — (unverified) | Unverified | Unassessed | formal verification / rust | Reference / later |
| [GaloisInc/saw-script](https://github.com/GaloisInc/saw-script) | — (unverified) | Unverified | Unassessed | formal verification / rust | Reference / later |
| [facebookresearch/pyrefly](https://github.com/facebookresearch/pyrefly) | — (unverified) | Unverified | Unassessed | formal verification / rust | Reference / later |

*Established = operationally plausible candidate, subject to your own independent security, version, license and capability testing.*

### CGP / Rust metaprogramming — 7 projects

| Project | GitHub stars | Production readiness | Assurance contribution | Strongest niche | Priority |
|---|---:|---|---|---|---|
| [contextgeneric/cgp](https://github.com/contextgeneric/cgp) | — (unverified) | Unverified | Unassessed | cgp / rust metaprogramming | Reference / later |
| [jeffersonlamb/derive-deftly](https://github.com/jeffersonlamb/derive-deftly) | — (unverified) | Unverified | Unassessed | cgp / rust metaprogramming | Reference / later |
| [dtolnay/syn](https://github.com/dtolnay/syn) | — (unverified) | Unverified | Unassessed | cgp / rust metaprogramming | Reference / later |
| [dtolnay/quote](https://github.com/dtolnay/quote) | — (unverified) | Unverified | Unassessed | cgp / rust metaprogramming | Reference / later |
| [dtolnay/proc-macro2](https://github.com/dtolnay/proc-macro2) | — (unverified) | Unverified | Unassessed | cgp / rust metaprogramming | Reference / later |
| [bevyengine/bevy](https://github.com/bevyengine/bevy) | — (unverified) | Established* | Unassessed | Rust ECS and game engine | Reference / later |
| [PyO3/pyo3](https://github.com/PyO3/pyo3) | — (unverified) | Established* | Unassessed | Python/Rust interop | Reference / later |

*Established = operationally plausible candidate, subject to your own independent security, version, license and capability testing.*

### Architecture description — 6 projects

| Project | GitHub stars | Production readiness | Assurance contribution | Strongest niche | Priority |
|---|---:|---|---|---|---|
| [mermaid-js/mermaid](https://github.com/mermaid-js/mermaid) | 90,969 | Established* | Unassessed | Documentation-native diagrams | Reference / later |
| [plantuml/plantuml](https://github.com/plantuml/plantuml) | 13,392 | Review needed | Unassessed | architecture description | Reference / later |
| [likec4/likec4](https://github.com/likec4/likec4) | 6,004 | Review needed | Unassessed | Architecture-as-code and C4 diagrams | Reference / later |
| [arc42/arc42-template](https://github.com/arc42/arc42-template) | 1,317 | Review needed | Unassessed | architecture description | Reference / later |
| [structurizr/dsl](https://github.com/structurizr/dsl) | — (unverified) | Unverified | Unassessed | architecture description | Reference / later |
| [structurizr/java](https://github.com/structurizr/java) | — (unverified) | Unverified | Unassessed | architecture description | Reference / later |

*Established = operationally plausible candidate, subject to your own independent security, version, license and capability testing.*

## Special caveats

- The original Deep Research summary highlighted **RAGFlow, LangGraph, Qdrant and Haystack** as prominent context/agent infrastructure. None replaces a deterministic source-to-target completeness checker.
- Unlimiformer is deliberately excluded from the production baseline: it requires model-level integration unavailable for hosted Codex, and was previously observed to have no recent main-branch development.
- `facebookresearch/TransCoder` and `ProtectAI/llm-guard` were reported as archived via GitHub API in this recovery. They remain useful historical references but are poor defaults for new production dependency choices.
- For `GaloisInc/crux`, the queried repository contained a different/limited project than the Rust Crux verification ecosystem expected by name. **Do not treat this row as verified Crux capability** until the correct canonical upstream is established.
- An API error or unverified repo path is never evidence that a project is nonexistent or unsafe; it is an unknown. Verify before using it.
- Aegis is its own governing implementation; a project named `Aegis` elsewhere is not interchangeable with https://github.com/QuasarRay/Aegis.

## Data export

See `projects.csv` and `projects.json` for full catalog, evidence-status fields and sortable star counts. These distinguish verified numerical counts from missing metadata.
