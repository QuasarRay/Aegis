# Architecture B: expanded native Rust infrastructure

Use this only after Architecture A demonstrates a concrete measurable need.

```text
Immutable corpus / source and tests
        -> extractor adapters -> provenance store
        -> Tantivy exact index + Qdrant hybrid index
        -> ranker/eval suite -> read-only RMCP
                     |
       Cedar per-action capability gates
                     |
Restate or durable queue -> global single-agent lease
                     |
   Provider adapter -> Codex Goal/Plan executor
                     |
 Source inventories -> correspondence graph
                     |
 Existing-test-derived Kani harnesses -> original/target differential oracle
                     |
 Signatures/attestation + trace/evidence ledger
                     |
          later: CPGSchema and ISO 42010
```

`AgentRequest`: immutable work ID, source/test revision, lifecycle state, requested effort/budget, active lease token, allowed tool set. `RetrievalHit`: source_sha, doc_version, section id, source byte-span and optional page bbox, extraction_status, excerpt, citation. `HarnessReceipt`: exact original test locator+hash, derived contract hash, rust harness source+hash, invocation parameters, Kani bound, result, coverage, counterexample path. `CorrespondenceClaim`: one canonical source object -> one Rust target aggregate, all members individually mapped and reviewed.

Make every adapter a replaceable Rust trait boundary. Where CGP is used, keep canonical audit APIs independent of provider resolution. Avoid building a new meta-type system during the first deployment. Entire stack does not become "fully pure Rust" if Clang, CUDA, ONNX Runtime, hosted Codex, external GPUs or other dependencies remain; use a transparent component bill of materials.
