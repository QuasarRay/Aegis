# Classification methodology and evidence limits

**Snapshot:** 2026-11-02. Primary sources: official GitHub READMEs/repository API, official Rust/MCP/Kani documentation, and the Deep Research completion summary. Rust purity and production-readiness labels are engineering assessments—not independent security reviews.

## Purity labels

1. **Rust-primary (not audited pure Rust)**: GitHub REST reports primary language Rust. This alone says nothing about C libraries, JS UI, Python CLIs, ONNX Runtime, tokenizers, or hosted APIs used at runtime.
2. **Rust-facing / hybrid**: substantial Rust component but wrappers, FFI, runtime, C/C++ parser, or UI prevent a strict all-Rust description.
3. **Rust claimed / not independently confirmed**: candidate from previous research whose GitHub metadata was not successfully checked.
4. **Non-Rust / comparator**: intentionally included to show why it fails the user's Rust-only condition. Do not select it as a native replacement.

## Readiness labels

- **Established component**: mature, documented and active subsystem *in its niche*. Does not automatically certify an end-to-end agent platform.
- **Maintained/viable candidate**: promising but must be subjected to an Aegis-specific pilot, compatibility checks and evidence.
- **Exploratory/partial**: research, early implementation, modest adoption or unavailable independent deployment evidence.

## Assurance labels

- Formal capability has explicit assumptions/bounds: Kani is bounded verification, Verus/Creusot need proof specifications, Miri detects certain undefined behaviors when code is interpreted.
- Policy-as-code authorization (Cedar/Regorus) constrains allowed actions, but cannot guarantee safe outputs or prevent all prompt-injection attacks.
- Security scanning, supply-chain audits and semver analysis are distinct from functional semantic equivalence.
- Observability, model self-evaluation, RAG citations and GitHub stars are not correctness proofs.

## Ranking

Exact GitHub star counts are provided only when retrieved via GitHub REST API on 2026-11-02; otherwise recorded as `N/V`. Historic pushed-at dates reflect GitHub metadata, not necessarily latest stable releases or project health. A fork count or number of stars cannot establish production readiness, feature equivalence, license safety or suitability to high-assurance migrations.

## Research completeness warning

No finite search guarantees literally that *no Rust project was missed*. The attached original was not recoverable in this session. This bundle is a newly assembled, transparent substitute, **not** a claim that an unseen original 72-entry ZIP was reconstructed verbatim.
