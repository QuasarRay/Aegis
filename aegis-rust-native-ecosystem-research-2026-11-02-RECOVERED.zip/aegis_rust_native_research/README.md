# Rust-native Aegis ecosystem research — recovered replacement

**Snapshot: 2026-11-02. Status: RECONSTRUCTED FROM AVAILABLE RESEARCH FINDINGS, NOT ORIGINAL ZIP.**

The previous Deep Research report said it assessed **72 Rust-native projects** and provided a ZIP at `sandbox:/mnt/data/aegis-rust-native-ecosystem-research-2026-11-02.zip`. The actual original ZIP was **not present in the accessible session**, and no valid original bytes could be recovered. This **new** archive was created locally from the completed report's named projects and search findings, the earlier all-language baseline ZIP, and checked GitHub repository metadata. It contains 91 unique candidate repositories, including clearly flagged non-Rust or mixed-language comparators. It is **not** a reproduction of the original 72-entry report, and its checksum will differ.

We verified 82 GitHub star counts during recovery, as of 2026-11-02. Star counts are historical snapshots, not rankings of correctness; all candidates require separate security, license, maintenance and operational assessment. "Rust-primary" reflects GitHub's dominant language, **not proof of full Rust purity**. No complete source code or production audits were performed. A few non-verified candidate links may need correction. The project catalog separates such cases.

The user's strict goal of *zero information loss* is interpreted as retaining exact document bytes and reversible provenance, **not** guaranteeing model attention to every token. The user's strict *one agent at a time* rule remains mandatory. No automation may initiate a second LLM agent concurrently.

## Contents

- `00-executive-summary.md` — key findings and deployment decision.
- `01-scope-scoring.md` — how native-Rust purity, readiness, assurance, stars are evaluated.
- `02-all-projects.md` — complete categorized index with 91 projects and URLs.
- `03-cross-language-parity.md` — non-Rust incumbents versus Rust alternatives.
- `04-agent-harnesses-and-skills.md` — Rust agents, provider adapters, skills.
- `05-mcp-and-tool-gateways.md` — native MCP SDK, gateways and policy boundaries.
- `06-retrieval-search-and-memory.md` — books, retrieval, context, durable memory.
- `07-document-processing.md` — high-fidelity PDF and documentation processing.
- `08-orchestration-and-durable-state.md` — sequential agent control and idempotency.
- `09-authorization-and-assurance.md` — policies, verification, sandboxing, supply chain.
- `10-one-to-one-migration.md` — source graph, Rust target audit, Kani test-derived harnesses.
- `11-architecture-minimal.md` — smallest safe native-Rust pilot.
- `12-architecture-extended.md` — advanced modular architecture and interfaces.
- `13-integration-roadmap.md` — phases, gates and rollback.
- `14-open-gaps-and-risks.md` — what Rust does **not** solve yet.
- `15-sources-and-verification.md` — source provenance and bibliography.
- `tables/projects.csv`, `tables/projects.json`, `tables/star-ranked.csv` — searchable catalog.
- `SHA256SUMS.txt` — checksums of contents.

Read `01-scope-scoring.md` before treating any star count or label as a production certification. The original all-language ZIP was used only as a **comparison baseline**, not substituted for the Rust-specific result.
