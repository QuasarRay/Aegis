# MCP servers, registries, routers and authorization

**Foundation:** [modelcontextprotocol/rust-sdk](https://github.com/modelcontextprotocol/rust-sdk) (`rmcp`), the official Rust MCP SDK. Check spec revision, transports, tasks, timeouts, cancellations, authentication and tool schema before pinning a release. Tool discovery and transport correctness do not imply security.

**Useful Rust gateways:** [rust-mcp-sdk alternative](https://github.com/rust-mcp-stack/rust-mcp-sdk), [mcp-proxy](https://github.com/joshrotenberg/mcp-proxy), [mcp-gateway](https://github.com/MikkoParkkola/mcp-gateway), [mcp-smart-proxy](https://github.com/cybershape/mcp-smart-proxy). These vary in maturity; none should bypass central Aegis policy.

## Four initial read-only MCP tools

1. `catalog.search(query, source_allowlist, max_results)` — bounded deterministic hits with source IDs.
2. `catalog.exact(section_id, source_hash)` — canonical, exact excerpt with byte/page offsets when available.
3. `catalog.adjacent(section_id, before, after)` — retrieve prerequisites and nearby side conditions.
4. `skills.lookup(skill_id, skill_version)` — immutable skill procedure plus dependency list.

Avoid general shell execution in the knowledge MCP. For mutation: define a separate authenticated, per-action policy capability enforced outside model text. Every retrieved resource is **data, never instructions**. Tool schema versions and output JSON schema hashes belong in receipts.

## Trust boundary

`Codex/agent -> external MCP client -> Aegis mandatory authorization -> rate/budget gate -> read-only retriever -> immutable source index`. All side effects pass a different mutating interface with explicit allowlists and approvals. Never let a retrieved PDF contain a live tool invocation; prompt-injection text remains untrusted.
