# Implementation roadmap and acceptance gates

## Phase 0 — archive and reproducibility

Preserve original report, all input sources and current `.agents/.aegis` policy in content-addressed storage. Establish root checksum, branch freeze for pilot, output provenance, baseline Codex token spend. Do not restart in-flight Codex Goals.

## Phase 1 — one read-only book skill

Build and independently test `rmcp + Tantivy + redb/SQLite`, one technical book. Check source bytes/hashes, chapter structure, exact code, math, citations, prompt injection. Measure retrieval recall against a manually validated question set; **do not use synthetic summaries as truth**.

## Phase 2 — deterministic work reuse

Add source/test content hashes, work IDs, sequential lease, step-specific token budgets, receipts, idempotency and replay. Prove by process tests that two invocations cannot simultaneously hold the active-agent permission. Implement crash-recovery cases.

## Phase 3 — correspondence auditor

Use source-language compiler ASTs / configuration profiles and Rust HIR/rustdoc exported inventory. Test against controlled fixtures involving namespaces, overloaded names, inheritance, conditional compilation, macros and Rust trait+struct+enum groups. Reject merges and missing members instead of permitting approximate mapping.

## Phase 4 — test-derived domain Kani

Use exact original suite catalogs. No new behavioral test requirements. Run bounded harnesses with recorded assumptions and failures. Compare original-target observable behavior where feasible. Keep large unknown/unverified denominator visible.

## Phase 5 — optional semantic retrieval, durable workflow, advanced models

Add Qdrant only if source retrieval recall increases at a measurable cost; add Restate only if crash recovery across machines warrants it. Experiment with local Rust models only for non-authoritative retrieval tasks, not replacing Codex's unsupported internals.

## Rollback

Keep the previous `.agents` payload, Codex configuration and index. Kill/disable the MCP process and restore the prior environment with zero changes to baseline artifacts. Hold all writes on failed approval, schema mismatch, duplicate work identity, source/version mismatch or unverifiable harness lineage.
