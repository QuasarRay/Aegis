# Native Rust document processing and source fidelity

Candidates: `lopdf` (low-level PDF parser); `pdf-extract` (text); `docparse-rs` (structured/page+bbox output); `edgeparse` (born-digital PDFs); `docling-rs` (unofficial Docling port); `comrak` and `pulldown-cmark` (Markdown AST); `typst` and `mdBook` (published docs). **Do not infer production-quality parser parity from a self-reported README benchmark.**

Benchmark the actual books: **Learning Rust With Entirely Too Many Linked Lists**, **Rust Atomics and Locks**, CGP book and docs, Kani Book, derive-deftly, Bevy, PyO3, Agones, Bolero, Rust Book, Rust Reference. Compare chapter hierarchy, inline code, Unicode, formulas, tables, footnotes and hyperlinks. Produce per-page extraction confidence and a manifest listing sections requiring human review.

Record source content hashes and never overwrite originals. For docs scraped from websites, pin version, commit SHA or archived source. Mathematical expressions and compiler examples must survive character-perfect where fidelity is necessary; if a parser cannot do so, mark the section **not yet indexed** instead of silently offering an incorrect answer.

If high-fidelity native extraction cannot be demonstrated, retaining a mixed-language Docling offline build step **is safer** than insisting on a Rust-only ingestion component that corrupts proof rules. The serving/search/MCP side can still be fully native Rust.
