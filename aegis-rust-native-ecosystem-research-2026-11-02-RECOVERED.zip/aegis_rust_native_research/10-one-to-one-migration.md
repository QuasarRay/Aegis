# Exact one-to-one cross-language to Rust migration

Aegis should construct a **canonical source inventory** independent of any LLM-generated target inventory. For C/C++ prefer compiler-aware Clang tooling where configuration and macros matter; use language-specific Java/Go/Python parsers and runtime tracing as appropriate. AST-grep and tree-sitter-graph can help gather syntactic facts, but do not supply complete semantic type resolution. `rust-analyzer` and `rustdoc-types` provide target-side inventory and API comparison. `c2rust` and `cpp2rust` are translators/research tools, not a complete substitute for one-to-one audit.

## Mandatory mapping

`source_key = (repo_revision, language, compilation/config context, source_path, span, qualified_type_name, declaration_id)`.

`target_key = (repo_revision, crate, module_path, nominal_name, trait_impl_member_group, cfg_profile)`.

A one-to-one **source-object** may map to a bounded Rust aggregate containing a trait + struct + enum + impl blocks. That aggregate has exactly one canonical group ID. No group can claim multiple unrelated source identities; no source identity may disappear by being merged into a generic trait/util or dynamic registry. Fields, methods, overloads, inheritance/implements edges, ownership, events, metadata and visibility each require correspondence assertions.

Catalog states: `unmapped`, `mapped-structure-only`, `mapped-behavior-unverified`, `covered-by-original-test`, `kani-harness-proved-bounded`, `differentially-verified`, `unresolved-source`, `verified`. Denominators must include all original objects/tests for each configuration; the system must not silently reduce scope.

## Original-test-derived harness rule

Only existing original tests authorize first-phase Kani/Bolero domain harnesses. Each test: preserve original bytes/name, derive input/output behavior, record assumptions, instantiate Rust harness, check bounded assertions, report coverage/unreachability, optionally differentially execute original and target. A harness can only prove the property it encodes. Not every full external E2E flow is amenable to bounded Kani execution; when infeasible, document the gap rather than claiming it is proven.

Pervasive CGP is a **target architecture constraint** subordinate to exact original naming, object identity and user-visible behavior. Providers/delegations cannot hide canonical public objects; validate macro-expanded target identities. Generate CPGSchema and ISO/IEC/IEEE 42010 docs only after the scoped implementation passes stated gates.
