# Gaps, risk register and non-goals

| Risk / gap | Consequence | Mitigation |
|---|---|---|
| Original completed ZIP missing | Cannot provide byte-for-byte original | This reconstructed artifact is clearly labeled and checked |
| Stars mistaken for production maturity | Unsafe dependency | Require CI/build, releases, supply-chain and deployment evidence |
| Rust-primary misread as pure Rust | Native-only mandate violated | Audit Cargo dependency graph, FFI, runtime, UI, external executables |
| New research repo oversells itself | False parity claims | Reproduce tests and benchmark against actual books/code |
| PDF extraction loses math or layout | Incorrect formal rules | Preserve raw source bytes, mark failed sections, compare manually |
| Prompt injection in retrieved book | Tool/policy compromise | Source text never instructions; mandatory Cedar gate and read-only MCP |
| Two agent processes run | Violates Aegis hard rule | Durable lease with fencing, process fault injection |
| Unreachable Kani paths counted as proved | False assurance | Separate reachable, passed, unreachable, inconclusive, timeout results |
| Missing original C++ configuration/macro expansions | Incomplete nominal map | Config-aware AST inventory and explicit denominator |
| CGP meta-programming erases identities | One-to-one violation | Expand macros and audit correspondence against canonical source keys |
| Providers do not expose max reasoning | False guarantee | Record requested/effective knobs, reject unsupported setting |
| Entire framework rewrite | Token waste, regressions, duplicate work | Incremental read-only integration and measured acceptance criteria |
| Closed Codex model attention inaccessible | Unlimiformer integration infeasible | MCP retrieval, not internal attention modification |
| Lack of independent Python ecosystem parity | Underimplemented integrations | Keep narrow Rust scope or use best mixed-language backend where necessary |
| Licensing obligations (AGPL, book copyright) | Distribution or operational constraints | Per-repo license review and private book index; distribute pointers not protected text |

Production-grade is a **deployment claim**, not a property proven by Rust compilation. Aegis's strongest approach is independent source-identity audit and original-test-derived executable evidence, rather than optimizing only the model, number of agents, or degree of abstraction.
