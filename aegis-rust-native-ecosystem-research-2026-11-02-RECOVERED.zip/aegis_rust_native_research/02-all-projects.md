# Complete Rust ecosystem project atlas

Catalog size: **91 unique repository references**; **82 GitHub metadata checks**. Some are explicitly hybrid/non-Rust comparators and some candidate URLs remain unverified. Each project links to its repository.

| category | project | stars | star_band | primary_language | strongest_niche | aegis_fit |
|---|---|---|---|---|---|---|
| 01_agents_provider_harnesses | openai/codex | 132800 | 50k+ | Rust | Hosted-model coding agent and Rust CLI | P0; keep Codex as executor |
| 01_agents_provider_harnesses | sigoden/aichat | 10534 | 10k-49,999 | Rust | Mature CLI AI agent and RAG | P2; reference implementation |
| 01_agents_provider_harnesses | 0xPlaygrounds/rig | 9040 | 1k-9,999 | Rust | Modular Rust LLM SDK and Bevy plugin coding agent | P1; modular experiment |
| 01_agents_provider_harnesses | jeremychone/rust-genai | 923 | 100-999 | Rust | Model/provider abstraction | P0; candidate for provider adapter |
| 01_agents_provider_harnesses | bosun-ai/swiftide | 801 | 100-999 | Rust | RAG/agent pipelines, ingestion and retrieval | P1; compare against Rig |
| 01_agents_provider_harnesses | liquidos-ai/AutoAgents | 772 | 100-999 | Rust | Native agent framework and orchestration | P2; evaluation only |
| 01_agents_provider_harnesses | zavora-ai/adk-rust | 737 | 100-999 | Rust | Full-featured modular agent framework | P1; later controlled pilot |
| 01_agents_provider_harnesses | ldclabs/anda | 447 | 100-999 | Rust | Composable Rust agent runtime | P2; evaluation only |
| 01_agents_provider_harnesses | Muvon/octolib | 9 | 0-99 | Rust | Multi-provider Rust client/cost accounting | P2; compare adapter options |
| 01_agents_provider_harnesses | getlatentic/agent-harness | 2 | 0-99 | Rust | Common Rust adapter for existing CLI agents | P2; small prototype |
| 01_agents_provider_harnesses | CHKDSKLabs/Mutagen | 0 | 0-99 | Rust | Rust governing harness for coding agents | P2; architecture reference |
| 01_agents_provider_harnesses | AstraBert/microagents | N/V | unverified | not checked | Agent core and skill-loading crates | Research only |
| 01_agents_provider_harnesses | Dicklesworthstone/pi_agent_rust | N/V | unverified | not checked | Rust coding agent with context compaction | P2; context study |
| 01_agents_provider_harnesses | avala-ai/agent-code | N/V | unverified | not checked | Native terminal coding agent | P2; harness candidate |
| 01_agents_provider_harnesses | contextbridge/aether | N/V | unverified | not checked | Rust coding harness with explicit context control | P2; context study |
| 02_skills_mcp | modelcontextprotocol/rust-sdk | 4083 | 1k-9,999 | Rust | Official RMCP client/server SDK | P0; MCP server foundation |
| 02_skills_mcp | leonardomso/rust-skills | 662 | 100-999 | Python | Rust programming SKILL.md content catalog | Reference material |
| 02_skills_mcp | rust-mcp-stack/rust-mcp-sdk | 199 | 100-999 | Rust | Alternative Rust MCP SDK | P2; comparison reference |
| 02_skills_mcp | MikkoParkkola/mcp-gateway | 85 | 0-99 | Rust | Context-budgeted dynamic MCP tool catalog | P2; token-budget experiments |
| 02_skills_mcp | Brainwires/project-rag | 33 | 0-99 | Rust | MCP agent-facing codebase search | P1; reference/pilot |
| 02_skills_mcp | joshrotenberg/mcp-proxy | 18 | 0-99 | Rust | Rust configurable MCP reverse proxy | P2; stage behind tests |
| 02_skills_mcp | Govcraft/agent-skills | 16 | 0-99 | Rust | Rust Agent Skills parser/validator | P1; skill validator candidate |
| 02_skills_mcp | cybershape/mcp-smart-proxy | 3 | 0-99 | Rust | MCP discovery via compact proxy surface | P2; context gateway example |
| 02_skills_mcp | agntcy/slim-mcp-rust | 1 | 0-99 | Rust | SLIM transport/proxy integration | Research only |
| 02_skills_mcp | skill-one/agents-skills | 0 | 0-99 | Rust | Cross-agent SKILL.md package installer | P2; evaluation only |
| 02_skills_mcp | yuunnn-w/Rust-Agent-MCP | N/V | unverified | not checked | Rust sequential subagent dispatch MCP | Research only |
| 03_search_storage_rag_memory | meilisearch/meilisearch | 59751 | 50k+ | Rust | Search platform with typo tolerance | P1; alternative search backend |
| 03_search_storage_rag_memory | qdrant/qdrant | 35377 | 10k-49,999 | Rust | Production vector store, hybrid retrieval | P1; when semantic retrieval warranted |
| 03_search_storage_rag_memory | surrealdb/surrealdb | 33259 | 10k-49,999 | Rust | Graph/multi-model database | P2; future graph indexing |
| 03_search_storage_rag_memory | chroma-core/chroma | 29620 | 10k-49,999 | Rust | Vector/database platform with Rust systems core | Hybrid; out of strict pure-Rust scope |
| 03_search_storage_rag_memory | quickwit-oss/tantivy | 16378 | 10k-49,999 | Rust | High-performance embedded full-text/BM25 library | P0; authoritative search index |
| 03_search_storage_rag_memory | lancedb/lancedb | 11826 | 10k-49,999 | Rust | Embedded vector and multimodal storage | P1; local semantic index |
| 03_search_storage_rag_memory | quickwit-oss/quickwit | 11759 | 10k-49,999 | Rust | Distributed log and search system | P2; scale-out indexing |
| 03_search_storage_rag_memory | huggingface/tokenizers | 11217 | 10k-49,999 | Rust | High-performance tokenizer | P0; token accounting support |
| 03_search_storage_rag_memory | cberner/redb | 4890 | 1k-9,999 | Rust | Pure-Rust embedded key/value storage | P0; local ledger option |
| 03_search_storage_rag_memory | unum-cloud/USearch | 4368 | 1k-9,999 | C++ | High-performance vector search | Exclude native-Rust claim |
| 03_search_storage_rag_memory | fjall-rs/fjall | 2414 | 1k-9,999 | Rust | Pure-Rust LSM key/value persistence | P1; local durable index |
| 03_search_storage_rag_memory | Anush008/fastembed-rs | 1051 | 1k-9,999 | Rust | Rust-native embeddings interface | P1; optional embeddings |
| 03_search_storage_rag_memory | asanabrial/leteo | 4 | 0-99 | Rust | SQLite local persistent agent memory | Research only |
| 03_search_storage_rag_memory | taeyun16/aidememo | 1 | 0-99 | Rust | Rust local agent memory and graph MCP | Research only |
| 03_search_storage_rag_memory | ltsearch/LTSearch | N/V | unverified | not checked | Rust hybrid search architecture | Unverified candidate |
| 03_search_storage_rag_memory | vectorian-rs/qrst | N/V | unverified | not checked | On-device BM25 + vector hybrid retrieval | P2; small-scale pilot |
| 04_document_parsing_inference | typst/typst | 56942 | 50k+ | Rust | Typesetting/document generation in Rust | P1; render future docs |
| 04_document_parsing_inference | rust-lang/mdBook | 22258 | 10k-49,999 | Rust | Rust book documentation builder | P1; docs publisher |
| 04_document_parsing_inference | huggingface/candle | 21265 | 10k-49,999 | Rust | Rust machine learning framework | P2; local embeddings/inference |
| 04_document_parsing_inference | tracel-ai/burn | 16211 | 10k-49,999 | Rust | Rust neural network framework | P2; custom model research |
| 04_document_parsing_inference | EricLBuehler/mistral.rs | 7791 | 1k-9,999 | Rust | Rust local model inference/serving | P2; optional local model |
| 04_document_parsing_inference | pulldown-cmark/pulldown-cmark | 2755 | 1k-9,999 | Rust | CommonMark parser | P0; source-preserving Markdown pipelines |
| 04_document_parsing_inference | pykeio/ort | 2603 | 1k-9,999 | Rust | Rust bindings to ONNX Runtime | Hybrid; not pure Rust inference |
| 04_document_parsing_inference | J-F-Liu/lopdf | 2289 | 1k-9,999 | Rust | PDF parser and writer library | P0; build low-level extraction |
| 04_document_parsing_inference | kivikakk/comrak | 1731 | 1k-9,999 | Rust | CommonMark/GFM parser and renderer | P0; skill/book transformation |
| 04_document_parsing_inference | jrmuizel/pdf-extract | 606 | 100-999 | Rust | PDF text extraction | P1; simple text fallback |
| 04_document_parsing_inference | raphaelmansuy/edgeparse | 154 | 100-999 | Rust | Deterministic born-digital PDF parsing | P2; compare PDF accuracy |
| 04_document_parsing_inference | carles-abarca/docling-rs | 9 | 0-99 | Rust | Unofficial native-Rust Docling port | Research only |
| 04_document_parsing_inference | yzlabai/docparse-rs | 8 | 0-99 | Rust | Rust parser with source/bounding-box provenance | P2; evaluate parser against PDFs |
| 04_document_parsing_inference | sonos/tract | N/V | unverified | not checked | ONNX/inference engine Rust | P1; native inference candidate |
| 05_orchestration_governance_observability | tokio-rs/tokio | 33562 | 10k-49,999 | Rust | Async runtime | P1; when underlying libraries require it |
| 05_orchestration_governance_observability | tokio-rs/axum | 27681 | 10k-49,999 | Rust | Rust HTTP API framework | P1; remote MCP endpoint |
| 05_orchestration_governance_observability | wasmerio/wasmer | 21217 | 10k-49,999 | Rust | Alternative Rust WebAssembly runtime | P2; performance/policy comparison |
| 05_orchestration_governance_observability | bytecodealliance/wasmtime | 18814 | 10k-49,999 | Rust | Rust WebAssembly sandbox/runtime | P1; constrain untrusted tool extensions |
| 05_orchestration_governance_observability | windmill-labs/windmill | 18357 | 10k-49,999 | Rust | Workflow automation platform | P2; ops/UI option |
| 05_orchestration_governance_observability | tokio-rs/tracing | 6949 | 1k-9,999 | Rust | Structured trace instrumentation | P0; step/evidence observability |
| 05_orchestration_governance_observability | restatedev/restate | 4642 | 1k-9,999 | Rust | Durable Rust-backed execution and service orchestration | P1; future durable work state |
| 05_orchestration_governance_observability | nextest-rs/nextest | 3380 | 1k-9,999 | Rust | Efficient Rust test orchestration | P1; run only after allowed tests/harnesses |
| 05_orchestration_governance_observability | open-telemetry/opentelemetry-rust | 2757 | 1k-9,999 | Rust | Tracing/metric telemetry SDK | P0; evidence pipeline |
| 05_orchestration_governance_observability | EmbarkStudios/cargo-deny | 2476 | 1k-9,999 | Rust | Rust dependency/license/advisory policy checks | P0; dependency governance |
| 05_orchestration_governance_observability | rustsec/rustsec | 1979 | 1k-9,999 | Rust | Rust security advisory tooling | P0; dependency advisory feed |
| 05_orchestration_governance_observability | cedar-policy/cedar | 1831 | 1k-9,999 | Rust | Rust policy-as-code authorization engine | P0; tool permissions and resource policy |
| 05_orchestration_governance_observability | apalis-dev/apalis | 1490 | 1k-9,999 | Rust | Rust background jobs and workers | P1; single-worker queue |
| 05_orchestration_governance_observability | mozilla/cargo-vet | 1005 | 1k-9,999 | Rust | Dependency audit provenance and trust delegation | P0; dependency review |
| 05_orchestration_governance_observability | rust-secure-code/cargo-auditable | 873 | 100-999 | Rust | Dependency information embedded in binaries | P1; post-build traceability |
| 05_orchestration_governance_observability | obeli-sk/obelisk | 766 | 100-999 | Rust | Deterministic Rust durable workflow engine | P2; experimental sequential workflow |
| 05_orchestration_governance_observability | microsoft/regorus | 366 | 100-999 | Rust | Rust Rego interpreter | P1; compatibility alternative |
| 06_verification_one_to_one_migration | tree-sitter/tree-sitter | 27354 | 10k-49,999 | C | Polyglot parser with Rust bindings | Hybrid; C runtime |
| 06_verification_one_to_one_migration | rust-lang/rust-analyzer | 16964 | 10k-49,999 | Rust | Rust HIR/semantic frontend | P0; target object inventory |
| 06_verification_one_to_one_migration | ast-grep/ast-grep | 16417 | 10k-49,999 | Rust | Rust structural search and rewrite | P0; object/method naming gates |
| 06_verification_one_to_one_migration | rust-lang/miri | 6707 | 1k-9,999 | Rust | Rust interpreter for undefined-behavior detection | P2; later technical safety phase |
| 06_verification_one_to_one_migration | rust-lang/rust-bindgen | 5314 | 1k-9,999 | Rust | Generate Rust FFI declarations from C/C++ | P1; source ABI inventory |
| 06_verification_one_to_one_migration | immunant/c2rust | 4832 | 1k-9,999 | Rust | C-to-Rust translation | P2; baseline comparator for C |
| 06_verification_one_to_one_migration | model-checking/kani | 3627 | 1k-9,999 | Rust | Rust bounded model checking | P0; original-test-derived domain harnesses |
| 06_verification_one_to_one_migration | verus-lang/verus | 3536 | 1k-9,999 | Rust | Deductive Rust verification | P2; later proof phase |
| 06_verification_one_to_one_migration | creusot-rs/creusot | 1951 | 1k-9,999 | Rust | Rust deductive verification | P2; later proof phase |
| 06_verification_one_to_one_migration | obi1kenobi/cargo-semver-checks | 1703 | 1k-9,999 | Rust | Rust public API compatibility checks | P0; post-map change detection |
| 06_verification_one_to_one_migration | cargo-public-api/cargo-public-api | 582 | 100-999 | Rust | Rust public API inventory and diff | P0; correspondence comparator |
| 06_verification_one_to_one_migration | tree-sitter/tree-sitter-graph | 349 | 100-999 | Rust | Graph construction on tree-sitter | P1; source-fact extraction |
| 06_verification_one_to_one_migration | Cpp2Rust/cpp2rust | 319 | 100-999 | Rust | C++ to safe Rust research translator | Research only |
| 06_verification_one_to_one_migration | camshaft/bolero | 265 | 100-999 | C | Property/fuzz frontend with Kani options | P1; check backend support and pin versions |
| 06_verification_one_to_one_migration | stakwork/stakgraph | 113 | 100-999 | TypeScript | Polyglot source graph tooling | Hybrid; not pure Rust |
| 06_verification_one_to_one_migration | rust-lang/rustdoc-types | 44 | 0-99 | Rust | Rust public API JSON schema types | P0; target interface export |
| 06_verification_one_to_one_migration | NodeDB-Lab/code2graph | 11 | 0-99 | Rust | Rust polyglot structural facts via tree-sitter | Research only |
| 06_verification_one_to_one_migration | viperproject/prusti-dev | N/V | unverified | not checked | Rust verification based on Viper | Research only |

Detailed notes and source-classification rationales are in `catalog/`. Exact GitHub API metadata is preserved in `tables/projects.json`.
