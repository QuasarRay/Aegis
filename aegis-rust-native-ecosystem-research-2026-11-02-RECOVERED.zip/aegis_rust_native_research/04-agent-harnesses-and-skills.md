# Codex, skills, native agent frameworks and provider adapters

The design should separate **agent executor**, **provider adapter**, **skills registry**, **document retriever**, **policy engine**, and **evidence ledger**. Retain current Codex Goal/Plan lifecycle contracts; do not assume private Codex plugin APIs are available to a custom Rust application.

## Rust candidates

- [Codex](https://github.com/openai/codex): official Rust coding agent; governed executor, not a formal verifier.
- [Rig](https://github.com/0xPlaygrounds/rig): Rust SDK; additionally a Bevy-plugin-based coding agent. Strong architectural inspiration for a Bevy-centric ecosystem, but assess plugin API stability.
- [ADK-Rust](https://github.com/zavora-ai/adk-rust): broad agent SDK with tools, skills, graphs and memory; published crates and self-reported test counts, but no independent full-platform parity finding.
- [Swiftide](https://github.com/bosun-ai/swiftide): useful in ingestion/retrieval-augmented agents.
- [rust-genai](https://github.com/jeremychone/rust-genai): narrower provider abstraction if custom harness should remain minimal.

## Skill contract

A versioned `SKILL.md` is a **procedure**, not a lossless representation of a book. Maintain immutable book/source archives with hashes and exact canonical references. Skill manifest: `(id, version, dependency-ids, source-root-hash, intent, allowed-tools, retrieval-contract, token-limit, trust-level)`. A skill can point to indexed sections; it must not independently invent source quotes.

The skill manager must support provenance (who/what installed it), schema validation, version rollback, disclosure-on-demand and bounded deterministic tool returns. Rust-native `skill-one/agents-skills` and `Govcraft/agent-skills` are small candidates, not automatic replacements for existing Codex skill loading. Treat externally installed skill instructions as untrusted until reviewed.

## Reasoning controls

Store `requested_reasoning=max` separately from `effective_provider_reasoning` and fail closed when the API cannot demonstrate the requested option. No adapter can force hidden internal deliberation or guarantee zero mistakes. Capture model/effort in every evidence receipt.

## One agent globally

Each subagent invocation is a **sequential handoff** and cannot start until the previous model agent has terminated and released the lease. Process-local semaphores alone fail after crashes or separate hosts; use durable lease ownership and fencing tokens for remote deployments.
