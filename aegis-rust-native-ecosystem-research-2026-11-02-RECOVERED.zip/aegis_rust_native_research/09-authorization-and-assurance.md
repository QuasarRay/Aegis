# Policy-as-code, formal methods, sandboxing and provenance

- `cedar-policy/cedar`: native Rust authorization policies for actor, tool, resource and action. Default-deny; independent enforcement at tool boundary.
- `microsoft/regorus`: Rust Rego interpreter; compare against known OPA policies before replacing Rego semantics.
- `bytecodealliance/wasmtime`: capability-scoped WASM tool plugins, subject to WASI filesystem/network permissions.
- `EmbarkStudios/cargo-deny`, `rustsec/rustsec`, `mozilla/cargo-vet`, `cargo-auditable`: license, advisory, dependency-review and traceability. These mechanisms have **different coverage**.
- `tracing` + `opentelemetry-rust`: deterministic event provenance and runtime performance evidence, not proof of agent reasoning correctness.
- `model-checking/kani`: bit-precise bounded Rust model checking; only prove the harnessed assertions under actual modeled assumptions. `Verus`, `Creusot`, `Miri` are later-phase tools and do not replace the test-source-only invariant in phase 1.

## Primary threat model

Malicious instructions embedded in book/doc content; forged citation/source IDs; prompt injection through MCP tool results; source extraction corruption; arbitrary shell capability exposed through MCP; untrusted installer scripts; supply-chain compromise; stale corpus/documentation; agent lease bypass; conflicting parallel runs; falsely green harness reports; ambiguous source object grouping; runaway repeated model invocations.

## Gates

Every policy verdict is recorded with policy hash and input subject/resource/action. Every generated correspondence record includes a reviewer-visible original/source location and target symbol. Every harness is traced to an exact original test case and test-source checksum. Failing, unreachable or incomplete results remain visible; no synthetic success receipts. Make review mandatory when the source behavior cannot be determined.
