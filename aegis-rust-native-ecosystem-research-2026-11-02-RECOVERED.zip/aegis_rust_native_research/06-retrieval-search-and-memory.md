# Rust-native search, RAG and memory

Start with **Tantivy** for exact/lexical search (method names, theorem labels, features, source locations); add a **Qdrant** or **LanceDB** vector channel only after measuring better recall on technical questions. `redb` or Fjall can hold immutable index manifests, source hashes, topic-to-section links, and work deduplication IDs. Build hybrid retrieval via fusion with explicit lexical priority for exact source identifiers.

## Zero-loss interpretation

- Preserve authoritative original bytes exactly, with SHA-256, license/provenance, declared version and page/file identities.
- Preserve parser output separately and record extraction failures; PDF-to-Markdown cannot automatically be presumed reversible.
- Maintain a structured section registry and non-destructive chunk mapping. Every emitted excerpt references original document hash plus page/byte/bounding-box location where feasible.
- Evaluation uses exact-match query suites, source retrieval recall, predecessor/successor rule retrieval, symbol/identifier fidelity, equation roundtrip spot checks, and citation accuracy. A summary is an optional derived note, never the source of truth.
- Unlimiformer operates at transformer attention/model level; Codex cannot be extended through MCP to alter hidden attention. Do not add it for this pilot.

## Memory

Persistent agent memory should consist of structured, evidence-linked facts such as `work-item`, `source-version`, `verified-harness-receipt`, `retrieval-trace`, `correspondence-status`, `reviewer`, `decision`. Low-adoption memory agents such as Aidememo/Leteo are evaluated only as experiments; memory must never override source artifacts or Aegis policy.

## Practical query budget

Use indexed search + rerank then expand adjacent sections. Cap initial hits (e.g., 8), cap result tokens, and require explicit tool call for more. Cache `(source-root-hash, query-normalization, retrieval-version, ranking-configuration)` to avoid repeat token expenditure; log cache-hit rate and wrong-retrieval rate.
