# 06 Verification One To One Migration

**Entries:** 18. Stars sorted descending where verified. No project is asserted to be independently audited as production ready.

| project | stars | primary_language | rust_purity | readiness | strongest_niche |
|---|---|---|---|---|---|
| tree-sitter/tree-sitter | 27354 | C | Rust-facing / hybrid (not strict Rust-only) | Exploratory / partial / insufficient independent deployment evidence | Polyglot parser with Rust bindings |
| rust-lang/rust-analyzer | 16964 | Rust | Rust-primary (not audited pure Rust) | Established component; production assessment scoped to niche | Rust HIR/semantic frontend |
| ast-grep/ast-grep | 16417 | Rust | Rust-primary (not audited pure Rust) | Established component; production assessment scoped to niche | Rust structural search and rewrite |
| rust-lang/miri | 6707 | Rust | Rust-primary (not audited pure Rust) | Established component; production assessment scoped to niche | Rust interpreter for undefined-behavior detection |
| rust-lang/rust-bindgen | 5314 | Rust | Rust-facing / hybrid (not strict Rust-only) | Exploratory / partial / insufficient independent deployment evidence | Generate Rust FFI declarations from C/C++ |
| immunant/c2rust | 4832 | Rust | Rust-primary (not audited pure Rust) | Maintained/viable candidate; pilot before critical path | C-to-Rust translation |
| model-checking/kani | 3627 | Rust | Rust-primary (not audited pure Rust) | Established component; production assessment scoped to niche | Rust bounded model checking |
| verus-lang/verus | 3536 | Rust | Rust-primary (not audited pure Rust) | Maintained/viable candidate; pilot before critical path | Deductive Rust verification |
| creusot-rs/creusot | 1951 | Rust | Rust-primary (not audited pure Rust) | Maintained/viable candidate; pilot before critical path | Rust deductive verification |
| obi1kenobi/cargo-semver-checks | 1703 | Rust | Rust-primary (not audited pure Rust) | Exploratory / partial / insufficient independent deployment evidence | Rust public API compatibility checks |
| cargo-public-api/cargo-public-api | 582 | Rust | Rust-primary (not audited pure Rust) | Exploratory / partial / insufficient independent deployment evidence | Rust public API inventory and diff |
| tree-sitter/tree-sitter-graph | 349 | Rust | Rust-primary (not audited pure Rust) | Exploratory / partial / insufficient independent deployment evidence | Graph construction on tree-sitter |
| Cpp2Rust/cpp2rust | 319 | Rust | Rust-primary (not audited pure Rust) | Exploratory / partial / insufficient independent deployment evidence | C++ to safe Rust research translator |
| camshaft/bolero | 265 | C | Rust functionality; repository language metadata mixed | Exploratory / partial / insufficient independent deployment evidence | Property/fuzz frontend with Kani options |
| stakwork/stakgraph | 113 | TypeScript | Rust-facing / hybrid (not strict Rust-only) | Exploratory / partial / insufficient independent deployment evidence | Polyglot source graph tooling |
| rust-lang/rustdoc-types | 44 | Rust | Rust-primary (not audited pure Rust) | Established component; production assessment scoped to niche | Rust public API JSON schema types |
| NodeDB-Lab/code2graph | 11 | Rust | Rust-primary (not audited pure Rust) | Exploratory / partial / insufficient independent deployment evidence | Rust polyglot structural facts via tree-sitter |
| viperproject/prusti-dev | N/V | not checked | Rust claimed / not independently confirmed | Exploratory / partial / insufficient independent deployment evidence | Rust verification based on Viper |

### [tree-sitter/tree-sitter](https://github.com/tree-sitter/tree-sitter)

**Best niche:** Polyglot parser with Rust bindings. **Aegis disposition:** Hybrid; C runtime.

**Evidence:** 27354 stars (GitHub REST API / 2026-11-02); primary language C; last pushed 2026-11-02; license MIT. **Purity:** Rust-facing / hybrid (not strict Rust-only). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Not fully Rust-native parser, despite Rust bindings. Independent code review, build reproduction and deployment audit were not performed.

### [rust-lang/rust-analyzer](https://github.com/rust-lang/rust-analyzer)

**Best niche:** Rust HIR/semantic frontend. **Aegis disposition:** P0; target object inventory.

**Evidence:** 16964 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-02; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Established component; production assessment scoped to niche. **Assurance:** Deterministic/parser/system checks; no full migration assurance.

**Caveat:** Macro expansions and cfg variants require explicit audit. Independent code review, build reproduction and deployment audit were not performed.

### [ast-grep/ast-grep](https://github.com/ast-grep/ast-grep)

**Best niche:** Rust structural search and rewrite. **Aegis disposition:** P0; object/method naming gates.

**Evidence:** 16417 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-02; license MIT. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Established component; production assessment scoped to niche. **Assurance:** Deterministic/parser/system checks; no full migration assurance.

**Caveat:** Syntactic matches do not prove semantic equivalence. Independent code review, build reproduction and deployment audit were not performed.

### [rust-lang/miri](https://github.com/rust-lang/miri)

**Best niche:** Rust interpreter for undefined-behavior detection. **Aegis disposition:** P2; later technical safety phase.

**Evidence:** 6707 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-02; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Established component; production assessment scoped to niche. **Assurance:** Formal analysis capability (scope limited).

**Caveat:** Not a semantics-equivalence proof. Independent code review, build reproduction and deployment audit were not performed.

### [rust-lang/rust-bindgen](https://github.com/rust-lang/rust-bindgen)

**Best niche:** Generate Rust FFI declarations from C/C++. **Aegis disposition:** P1; source ABI inventory.

**Evidence:** 5314 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-28; license BSD-3-Clause. **Purity:** Rust-facing / hybrid (not strict Rust-only). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Depends on Clang/libclang: not fully native Rust pipeline. Independent code review, build reproduction and deployment audit were not performed.

### [immunant/c2rust](https://github.com/immunant/c2rust)

**Best niche:** C-to-Rust translation. **Aegis disposition:** P2; baseline comparator for C.

**Evidence:** 4832 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-26; license not automatically classified. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Maintained/viable candidate; pilot before critical path. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** C translation is not full C++/Go/Java/Python one-to-one semantics. Independent code review, build reproduction and deployment audit were not performed.

### [model-checking/kani](https://github.com/model-checking/kani)

**Best niche:** Rust bounded model checking. **Aegis disposition:** P0; original-test-derived domain harnesses.

**Evidence:** 3627 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-02; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Established component; production assessment scoped to niche. **Assurance:** Formal analysis capability (scope limited).

**Caveat:** Cannot prove full E2E equivalence or concurrency automatically. Independent code review, build reproduction and deployment audit were not performed.

### [verus-lang/verus](https://github.com/verus-lang/verus)

**Best niche:** Deductive Rust verification. **Aegis disposition:** P2; later proof phase.

**Evidence:** 3536 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-02; license MIT. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Maintained/viable candidate; pilot before critical path. **Assurance:** Formal analysis capability (scope limited).

**Caveat:** Separate proof models/specs needed; not a drop-in Kani replacement. Independent code review, build reproduction and deployment audit were not performed.

### [creusot-rs/creusot](https://github.com/creusot-rs/creusot)

**Best niche:** Rust deductive verification. **Aegis disposition:** P2; later proof phase.

**Evidence:** 1951 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-30; license LGPL-2.1. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Maintained/viable candidate; pilot before critical path. **Assurance:** Formal analysis capability (scope limited).

**Caveat:** Toolchain restrictions and human-reviewed specs. Independent code review, build reproduction and deployment audit were not performed.

### [obi1kenobi/cargo-semver-checks](https://github.com/obi1kenobi/cargo-semver-checks)

**Best niche:** Rust public API compatibility checks. **Aegis disposition:** P0; post-map change detection.

**Evidence:** 1703 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-02; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Supply-chain/checking/verification evidence.

**Caveat:** API preservation is narrower than object/behavior equivalence. Independent code review, build reproduction and deployment audit were not performed.

### [cargo-public-api/cargo-public-api](https://github.com/cargo-public-api/cargo-public-api)

**Best niche:** Rust public API inventory and diff. **Aegis disposition:** P0; correspondence comparator.

**Evidence:** 582 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-02; license MIT. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Supply-chain/checking/verification evidence.

**Caveat:** Can miss private members, cfg variants or dynamic behavior. Independent code review, build reproduction and deployment audit were not performed.

### [tree-sitter/tree-sitter-graph](https://github.com/tree-sitter/tree-sitter-graph)

**Best niche:** Graph construction on tree-sitter. **Aegis disposition:** P1; source-fact extraction.

**Evidence:** 349 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2024-12-11; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Inherits tree-sitter parsing limits; semantic resolution requires work. Independent code review, build reproduction and deployment audit were not performed.

### [Cpp2Rust/cpp2rust](https://github.com/Cpp2Rust/cpp2rust)

**Best niche:** C++ to safe Rust research translator. **Aegis disposition:** Research only.

**Evidence:** 319 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-01; license MIT. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Claims require restricted-language benchmarks; not full C++ coverage. Independent code review, build reproduction and deployment audit were not performed.

### [camshaft/bolero](https://github.com/camshaft/bolero)

**Best niche:** Property/fuzz frontend with Kani options. **Aegis disposition:** P1; check backend support and pin versions.

**Evidence:** 265 stars (GitHub REST API / 2026-11-02); primary language C; last pushed 2026-10-03; license MIT. **Purity:** Rust functionality; repository language metadata mixed. **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Repo primary-language listing C; inspect Rust crates and backends. Independent code review, build reproduction and deployment audit were not performed.

### [stakwork/stakgraph](https://github.com/stakwork/stakgraph)

**Best niche:** Polyglot source graph tooling. **Aegis disposition:** Hybrid; not pure Rust.

**Evidence:** 113 stars (GitHub REST API / 2026-11-02); primary language TypeScript; last pushed 2026-11-02; license not checked. **Purity:** Rust-facing / hybrid (not strict Rust-only). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** GitHub reports TypeScript primary language. Independent code review, build reproduction and deployment audit were not performed.

### [rust-lang/rustdoc-types](https://github.com/rust-lang/rustdoc-types)

**Best niche:** Rust public API JSON schema types. **Aegis disposition:** P0; target interface export.

**Evidence:** 44 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-27; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Established component; production assessment scoped to niche. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** rustdoc JSON output remains unstable; nightly pinning. Independent code review, build reproduction and deployment audit were not performed.

### [NodeDB-Lab/code2graph](https://github.com/NodeDB-Lab/code2graph)

**Best niche:** Rust polyglot structural facts via tree-sitter. **Aegis disposition:** Research only.

**Evidence:** 11 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-04; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Very low adoption and semantics not independently verified. Independent code review, build reproduction and deployment audit were not performed.

### [viperproject/prusti-dev](https://github.com/viperproject/prusti-dev)

**Best niche:** Rust verification based on Viper. **Aegis disposition:** Research only.

**Evidence:** stars not verified stars (not verified); primary language not checked; last pushed not checked; license not checked. **Purity:** Rust claimed / not independently confirmed. **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Prototype and backend dependency; validate maintenance. Independent code review, build reproduction and deployment audit were not performed.
