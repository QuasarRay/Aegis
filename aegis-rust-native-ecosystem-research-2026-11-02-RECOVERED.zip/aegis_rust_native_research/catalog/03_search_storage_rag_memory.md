# 03 Search Storage Rag Memory

**Entries:** 16. Stars sorted descending where verified. No project is asserted to be independently audited as production ready.

| project | stars | primary_language | rust_purity | readiness | strongest_niche |
|---|---|---|---|---|---|
| meilisearch/meilisearch | 59751 | Rust | Rust-primary (not audited pure Rust) | Established component; production assessment scoped to niche | Search platform with typo tolerance |
| qdrant/qdrant | 35377 | Rust | Rust-primary (not audited pure Rust) | Established component; production assessment scoped to niche | Production vector store, hybrid retrieval |
| surrealdb/surrealdb | 33259 | Rust | Rust-primary (not audited pure Rust) | Maintained/viable candidate; pilot before critical path | Graph/multi-model database |
| chroma-core/chroma | 29620 | Rust | Rust-facing / hybrid (not strict Rust-only) | Exploratory / partial / insufficient independent deployment evidence | Vector/database platform with Rust systems core |
| quickwit-oss/tantivy | 16378 | Rust | Rust-primary (not audited pure Rust) | Established component; production assessment scoped to niche | High-performance embedded full-text/BM25 library |
| lancedb/lancedb | 11826 | Rust | Rust-primary (not audited pure Rust) | Established component; production assessment scoped to niche | Embedded vector and multimodal storage |
| quickwit-oss/quickwit | 11759 | Rust | Rust-primary (not audited pure Rust) | Established component; production assessment scoped to niche | Distributed log and search system |
| huggingface/tokenizers | 11217 | Rust | Rust-primary (not audited pure Rust) | Established component; production assessment scoped to niche | High-performance tokenizer |
| cberner/redb | 4890 | Rust | Rust-primary (not audited pure Rust) | Established component; production assessment scoped to niche | Pure-Rust embedded key/value storage |
| unum-cloud/USearch | 4368 | C++ | Rust-facing / hybrid (not strict Rust-only) | Exploratory / partial / insufficient independent deployment evidence | High-performance vector search |
| fjall-rs/fjall | 2414 | Rust | Rust-primary (not audited pure Rust) | Maintained/viable candidate; pilot before critical path | Pure-Rust LSM key/value persistence |
| Anush008/fastembed-rs | 1051 | Rust | Rust-primary (not audited pure Rust) | Maintained/viable candidate; pilot before critical path | Rust-native embeddings interface |
| asanabrial/leteo | 4 | Rust | Rust-primary (not audited pure Rust) | Exploratory / partial / insufficient independent deployment evidence | SQLite local persistent agent memory |
| taeyun16/aidememo | 1 | Rust | Rust-primary (not audited pure Rust) | Exploratory / partial / insufficient independent deployment evidence | Rust local agent memory and graph MCP |
| ltsearch/LTSearch | N/V | not checked | Rust claimed / not independently confirmed | Exploratory / partial / insufficient independent deployment evidence | Rust hybrid search architecture |
| vectorian-rs/qrst | N/V | not checked | Rust claimed / not independently confirmed | Exploratory / partial / insufficient independent deployment evidence | On-device BM25 + vector hybrid retrieval |

### [meilisearch/meilisearch](https://github.com/meilisearch/meilisearch)

**Best niche:** Search platform with typo tolerance. **Aegis disposition:** P1; alternative search backend.

**Evidence:** 59751 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-01; license not automatically classified. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Established component; production assessment scoped to niche. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Typo tolerance must not replace exact symbol lookup. Independent code review, build reproduction and deployment audit were not performed.

### [qdrant/qdrant](https://github.com/qdrant/qdrant)

**Best niche:** Production vector store, hybrid retrieval. **Aegis disposition:** P1; when semantic retrieval warranted.

**Evidence:** 35377 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-02; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Established component; production assessment scoped to niche. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Additional service overhead vs embedded index. Independent code review, build reproduction and deployment audit were not performed.

### [surrealdb/surrealdb](https://github.com/surrealdb/surrealdb)

**Best niche:** Graph/multi-model database. **Aegis disposition:** P2; future graph indexing.

**Evidence:** 33259 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-29; license not automatically classified. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Maintained/viable candidate; pilot before critical path. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Operational complexity and query semantics require audit. Independent code review, build reproduction and deployment audit were not performed.

### [chroma-core/chroma](https://github.com/chroma-core/chroma)

**Best niche:** Vector/database platform with Rust systems core. **Aegis disposition:** Hybrid; out of strict pure-Rust scope.

**Evidence:** 29620 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-30; license Apache-2.0. **Purity:** Rust-facing / hybrid (not strict Rust-only). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Python/TypeScript interfaces and other runtime pieces; check full stack. Independent code review, build reproduction and deployment audit were not performed.

### [quickwit-oss/tantivy](https://github.com/quickwit-oss/tantivy)

**Best niche:** High-performance embedded full-text/BM25 library. **Aegis disposition:** P0; authoritative search index.

**Evidence:** 16378 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-30; license MIT. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Established component; production assessment scoped to niche. **Assurance:** Deterministic/parser/system checks; no full migration assurance.

**Caveat:** Excellent exact search; embeddings optional. Independent code review, build reproduction and deployment audit were not performed.

### [lancedb/lancedb](https://github.com/lancedb/lancedb)

**Best niche:** Embedded vector and multimodal storage. **Aegis disposition:** P1; local semantic index.

**Evidence:** 11826 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-02; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Established component; production assessment scoped to niche. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Rust core plus cross-language bindings; check operational footprint. Independent code review, build reproduction and deployment audit were not performed.

### [quickwit-oss/quickwit](https://github.com/quickwit-oss/quickwit)

**Best niche:** Distributed log and search system. **Aegis disposition:** P2; scale-out indexing.

**Evidence:** 11759 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-01; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Established component; production assessment scoped to niche. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Overkill for small single-machine book indexes. Independent code review, build reproduction and deployment audit were not performed.

### [huggingface/tokenizers](https://github.com/huggingface/tokenizers)

**Best niche:** High-performance tokenizer. **Aegis disposition:** P0; token accounting support.

**Evidence:** 11217 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-02; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Established component; production assessment scoped to niche. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Token counts depend on exact provider/model encoding. Independent code review, build reproduction and deployment audit were not performed.

### [cberner/redb](https://github.com/cberner/redb)

**Best niche:** Pure-Rust embedded key/value storage. **Aegis disposition:** P0; local ledger option.

**Evidence:** 4890 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-02; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Established component; production assessment scoped to niche. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Transaction durability needs crash/fault testing. Independent code review, build reproduction and deployment audit were not performed.

### [unum-cloud/USearch](https://github.com/unum-cloud/USearch)

**Best niche:** High-performance vector search. **Aegis disposition:** Exclude native-Rust claim.

**Evidence:** 4368 stars (GitHub REST API / 2026-11-02); primary language C++; last pushed 2026-10-31; license Apache-2.0. **Purity:** Rust-facing / hybrid (not strict Rust-only). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** GitHub reports C++ as primary language. Independent code review, build reproduction and deployment audit were not performed.

### [fjall-rs/fjall](https://github.com/fjall-rs/fjall)

**Best niche:** Pure-Rust LSM key/value persistence. **Aegis disposition:** P1; local durable index.

**Evidence:** 2414 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-25; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Maintained/viable candidate; pilot before critical path. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Match reliability needs with tuning and benchmarks. Independent code review, build reproduction and deployment audit were not performed.

### [Anush008/fastembed-rs](https://github.com/Anush008/fastembed-rs)

**Best niche:** Rust-native embeddings interface. **Aegis disposition:** P1; optional embeddings.

**Evidence:** 1051 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-26; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Maintained/viable candidate; pilot before critical path. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Inference can depend on ONNX runtime native libraries. Independent code review, build reproduction and deployment audit were not performed.

### [asanabrial/leteo](https://github.com/asanabrial/leteo)

**Best niche:** SQLite local persistent agent memory. **Aegis disposition:** Research only.

**Evidence:** 4 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-17; license MIT. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Low adoption and limited independent evidence. Independent code review, build reproduction and deployment audit were not performed.

### [taeyun16/aidememo](https://github.com/taeyun16/aidememo)

**Best niche:** Rust local agent memory and graph MCP. **Aegis disposition:** Research only.

**Evidence:** 1 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-02; license not automatically classified. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Very low adoption; memory must not become governance authority. Independent code review, build reproduction and deployment audit were not performed.

### [ltsearch/LTSearch](https://github.com/ltsearch/LTSearch)

**Best niche:** Rust hybrid search architecture. **Aegis disposition:** Unverified candidate.

**Evidence:** stars not verified stars (not verified); primary language not checked; last pushed not checked; license not checked. **Purity:** Rust claimed / not independently confirmed. **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Repository naming/identity may differ; source explicitly not verified. Independent code review, build reproduction and deployment audit were not performed.

### [vectorian-rs/qrst](https://github.com/vectorian-rs/qrst)

**Best niche:** On-device BM25 + vector hybrid retrieval. **Aegis disposition:** P2; small-scale pilot.

**Evidence:** stars not verified stars (not verified); primary language not checked; last pushed not checked; license not checked. **Purity:** Rust claimed / not independently confirmed. **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Independently verify completeness and memory footprint. Independent code review, build reproduction and deployment audit were not performed.
