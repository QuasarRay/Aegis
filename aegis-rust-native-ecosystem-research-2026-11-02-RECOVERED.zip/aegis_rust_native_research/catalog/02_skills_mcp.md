# 02 Skills Mcp

**Entries:** 11. Stars sorted descending where verified. No project is asserted to be independently audited as production ready.

| project | stars | primary_language | rust_purity | readiness | strongest_niche |
|---|---|---|---|---|---|
| modelcontextprotocol/rust-sdk | 4083 | Rust | Rust-primary (not audited pure Rust) | Established component; production assessment scoped to niche | Official RMCP client/server SDK |
| leonardomso/rust-skills | 662 | Python | Rust-facing / hybrid (not strict Rust-only) | Exploratory / partial / insufficient independent deployment evidence | Rust programming SKILL.md content catalog |
| rust-mcp-stack/rust-mcp-sdk | 199 | Rust | Rust-primary (not audited pure Rust) | Maintained/viable candidate; pilot before critical path | Alternative Rust MCP SDK |
| MikkoParkkola/mcp-gateway | 85 | Rust | Rust-primary (not audited pure Rust) | Exploratory / partial / insufficient independent deployment evidence | Context-budgeted dynamic MCP tool catalog |
| Brainwires/project-rag | 33 | Rust | Rust-primary (not audited pure Rust) | Exploratory / partial / insufficient independent deployment evidence | MCP agent-facing codebase search |
| joshrotenberg/mcp-proxy | 18 | Rust | Rust-primary (not audited pure Rust) | Exploratory / partial / insufficient independent deployment evidence | Rust configurable MCP reverse proxy |
| Govcraft/agent-skills | 16 | Rust | Rust-primary (not audited pure Rust) | Exploratory / partial / insufficient independent deployment evidence | Rust Agent Skills parser/validator |
| cybershape/mcp-smart-proxy | 3 | Rust | Rust-primary (not audited pure Rust) | Exploratory / partial / insufficient independent deployment evidence | MCP discovery via compact proxy surface |
| agntcy/slim-mcp-rust | 1 | Rust | Rust-primary (not audited pure Rust) | Exploratory / partial / insufficient independent deployment evidence | SLIM transport/proxy integration |
| skill-one/agents-skills | 0 | Rust | Rust-primary (not audited pure Rust) | Exploratory / partial / insufficient independent deployment evidence | Cross-agent SKILL.md package installer |
| yuunnn-w/Rust-Agent-MCP | N/V | not checked | Rust claimed / not independently confirmed | Exploratory / partial / insufficient independent deployment evidence | Rust sequential subagent dispatch MCP |

### [modelcontextprotocol/rust-sdk](https://github.com/modelcontextprotocol/rust-sdk)

**Best niche:** Official RMCP client/server SDK. **Aegis disposition:** P0; MCP server foundation.

**Evidence:** 4083 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-01; license not automatically classified. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Established component; production assessment scoped to niche. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Protocol support established; policy and isolation must be external. Independent code review, build reproduction and deployment audit were not performed.

### [leonardomso/rust-skills](https://github.com/leonardomso/rust-skills)

**Best niche:** Rust programming SKILL.md content catalog. **Aegis disposition:** Reference material.

**Evidence:** 662 stars (GitHub REST API / 2026-11-02); primary language Python; last pushed 2026-06-14; license MIT. **Purity:** Rust-facing / hybrid (not strict Rust-only). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Not a Rust-native runtime: GitHub reports Python as primary language. Independent code review, build reproduction and deployment audit were not performed.

### [rust-mcp-stack/rust-mcp-sdk](https://github.com/rust-mcp-stack/rust-mcp-sdk)

**Best niche:** Alternative Rust MCP SDK. **Aegis disposition:** P2; comparison reference.

**Evidence:** 199 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-26; license MIT. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Maintained/viable candidate; pilot before critical path. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Avoid duplicate MCP stacks unless feature gap is demonstrated. Independent code review, build reproduction and deployment audit were not performed.

### [MikkoParkkola/mcp-gateway](https://github.com/MikkoParkkola/mcp-gateway)

**Best niche:** Context-budgeted dynamic MCP tool catalog. **Aegis disposition:** P2; token-budget experiments.

**Evidence:** 85 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-02; license not automatically classified. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Promised capabilities need independent resource and auth testing. Independent code review, build reproduction and deployment audit were not performed.

### [Brainwires/project-rag](https://github.com/Brainwires/project-rag)

**Best niche:** MCP agent-facing codebase search. **Aegis disposition:** P1; reference/pilot.

**Evidence:** 33 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-30; license MIT. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Indexing git history is useful but semantic retrieval is not proof. Independent code review, build reproduction and deployment audit were not performed.

### [joshrotenberg/mcp-proxy](https://github.com/joshrotenberg/mcp-proxy)

**Best niche:** Rust configurable MCP reverse proxy. **Aegis disposition:** P2; stage behind tests.

**Evidence:** 18 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-02; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Proxies are not authorization boundaries without explicit policy. Independent code review, build reproduction and deployment audit were not performed.

### [Govcraft/agent-skills](https://github.com/Govcraft/agent-skills)

**Best niche:** Rust Agent Skills parser/validator. **Aegis disposition:** P1; skill validator candidate.

**Evidence:** 16 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-14; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Low adoption does not imply incorrectness, but review code. Independent code review, build reproduction and deployment audit were not performed.

### [cybershape/mcp-smart-proxy](https://github.com/cybershape/mcp-smart-proxy)

**Best niche:** MCP discovery via compact proxy surface. **Aegis disposition:** P2; context gateway example.

**Evidence:** 3 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-08-25; license not checked. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Treat dynamic tool discovery as untrusted and authorize every call. Independent code review, build reproduction and deployment audit were not performed.

### [agntcy/slim-mcp-rust](https://github.com/agntcy/slim-mcp-rust)

**Best niche:** SLIM transport/proxy integration. **Aegis disposition:** Research only.

**Evidence:** 1 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-19; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Current README identifies future transport as not yet implemented. Independent code review, build reproduction and deployment audit were not performed.

### [skill-one/agents-skills](https://github.com/skill-one/agents-skills)

**Best niche:** Cross-agent SKILL.md package installer. **Aegis disposition:** P2; evaluation only.

**Evidence:** 0 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-08; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Installing skills and governing trusted usage are distinct. Independent code review, build reproduction and deployment audit were not performed.

### [yuunnn-w/Rust-Agent-MCP](https://github.com/yuunnn-w/Rust-Agent-MCP)

**Best niche:** Rust sequential subagent dispatch MCP. **Aegis disposition:** Research only.

**Evidence:** stars not verified stars (not verified); primary language not checked; last pushed not checked; license not checked. **Purity:** Rust claimed / not independently confirmed. **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** May violate Aegis one-active-agent rule if unmodified. Independent code review, build reproduction and deployment audit were not performed.
