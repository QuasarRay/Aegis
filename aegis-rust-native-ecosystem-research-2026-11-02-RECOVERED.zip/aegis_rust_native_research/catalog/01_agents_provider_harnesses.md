# 01 Agents Provider Harnesses

**Entries:** 15. Stars sorted descending where verified. No project is asserted to be independently audited as production ready.

| project | stars | primary_language | rust_purity | readiness | strongest_niche |
|---|---|---|---|---|---|
| openai/codex | 132800 | Rust | Rust-primary (not audited pure Rust) | Established component; production assessment scoped to niche | Hosted-model coding agent and Rust CLI |
| sigoden/aichat | 10534 | Rust | Rust-primary (not audited pure Rust) | Exploratory / partial / insufficient independent deployment evidence | Mature CLI AI agent and RAG |
| 0xPlaygrounds/rig | 9040 | Rust | Rust-primary (not audited pure Rust) | Maintained/viable candidate; pilot before critical path | Modular Rust LLM SDK and Bevy plugin coding agent |
| jeremychone/rust-genai | 923 | Rust | Rust-primary (not audited pure Rust) | Maintained/viable candidate; pilot before critical path | Model/provider abstraction |
| bosun-ai/swiftide | 801 | Rust | Rust-primary (not audited pure Rust) | Maintained/viable candidate; pilot before critical path | RAG/agent pipelines, ingestion and retrieval |
| liquidos-ai/AutoAgents | 772 | Rust | Rust-primary (not audited pure Rust) | Exploratory / partial / insufficient independent deployment evidence | Native agent framework and orchestration |
| zavora-ai/adk-rust | 737 | Rust | Rust-primary (not audited pure Rust) | Maintained/viable candidate; pilot before critical path | Full-featured modular agent framework |
| ldclabs/anda | 447 | Rust | Rust-primary (not audited pure Rust) | Exploratory / partial / insufficient independent deployment evidence | Composable Rust agent runtime |
| Muvon/octolib | 9 | Rust | Rust-primary (not audited pure Rust) | Exploratory / partial / insufficient independent deployment evidence | Multi-provider Rust client/cost accounting |
| getlatentic/agent-harness | 2 | Rust | Rust-primary (not audited pure Rust) | Exploratory / partial / insufficient independent deployment evidence | Common Rust adapter for existing CLI agents |
| CHKDSKLabs/Mutagen | 0 | Rust | Rust-primary (not audited pure Rust) | Exploratory / partial / insufficient independent deployment evidence | Rust governing harness for coding agents |
| AstraBert/microagents | N/V | not checked | Rust claimed / not independently confirmed | Exploratory / partial / insufficient independent deployment evidence | Agent core and skill-loading crates |
| Dicklesworthstone/pi_agent_rust | N/V | not checked | Rust claimed / not independently confirmed | Exploratory / partial / insufficient independent deployment evidence | Rust coding agent with context compaction |
| avala-ai/agent-code | N/V | not checked | Rust claimed / not independently confirmed | Exploratory / partial / insufficient independent deployment evidence | Native terminal coding agent |
| contextbridge/aether | N/V | not checked | Rust claimed / not independently confirmed | Exploratory / partial / insufficient independent deployment evidence | Rust coding harness with explicit context control |

### [openai/codex](https://github.com/openai/codex)

**Best niche:** Hosted-model coding agent and Rust CLI. **Aegis disposition:** P0; keep Codex as executor.

**Evidence:** 132800 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-02; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Established component; production assessment scoped to niche. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Rust CLI does not imply access to hosted model weights or private internals. Independent code review, build reproduction and deployment audit were not performed.

### [sigoden/aichat](https://github.com/sigoden/aichat)

**Best niche:** Mature CLI AI agent and RAG. **Aegis disposition:** P2; reference implementation.

**Evidence:** 10534 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-02-23; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Consumer CLI is not a formal governance system. Independent code review, build reproduction and deployment audit were not performed.

### [0xPlaygrounds/rig](https://github.com/0xPlaygrounds/rig)

**Best niche:** Modular Rust LLM SDK and Bevy plugin coding agent. **Aegis disposition:** P1; modular experiment.

**Evidence:** 9040 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-02; license MIT. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Maintained/viable candidate; pilot before critical path. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Inspect actual harness API and agent/plugin stability. Independent code review, build reproduction and deployment audit were not performed.

### [jeremychone/rust-genai](https://github.com/jeremychone/rust-genai)

**Best niche:** Model/provider abstraction. **Aegis disposition:** P0; candidate for provider adapter.

**Evidence:** 923 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-02; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Maintained/viable candidate; pilot before critical path. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Provider API capabilities and reasoning controls require per-model feature checks. Independent code review, build reproduction and deployment audit were not performed.

### [bosun-ai/swiftide](https://github.com/bosun-ai/swiftide)

**Best niche:** RAG/agent pipelines, ingestion and retrieval. **Aegis disposition:** P1; compare against Rig.

**Evidence:** 801 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-30; license MIT. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Maintained/viable candidate; pilot before critical path. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** LLM pipelines are not an automatic parity-preserving migration. Independent code review, build reproduction and deployment audit were not performed.

### [liquidos-ai/AutoAgents](https://github.com/liquidos-ai/AutoAgents)

**Best niche:** Native agent framework and orchestration. **Aegis disposition:** P2; evaluation only.

**Evidence:** 772 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-18; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Aegis must prohibit parallel agents despite framework options. Independent code review, build reproduction and deployment audit were not performed.

### [zavora-ai/adk-rust](https://github.com/zavora-ai/adk-rust)

**Best niche:** Full-featured modular agent framework. **Aegis disposition:** P1; later controlled pilot.

**Evidence:** 737 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-01; license not automatically classified. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Maintained/viable candidate; pilot before critical path. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Many published crates, but readiness claims require independent testing. Independent code review, build reproduction and deployment audit were not performed.

### [ldclabs/anda](https://github.com/ldclabs/anda)

**Best niche:** Composable Rust agent runtime. **Aegis disposition:** P2; evaluation only.

**Evidence:** 447 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-20; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Inspect state persistence and tool authorization. Independent code review, build reproduction and deployment audit were not performed.

### [Muvon/octolib](https://github.com/Muvon/octolib)

**Best niche:** Multi-provider Rust client/cost accounting. **Aegis disposition:** P2; compare adapter options.

**Evidence:** 9 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-02; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Low adoption; validate feature completeness. Independent code review, build reproduction and deployment audit were not performed.

### [getlatentic/agent-harness](https://github.com/getlatentic/agent-harness)

**Best niche:** Common Rust adapter for existing CLI agents. **Aegis disposition:** P2; small prototype.

**Evidence:** 2 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-09-06; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Not independently demonstrated production readiness. Independent code review, build reproduction and deployment audit were not performed.

### [CHKDSKLabs/Mutagen](https://github.com/CHKDSKLabs/Mutagen)

**Best niche:** Rust governing harness for coding agents. **Aegis disposition:** P2; architecture reference.

**Evidence:** 0 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-06-22; license MIT. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Small/recent project; avoid critical-path adoption without evidence. Independent code review, build reproduction and deployment audit were not performed.

### [AstraBert/microagents](https://github.com/AstraBert/microagents)

**Best niche:** Agent core and skill-loading crates. **Aegis disposition:** Research only.

**Evidence:** stars not verified stars (not verified); primary language not checked; last pushed not checked; license not checked. **Purity:** Rust claimed / not independently confirmed. **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Verify API maturity and maintenance. Independent code review, build reproduction and deployment audit were not performed.

### [Dicklesworthstone/pi_agent_rust](https://github.com/Dicklesworthstone/pi_agent_rust)

**Best niche:** Rust coding agent with context compaction. **Aegis disposition:** P2; context study.

**Evidence:** stars not verified stars (not verified); primary language not checked; last pushed not checked; license not checked. **Purity:** Rust claimed / not independently confirmed. **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Compaction is lossy; cannot replace authoritative source corpus. Independent code review, build reproduction and deployment audit were not performed.

### [avala-ai/agent-code](https://github.com/avala-ai/agent-code)

**Best niche:** Native terminal coding agent. **Aegis disposition:** P2; harness candidate.

**Evidence:** stars not verified stars (not verified); primary language not checked; last pushed not checked; license not checked. **Purity:** Rust claimed / not independently confirmed. **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Check active support and Codex/ACP semantics. Independent code review, build reproduction and deployment audit were not performed.

### [contextbridge/aether](https://github.com/contextbridge/aether)

**Best niche:** Rust coding harness with explicit context control. **Aegis disposition:** P2; context study.

**Evidence:** stars not verified stars (not verified); primary language not checked; last pushed not checked; license not checked. **Purity:** Rust claimed / not independently confirmed. **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Verify actual releases, permissions and escape hatches. Independent code review, build reproduction and deployment audit were not performed.
