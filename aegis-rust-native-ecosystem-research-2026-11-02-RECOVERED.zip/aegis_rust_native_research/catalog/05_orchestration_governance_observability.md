# 05 Orchestration Governance Observability

**Entries:** 17. Stars sorted descending where verified. No project is asserted to be independently audited as production ready.

| project | stars | primary_language | rust_purity | readiness | strongest_niche |
|---|---|---|---|---|---|
| tokio-rs/tokio | 33562 | Rust | Rust-primary (not audited pure Rust) | Established component; production assessment scoped to niche | Async runtime |
| tokio-rs/axum | 27681 | Rust | Rust-primary (not audited pure Rust) | Established component; production assessment scoped to niche | Rust HTTP API framework |
| wasmerio/wasmer | 21217 | Rust | Rust-primary (not audited pure Rust) | Exploratory / partial / insufficient independent deployment evidence | Alternative Rust WebAssembly runtime |
| bytecodealliance/wasmtime | 18814 | Rust | Rust-primary (not audited pure Rust) | Established component; production assessment scoped to niche | Rust WebAssembly sandbox/runtime |
| windmill-labs/windmill | 18357 | Rust | Rust-facing / hybrid (not strict Rust-only) | Exploratory / partial / insufficient independent deployment evidence | Workflow automation platform |
| tokio-rs/tracing | 6949 | Rust | Rust-primary (not audited pure Rust) | Established component; production assessment scoped to niche | Structured trace instrumentation |
| restatedev/restate | 4642 | Rust | Rust-primary (not audited pure Rust) | Established component; production assessment scoped to niche | Durable Rust-backed execution and service orchestration |
| nextest-rs/nextest | 3380 | Rust | Rust-primary (not audited pure Rust) | Established component; production assessment scoped to niche | Efficient Rust test orchestration |
| open-telemetry/opentelemetry-rust | 2757 | Rust | Rust-primary (not audited pure Rust) | Established component; production assessment scoped to niche | Tracing/metric telemetry SDK |
| EmbarkStudios/cargo-deny | 2476 | Rust | Rust-primary (not audited pure Rust) | Established component; production assessment scoped to niche | Rust dependency/license/advisory policy checks |
| rustsec/rustsec | 1979 | Rust | Rust-primary (not audited pure Rust) | Exploratory / partial / insufficient independent deployment evidence | Rust security advisory tooling |
| cedar-policy/cedar | 1831 | Rust | Rust-primary (not audited pure Rust) | Established component; production assessment scoped to niche | Rust policy-as-code authorization engine |
| apalis-dev/apalis | 1490 | Rust | Rust-primary (not audited pure Rust) | Maintained/viable candidate; pilot before critical path | Rust background jobs and workers |
| mozilla/cargo-vet | 1005 | Rust | Rust-primary (not audited pure Rust) | Established component; production assessment scoped to niche | Dependency audit provenance and trust delegation |
| rust-secure-code/cargo-auditable | 873 | Rust | Rust-primary (not audited pure Rust) | Exploratory / partial / insufficient independent deployment evidence | Dependency information embedded in binaries |
| obeli-sk/obelisk | 766 | Rust | Rust-primary (not audited pure Rust) | Exploratory / partial / insufficient independent deployment evidence | Deterministic Rust durable workflow engine |
| microsoft/regorus | 366 | Rust | Rust-primary (not audited pure Rust) | Maintained/viable candidate; pilot before critical path | Rust Rego interpreter |

### [tokio-rs/tokio](https://github.com/tokio-rs/tokio)

**Best niche:** Async runtime. **Aegis disposition:** P1; when underlying libraries require it.

**Evidence:** 33562 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-31; license MIT. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Established component; production assessment scoped to niche. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Not a workflow engine; user prefers Monoio for runtime where feasible. Independent code review, build reproduction and deployment audit were not performed.

### [tokio-rs/axum](https://github.com/tokio-rs/axum)

**Best niche:** Rust HTTP API framework. **Aegis disposition:** P1; remote MCP endpoint.

**Evidence:** 27681 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-01; license MIT. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Established component; production assessment scoped to niche. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Can avoid HTTP entirely with local stdio MCP. Independent code review, build reproduction and deployment audit were not performed.

### [wasmerio/wasmer](https://github.com/wasmerio/wasmer)

**Best niche:** Alternative Rust WebAssembly runtime. **Aegis disposition:** P2; performance/policy comparison.

**Evidence:** 21217 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-01; license MIT. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Security properties depend on embedding permissions. Independent code review, build reproduction and deployment audit were not performed.

### [bytecodealliance/wasmtime](https://github.com/bytecodealliance/wasmtime)

**Best niche:** Rust WebAssembly sandbox/runtime. **Aegis disposition:** P1; constrain untrusted tool extensions.

**Evidence:** 18814 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-31; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Established component; production assessment scoped to niche. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** WASI capabilities must be narrowly granted; not arbitrary OS confinement. Independent code review, build reproduction and deployment audit were not performed.

### [windmill-labs/windmill](https://github.com/windmill-labs/windmill)

**Best niche:** Workflow automation platform. **Aegis disposition:** P2; ops/UI option.

**Evidence:** 18357 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-02; license not automatically classified. **Purity:** Rust-facing / hybrid (not strict Rust-only). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Mixed interface stack and server; not single-crate pure Rust. Independent code review, build reproduction and deployment audit were not performed.

### [tokio-rs/tracing](https://github.com/tokio-rs/tracing)

**Best niche:** Structured trace instrumentation. **Aegis disposition:** P0; step/evidence observability.

**Evidence:** 6949 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-29; license MIT. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Established component; production assessment scoped to niche. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Keep deterministic logs apart from free-form model reasoning. Independent code review, build reproduction and deployment audit were not performed.

### [restatedev/restate](https://github.com/restatedev/restate)

**Best niche:** Durable Rust-backed execution and service orchestration. **Aegis disposition:** P1; future durable work state.

**Evidence:** 4642 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-01; license not automatically classified. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Established component; production assessment scoped to niche. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Production system but distributed complexity exceeds minimal Aegis pilot. Independent code review, build reproduction and deployment audit were not performed.

### [nextest-rs/nextest](https://github.com/nextest-rs/nextest)

**Best niche:** Efficient Rust test orchestration. **Aegis disposition:** P1; run only after allowed tests/harnesses.

**Evidence:** 3380 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-01; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Established component; production assessment scoped to niche. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Does not license creation of unapproved new behavioral tests. Independent code review, build reproduction and deployment audit were not performed.

### [open-telemetry/opentelemetry-rust](https://github.com/open-telemetry/opentelemetry-rust)

**Best niche:** Tracing/metric telemetry SDK. **Aegis disposition:** P0; evidence pipeline.

**Evidence:** 2757 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-02; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Established component; production assessment scoped to niche. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Telemetry does not prove semantics on its own. Independent code review, build reproduction and deployment audit were not performed.

### [EmbarkStudios/cargo-deny](https://github.com/EmbarkStudios/cargo-deny)

**Best niche:** Rust dependency/license/advisory policy checks. **Aegis disposition:** P0; dependency governance.

**Evidence:** 2476 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-26; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Established component; production assessment scoped to niche. **Assurance:** Supply-chain/checking/verification evidence.

**Caveat:** Not full artifact attestation or runtime protection. Independent code review, build reproduction and deployment audit were not performed.

### [rustsec/rustsec](https://github.com/rustsec/rustsec)

**Best niche:** Rust security advisory tooling. **Aegis disposition:** P0; dependency advisory feed.

**Evidence:** 1979 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-29; license not automatically classified. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Supply-chain/checking/verification evidence.

**Caveat:** A clean advisory scan is not proof of safety. Independent code review, build reproduction and deployment audit were not performed.

### [cedar-policy/cedar](https://github.com/cedar-policy/cedar)

**Best niche:** Rust policy-as-code authorization engine. **Aegis disposition:** P0; tool permissions and resource policy.

**Evidence:** 1831 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-30; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Established component; production assessment scoped to niche. **Assurance:** Executable access-control policy.

**Caveat:** Policy decision must be mandatory on every sensitive call. Independent code review, build reproduction and deployment audit were not performed.

### [apalis-dev/apalis](https://github.com/apalis-dev/apalis)

**Best niche:** Rust background jobs and workers. **Aegis disposition:** P1; single-worker queue.

**Evidence:** 1490 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-02; license MIT. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Maintained/viable candidate; pilot before critical path. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Constrain globally to one active agent including across restarts. Independent code review, build reproduction and deployment audit were not performed.

### [mozilla/cargo-vet](https://github.com/mozilla/cargo-vet)

**Best niche:** Dependency audit provenance and trust delegation. **Aegis disposition:** P0; dependency review.

**Evidence:** 1005 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-22; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Established component; production assessment scoped to niche. **Assurance:** Supply-chain/checking/verification evidence.

**Caveat:** Requires trustworthy imported audits and policy. Independent code review, build reproduction and deployment audit were not performed.

### [rust-secure-code/cargo-auditable](https://github.com/rust-secure-code/cargo-auditable)

**Best niche:** Dependency information embedded in binaries. **Aegis disposition:** P1; post-build traceability.

**Evidence:** 873 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-21; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Provenance alone does not guarantee safe dependencies. Independent code review, build reproduction and deployment audit were not performed.

### [obeli-sk/obelisk](https://github.com/obeli-sk/obelisk)

**Best niche:** Deterministic Rust durable workflow engine. **Aegis disposition:** P2; experimental sequential workflow.

**Evidence:** 766 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-01; license AGPL-3.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** AGPL license and operational maturity need review. Independent code review, build reproduction and deployment audit were not performed.

### [microsoft/regorus](https://github.com/microsoft/regorus)

**Best niche:** Rust Rego interpreter. **Aegis disposition:** P1; compatibility alternative.

**Evidence:** 366 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-30; license not automatically classified. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Maintained/viable candidate; pilot before critical path. **Assurance:** Executable access-control policy.

**Caveat:** Rego/OPA policy parity must be tested for used syntax. Independent code review, build reproduction and deployment audit were not performed.
