# 04 Document Parsing Inference

**Entries:** 14. Stars sorted descending where verified. No project is asserted to be independently audited as production ready.

| project | stars | primary_language | rust_purity | readiness | strongest_niche |
|---|---|---|---|---|---|
| typst/typst | 56942 | Rust | Rust-primary (not audited pure Rust) | Established component; production assessment scoped to niche | Typesetting/document generation in Rust |
| rust-lang/mdBook | 22258 | Rust | Rust-primary (not audited pure Rust) | Established component; production assessment scoped to niche | Rust book documentation builder |
| huggingface/candle | 21265 | Rust | Rust-primary (not audited pure Rust) | Maintained/viable candidate; pilot before critical path | Rust machine learning framework |
| tracel-ai/burn | 16211 | Rust | Rust-primary (not audited pure Rust) | Maintained/viable candidate; pilot before critical path | Rust neural network framework |
| EricLBuehler/mistral.rs | 7791 | Rust | Rust-primary (not audited pure Rust) | Maintained/viable candidate; pilot before critical path | Rust local model inference/serving |
| pulldown-cmark/pulldown-cmark | 2755 | Rust | Rust-primary (not audited pure Rust) | Established component; production assessment scoped to niche | CommonMark parser |
| pykeio/ort | 2603 | Rust | Rust-facing / hybrid (not strict Rust-only) | Exploratory / partial / insufficient independent deployment evidence | Rust bindings to ONNX Runtime |
| J-F-Liu/lopdf | 2289 | Rust | Rust-primary (not audited pure Rust) | Established component; production assessment scoped to niche | PDF parser and writer library |
| kivikakk/comrak | 1731 | Rust | Rust-primary (not audited pure Rust) | Maintained/viable candidate; pilot before critical path | CommonMark/GFM parser and renderer |
| jrmuizel/pdf-extract | 606 | Rust | Rust-primary (not audited pure Rust) | Exploratory / partial / insufficient independent deployment evidence | PDF text extraction |
| raphaelmansuy/edgeparse | 154 | Rust | Rust-primary (not audited pure Rust) | Exploratory / partial / insufficient independent deployment evidence | Deterministic born-digital PDF parsing |
| carles-abarca/docling-rs | 9 | Rust | Rust-primary (not audited pure Rust) | Exploratory / partial / insufficient independent deployment evidence | Unofficial native-Rust Docling port |
| yzlabai/docparse-rs | 8 | Rust | Rust-primary (not audited pure Rust) | Exploratory / partial / insufficient independent deployment evidence | Rust parser with source/bounding-box provenance |
| sonos/tract | N/V | not checked | Rust claimed / not independently confirmed | Exploratory / partial / insufficient independent deployment evidence | ONNX/inference engine Rust |

### [typst/typst](https://github.com/typst/typst)

**Best niche:** Typesetting/document generation in Rust. **Aegis disposition:** P1; render future docs.

**Evidence:** 56942 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-30; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Established component; production assessment scoped to niche. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Not a native PDF-to-semantic-document reader. Independent code review, build reproduction and deployment audit were not performed.

### [rust-lang/mdBook](https://github.com/rust-lang/mdBook)

**Best niche:** Rust book documentation builder. **Aegis disposition:** P1; docs publisher.

**Evidence:** 22258 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-01; license MPL-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Established component; production assessment scoped to niche. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Not a content ingestion or vector retrieval engine. Independent code review, build reproduction and deployment audit were not performed.

### [huggingface/candle](https://github.com/huggingface/candle)

**Best niche:** Rust machine learning framework. **Aegis disposition:** P2; local embeddings/inference.

**Evidence:** 21265 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-01; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Maintained/viable candidate; pilot before critical path. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Does not extend closed Codex internal attention layers. Independent code review, build reproduction and deployment audit were not performed.

### [tracel-ai/burn](https://github.com/tracel-ai/burn)

**Best niche:** Rust neural network framework. **Aegis disposition:** P2; custom model research.

**Evidence:** 16211 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-01; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Maintained/viable candidate; pilot before critical path. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Not needed for day-one Aegis skill retrieval. Independent code review, build reproduction and deployment audit were not performed.

### [EricLBuehler/mistral.rs](https://github.com/EricLBuehler/mistral.rs)

**Best niche:** Rust local model inference/serving. **Aegis disposition:** P2; optional local model.

**Evidence:** 7791 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-02; license MIT. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Maintained/viable candidate; pilot before critical path. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** VRAM and accuracy constraints, model licensing. Independent code review, build reproduction and deployment audit were not performed.

### [pulldown-cmark/pulldown-cmark](https://github.com/pulldown-cmark/pulldown-cmark)

**Best niche:** CommonMark parser. **Aegis disposition:** P0; source-preserving Markdown pipelines.

**Evidence:** 2755 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-30; license MIT. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Established component; production assessment scoped to niche. **Assurance:** Deterministic/parser/system checks; no full migration assurance.

**Caveat:** Markdown grammar does not encode all PDF structure. Independent code review, build reproduction and deployment audit were not performed.

### [pykeio/ort](https://github.com/pykeio/ort)

**Best niche:** Rust bindings to ONNX Runtime. **Aegis disposition:** Hybrid; not pure Rust inference.

**Evidence:** 2603 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-01; license Apache-2.0. **Purity:** Rust-facing / hybrid (not strict Rust-only). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Core inference engine is external native runtime. Independent code review, build reproduction and deployment audit were not performed.

### [J-F-Liu/lopdf](https://github.com/J-F-Liu/lopdf)

**Best niche:** PDF parser and writer library. **Aegis disposition:** P0; build low-level extraction.

**Evidence:** 2289 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-02; license MIT. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Established component; production assessment scoped to niche. **Assurance:** Deterministic/parser/system checks; no full migration assurance.

**Caveat:** No automatic high-quality reading-order/layout guarantee. Independent code review, build reproduction and deployment audit were not performed.

### [kivikakk/comrak](https://github.com/kivikakk/comrak)

**Best niche:** CommonMark/GFM parser and renderer. **Aegis disposition:** P0; skill/book transformation.

**Evidence:** 1731 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-11-02; license not automatically classified. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Maintained/viable candidate; pilot before critical path. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Treat generated Markdown as a derived view, not lossless book. Independent code review, build reproduction and deployment audit were not performed.

### [jrmuizel/pdf-extract](https://github.com/jrmuizel/pdf-extract)

**Best niche:** PDF text extraction. **Aegis disposition:** P1; simple text fallback.

**Evidence:** 606 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-09-16; license not checked. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** May lose layout/equation semantics; preserve originals. Independent code review, build reproduction and deployment audit were not performed.

### [raphaelmansuy/edgeparse](https://github.com/raphaelmansuy/edgeparse)

**Best niche:** Deterministic born-digital PDF parsing. **Aegis disposition:** P2; compare PDF accuracy.

**Evidence:** 154 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-09; license not automatically classified. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Benchmark self-report must be tested on Aegis books. Independent code review, build reproduction and deployment audit were not performed.

### [carles-abarca/docling-rs](https://github.com/carles-abarca/docling-rs)

**Best niche:** Unofficial native-Rust Docling port. **Aegis disposition:** Research only.

**Evidence:** 9 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-10-05; license not checked. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Not feature-equivalent to mature IBM Docling without fidelity tests. Independent code review, build reproduction and deployment audit were not performed.

### [yzlabai/docparse-rs](https://github.com/yzlabai/docparse-rs)

**Best niche:** Rust parser with source/bounding-box provenance. **Aegis disposition:** P2; evaluate parser against PDFs.

**Evidence:** 8 stars (GitHub REST API / 2026-11-02); primary language Rust; last pushed 2026-07-29; license Apache-2.0. **Purity:** Rust-primary (not audited pure Rust). **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Low adoption: self-reported claims are not independent benchmark validation. Independent code review, build reproduction and deployment audit were not performed.

### [sonos/tract](https://github.com/sonos/tract)

**Best niche:** ONNX/inference engine Rust. **Aegis disposition:** P1; native inference candidate.

**Evidence:** stars not verified stars (not verified); primary language not checked; last pushed not checked; license not checked. **Purity:** Rust claimed / not independently confirmed. **Readiness:** Exploratory / partial / insufficient independent deployment evidence. **Assurance:** Operational capability; not independent correctness proof.

**Caveat:** Evaluate model operator coverage and quantization accuracy. Independent code review, build reproduction and deployment audit were not performed.
