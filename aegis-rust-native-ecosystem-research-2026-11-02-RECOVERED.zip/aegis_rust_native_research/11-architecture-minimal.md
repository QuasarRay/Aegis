# Architecture A: minimal safe-now Rust pilot

```text
Immutable original books, docs, test source, code snapshots
    | SHA-256 and version manifest
    v
Offline parser adapters (Rust-first; fall back only with disclosed fidelity results)
    | canonical section/bbox map + loss reports
    v
Tantivy full-text index + redb/SQLite durable evidence ledger
    | exact excerpt retrieval; bounded token budget
    v
Rust RMCP read-only MCP server
    | Cedar allow/deny + tool event logs
    v
Codex current Goal/Plan lifecycle, ONE ACTIVE AGENT
    | deterministic source-object + Rust-target inventory checks
    v
Original-test-derived Kani harnesses + receipts + existing CI
```

**No new model runtime; no custom attention; no distributed workflow engine.** Do not replace `.agents` governance payload or current Goal/Plan ABI until safe cutover tests pass. One read-only server is less likely than a new adaptive harness to disrupt source equivalence.

Core crates proposed: `aegis-corpus` (raw archive+hash), `aegis-index` (Tantivy+section registry), `aegis-mcp` (RMCP read-only tools), `aegis-policy` (Cedar), `aegis-evidence` (append-only receipts), `aegis-correspondence` (mapping/invariant validator), and a thin `aegis-codex-adapter` (do not claim unsupported private APIs).

Acceptance: identical book bytes before/after indexing; correct source cite on retrieval; no writes by knowledge MCP; one active owner even under crashed second process; stable exact object denominator; no new test-derived behavior invented; token/cost receipts; clean rollback by disabling MCP registration.
