# Primary sources and verification provenance

The original rust-specific Deep Research completion message is the starting point. It named 72 evaluated projects and a ZIP but exposed only a short narrative and some source links, not the 72 report records. This collection is a transparent substitute and uses further GitHub metadata checks. The prior non-Rust baseline ZIP was parsed from the user-provided attachment to inform category parity.

### High-priority primary-source docs

- https://github.com/openai/codex
- https://github.com/modelcontextprotocol/rust-sdk
- https://modelcontextprotocol.io/specification
- https://github.com/0xPlaygrounds/rig
- https://github.com/zavora-ai/adk-rust
- https://github.com/jeremychone/rust-genai
- https://github.com/qdrant/qdrant
- https://github.com/quickwit-oss/tantivy
- https://github.com/restatedev/restate
- https://github.com/cedar-policy/cedar
- https://github.com/model-checking/kani
- https://github.com/rust-lang/rust-analyzer
- https://github.com/ast-grep/ast-grep
- https://github.com/yzlabai/docparse-rs
- https://github.com/raphaelmansuy/edgeparse

### Repository URLs by category

#### 01_agents_provider_harnesses

- [openai/codex](https://github.com/openai/codex) — GitHub API inspected
- [sigoden/aichat](https://github.com/sigoden/aichat) — GitHub API inspected
- [0xPlaygrounds/rig](https://github.com/0xPlaygrounds/rig) — GitHub API inspected
- [jeremychone/rust-genai](https://github.com/jeremychone/rust-genai) — GitHub API inspected
- [bosun-ai/swiftide](https://github.com/bosun-ai/swiftide) — GitHub API inspected
- [liquidos-ai/AutoAgents](https://github.com/liquidos-ai/AutoAgents) — GitHub API inspected
- [zavora-ai/adk-rust](https://github.com/zavora-ai/adk-rust) — GitHub API inspected
- [ldclabs/anda](https://github.com/ldclabs/anda) — GitHub API inspected
- [Muvon/octolib](https://github.com/Muvon/octolib) — GitHub API inspected
- [getlatentic/agent-harness](https://github.com/getlatentic/agent-harness) — GitHub API inspected
- [CHKDSKLabs/Mutagen](https://github.com/CHKDSKLabs/Mutagen) — GitHub API inspected
- [AstraBert/microagents](https://github.com/AstraBert/microagents) — candidate; metadata not checked
- [Dicklesworthstone/pi_agent_rust](https://github.com/Dicklesworthstone/pi_agent_rust) — candidate; metadata not checked
- [avala-ai/agent-code](https://github.com/avala-ai/agent-code) — candidate; metadata not checked
- [contextbridge/aether](https://github.com/contextbridge/aether) — candidate; metadata not checked

#### 02_skills_mcp

- [modelcontextprotocol/rust-sdk](https://github.com/modelcontextprotocol/rust-sdk) — GitHub API inspected
- [leonardomso/rust-skills](https://github.com/leonardomso/rust-skills) — GitHub API inspected
- [rust-mcp-stack/rust-mcp-sdk](https://github.com/rust-mcp-stack/rust-mcp-sdk) — GitHub API inspected
- [MikkoParkkola/mcp-gateway](https://github.com/MikkoParkkola/mcp-gateway) — GitHub API inspected
- [Brainwires/project-rag](https://github.com/Brainwires/project-rag) — GitHub API inspected
- [joshrotenberg/mcp-proxy](https://github.com/joshrotenberg/mcp-proxy) — GitHub API inspected
- [Govcraft/agent-skills](https://github.com/Govcraft/agent-skills) — GitHub API inspected
- [cybershape/mcp-smart-proxy](https://github.com/cybershape/mcp-smart-proxy) — GitHub API inspected
- [agntcy/slim-mcp-rust](https://github.com/agntcy/slim-mcp-rust) — GitHub API inspected
- [skill-one/agents-skills](https://github.com/skill-one/agents-skills) — GitHub API inspected
- [yuunnn-w/Rust-Agent-MCP](https://github.com/yuunnn-w/Rust-Agent-MCP) — candidate; metadata not checked

#### 03_search_storage_rag_memory

- [meilisearch/meilisearch](https://github.com/meilisearch/meilisearch) — GitHub API inspected
- [qdrant/qdrant](https://github.com/qdrant/qdrant) — GitHub API inspected
- [surrealdb/surrealdb](https://github.com/surrealdb/surrealdb) — GitHub API inspected
- [chroma-core/chroma](https://github.com/chroma-core/chroma) — GitHub API inspected
- [quickwit-oss/tantivy](https://github.com/quickwit-oss/tantivy) — GitHub API inspected
- [lancedb/lancedb](https://github.com/lancedb/lancedb) — GitHub API inspected
- [quickwit-oss/quickwit](https://github.com/quickwit-oss/quickwit) — GitHub API inspected
- [huggingface/tokenizers](https://github.com/huggingface/tokenizers) — GitHub API inspected
- [cberner/redb](https://github.com/cberner/redb) — GitHub API inspected
- [unum-cloud/USearch](https://github.com/unum-cloud/USearch) — GitHub API inspected
- [fjall-rs/fjall](https://github.com/fjall-rs/fjall) — GitHub API inspected
- [Anush008/fastembed-rs](https://github.com/Anush008/fastembed-rs) — GitHub API inspected
- [asanabrial/leteo](https://github.com/asanabrial/leteo) — GitHub API inspected
- [taeyun16/aidememo](https://github.com/taeyun16/aidememo) — GitHub API inspected
- [ltsearch/LTSearch](https://github.com/ltsearch/LTSearch) — candidate; metadata not checked
- [vectorian-rs/qrst](https://github.com/vectorian-rs/qrst) — candidate; metadata not checked

#### 04_document_parsing_inference

- [typst/typst](https://github.com/typst/typst) — GitHub API inspected
- [rust-lang/mdBook](https://github.com/rust-lang/mdBook) — GitHub API inspected
- [huggingface/candle](https://github.com/huggingface/candle) — GitHub API inspected
- [tracel-ai/burn](https://github.com/tracel-ai/burn) — GitHub API inspected
- [EricLBuehler/mistral.rs](https://github.com/EricLBuehler/mistral.rs) — GitHub API inspected
- [pulldown-cmark/pulldown-cmark](https://github.com/pulldown-cmark/pulldown-cmark) — GitHub API inspected
- [pykeio/ort](https://github.com/pykeio/ort) — GitHub API inspected
- [J-F-Liu/lopdf](https://github.com/J-F-Liu/lopdf) — GitHub API inspected
- [kivikakk/comrak](https://github.com/kivikakk/comrak) — GitHub API inspected
- [jrmuizel/pdf-extract](https://github.com/jrmuizel/pdf-extract) — GitHub API inspected
- [raphaelmansuy/edgeparse](https://github.com/raphaelmansuy/edgeparse) — GitHub API inspected
- [carles-abarca/docling-rs](https://github.com/carles-abarca/docling-rs) — GitHub API inspected
- [yzlabai/docparse-rs](https://github.com/yzlabai/docparse-rs) — GitHub API inspected
- [sonos/tract](https://github.com/sonos/tract) — candidate; metadata not checked

#### 05_orchestration_governance_observability

- [tokio-rs/tokio](https://github.com/tokio-rs/tokio) — GitHub API inspected
- [tokio-rs/axum](https://github.com/tokio-rs/axum) — GitHub API inspected
- [wasmerio/wasmer](https://github.com/wasmerio/wasmer) — GitHub API inspected
- [bytecodealliance/wasmtime](https://github.com/bytecodealliance/wasmtime) — GitHub API inspected
- [windmill-labs/windmill](https://github.com/windmill-labs/windmill) — GitHub API inspected
- [tokio-rs/tracing](https://github.com/tokio-rs/tracing) — GitHub API inspected
- [restatedev/restate](https://github.com/restatedev/restate) — GitHub API inspected
- [nextest-rs/nextest](https://github.com/nextest-rs/nextest) — GitHub API inspected
- [open-telemetry/opentelemetry-rust](https://github.com/open-telemetry/opentelemetry-rust) — GitHub API inspected
- [EmbarkStudios/cargo-deny](https://github.com/EmbarkStudios/cargo-deny) — GitHub API inspected
- [rustsec/rustsec](https://github.com/rustsec/rustsec) — GitHub API inspected
- [cedar-policy/cedar](https://github.com/cedar-policy/cedar) — GitHub API inspected
- [apalis-dev/apalis](https://github.com/apalis-dev/apalis) — GitHub API inspected
- [mozilla/cargo-vet](https://github.com/mozilla/cargo-vet) — GitHub API inspected
- [rust-secure-code/cargo-auditable](https://github.com/rust-secure-code/cargo-auditable) — GitHub API inspected
- [obeli-sk/obelisk](https://github.com/obeli-sk/obelisk) — GitHub API inspected
- [microsoft/regorus](https://github.com/microsoft/regorus) — GitHub API inspected

#### 06_verification_one_to_one_migration

- [tree-sitter/tree-sitter](https://github.com/tree-sitter/tree-sitter) — GitHub API inspected
- [rust-lang/rust-analyzer](https://github.com/rust-lang/rust-analyzer) — GitHub API inspected
- [ast-grep/ast-grep](https://github.com/ast-grep/ast-grep) — GitHub API inspected
- [rust-lang/miri](https://github.com/rust-lang/miri) — GitHub API inspected
- [rust-lang/rust-bindgen](https://github.com/rust-lang/rust-bindgen) — GitHub API inspected
- [immunant/c2rust](https://github.com/immunant/c2rust) — GitHub API inspected
- [model-checking/kani](https://github.com/model-checking/kani) — GitHub API inspected
- [verus-lang/verus](https://github.com/verus-lang/verus) — GitHub API inspected
- [creusot-rs/creusot](https://github.com/creusot-rs/creusot) — GitHub API inspected
- [obi1kenobi/cargo-semver-checks](https://github.com/obi1kenobi/cargo-semver-checks) — GitHub API inspected
- [cargo-public-api/cargo-public-api](https://github.com/cargo-public-api/cargo-public-api) — GitHub API inspected
- [tree-sitter/tree-sitter-graph](https://github.com/tree-sitter/tree-sitter-graph) — GitHub API inspected
- [Cpp2Rust/cpp2rust](https://github.com/Cpp2Rust/cpp2rust) — GitHub API inspected
- [camshaft/bolero](https://github.com/camshaft/bolero) — GitHub API inspected
- [stakwork/stakgraph](https://github.com/stakwork/stakgraph) — GitHub API inspected
- [rust-lang/rustdoc-types](https://github.com/rust-lang/rustdoc-types) — GitHub API inspected
- [NodeDB-Lab/code2graph](https://github.com/NodeDB-Lab/code2graph) — GitHub API inspected
- [viperproject/prusti-dev](https://github.com/viperproject/prusti-dev) — candidate; metadata not checked

### Verification restrictions

GitHub primary-language and SPDX fields were retrieved from repository metadata where available. No full code reviews, builds or security audits were performed. Some repository license classifications are `NOASSERTION` in GitHub; inspect actual LICENSE files before deployment. Missing star counts are never assigned arbitrary values. Stable versions, benchmarks, cryptographic guarantees and production adoption are not independently confirmed simply from a README.
