# Cross-language ecosystem parity matrix

| incumbent | rust | parity | critical_gap |
|---|---|---|---|
| LangChain / LangGraph | Rig; ADK-Rust; Swiftide; Restate/Apalis | Scoped competitiveness | No complete parity claim for integrations, graph semantics or debugging tools |
| Haystack / LlamaIndex | Swiftide + Tantivy/Qdrant + rmcp | Composition, partial | No proof of complete ingestion/evaluator/reranker/agent ecosystem |
| RAGFlow | Docparse-rs/EdgeParse + Qdrant/Tantivy + skills | Partial; not turnkey | Knowledge-compilation, human-in-loop and UI may need building |
| Letta / Letta Code | Rig/agent-code + redb + structured memory | Partial | Durable semantic memory, context editing and governance need design |
| Docling / Marker / MinerU | docparse-rs; edgeparse; lopdf | Partial, empirical | Complex layout/scan/figure benchmarks still required |
| Unstructured / Apache Tika | docparse-rs; lopdf; comrak | Partial | Not complete same-format/document fidelity |
| MCP SDK Python/TS | Official rmcp Rust SDK | Strong scoped parity | Protocol version and transport compatibility must be pinned |
| MCP proxy/gateway platforms | mcp-gateway; mcp-proxy; mcp-smart-proxy | Scoped competition | Per-tool auth, identity delegation and audit require proof |
| OPA/Rego | Regorus | Interpreter alternative | Rego compatibility for used semantics must be evaluated |
| Cedar | cedar-policy/cedar | Native reference implementation | Authorization only; no comprehensive prompt safety |
| Milvus / Weaviate / pgvector | Qdrant; LanceDB | Strong for vector retrieval | Architecture and database semantics differ |
| Elasticsearch/OpenSearch | Tantivy; Quickwit; Meilisearch | Strong for scoped search | Distributed operational semantics/features vary |
| Chroma | Qdrant; LanceDB | Viable service/embedded alternatives | Cross-language service ecosystems differ |
| Dify / Flowise / AutoGen / CrewAI | ADK-Rust; Rig + custom UI | Partial | No evidence of turnkey ecosystem breadth parity |
| Langfuse / Arize Phoenix / LangSmith | tracing + opentelemetry-rust | Instrumentation only | Need UI, eval, replay, scoring, analytics, storage |
| Ragas / DeepEval / Inspect AI | Kani + source-test gates + custom evals | Different purpose | Formal verification does not replace statistical LLM evaluations |
| Joern / CodeQL | rust-analyzer; AST-grep; tree-sitter-graph; source-specific compilers | Partial | Whole-program polyglot semantic graph not automatic |
| C2Rust / translation researchers | immunant/c2rust; Cpp2Rust/cpp2rust | Language-specific partial | Not C++/Go/Java/Python bidirectional semantic isomorphism |
| Temporal / durable worker systems | Restate; Obelisk; Apalis | Strong scoped alternatives | Enforce one active agent, idempotent side effects, ownership lock |
| Unlimiformer | Candle/Burn/mistral.rs research | Not equivalent | Closed hosted Codex attention inaccessible to external Rust harness |

"Parity" is feature-by-feature, not star-based. Hosted Codex APIs, consumer product UIs, or external inference are not made Rust-native by a Rust client.
