# Sequential orchestration, durable state and budget guarantees

All subagents are mutually exclusive. State machine: `Proposed -> SourceInventoried -> ContractMapped -> HarnessDerived -> Implemented -> DifferentiallyChecked -> Verified -> Reviewed -> Committed`, with a distinct `Blocked`/`Unknown` state. Each stage must emit receipts and be restart-safe.

**Restate** provides durable workflow and state primitives, **Apalis** offers queue-based processing, **Obelisk** provides deterministic workflow research. Aegis need not introduce a distributed service until a single-host SQLite/`redb` lock plus append-only ledger proves inadequate. A queue configured at concurrency=1 **still** requires a global owner lease and fencing token if multiple workers/hosts are possible.

Define a unique work identity `(source_revision, source_symbol_identity, target_profile, migration_policy_revision, harness_catalog_version)`. Before each agent call, consult evidence ledger and reject any already-complete or in-flight work. The model receives only missing obligations and bounded source fragments, not the entire task history.

Do not confuse exactly-once request delivery with exactly-once effects. An external Git push, payment or file write requires idempotency keys and state reconciliation after crash. Cancellation must cleanly retire a lease before another subagent starts. The per-stage token budget is a hard allowance applied at API/tool boundaries where supported; unreported model usage is unknown rather than assumed zero.
