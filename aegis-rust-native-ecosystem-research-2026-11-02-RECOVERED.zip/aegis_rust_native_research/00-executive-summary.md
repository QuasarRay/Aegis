# Executive summary

## Finding

Rust provides credible production-grade components for **MCP** (`modelcontextprotocol/rust-sdk`), **keyword search** (`quickwit-oss/tantivy`), **vector retrieval** (`qdrant/qdrant`), **durable execution** (`restatedev/restate`), **authorization** (`cedar-policy/cedar`), **Rust code analysis** (`rust-lang/rust-analyzer`), and **bounded model checking** (`model-checking/kani`). Rust-first agent SDKs such as **Rig** and **ADK-Rust** are available and active; they require Aegis-specific acceptance tests rather than an assumption of LangGraph/Letta/Haystack feature parity.

This recovered catalog contains 91 unique repo references across six major groups and 82 checked GitHub star snapshots. It deliberately retains some **hybrid / non-Rust counterparts** to prevent false claims of a pure-Rust equivalent.

## Recommended architecture

For now: Codex remains the coding executor; a **read-only Rust MCP knowledge server** serves exact source-attributed book passages and agent skills from a versioned, hash-verified corpus. Pair `rmcp` with `tantivy` and a small SQLite or `redb` evidence ledger. Implement hard **single-active-agent** locking, scoped Cedar authorization, retry-safe work IDs, and deterministic target/source inventories. Allow Qdrant only if hybrid search demonstrably improves exact technical retrieval.

For later: add `restate` or `apalis` only if crash-resumable orchestration or persistent queues justify their complexity, add local embeddings through validated models, and introduce formal audit gates for canonical one-to-one object mapping.

## Areas without demonstrated full Rust parity

- IBM Docling/Marker/MinerU quality on complex PDFs, scan OCR, formulas, tables; native Rust parsers warrant empirical tests, not parity claims.
- Python LangGraph/Haystack/LlamaIndex breadth of integrations and ecosystem components; Rust libraries offer **scoped** capabilities.
- Letta-style durable reflective memory and RAGFlow end-to-end knowledge compilation at the same level of maturity; composed Rust components do not equal a turnkey platform.
- Joern/CodeQL depth of polyglot semantic resolution and whole-program queries. Tree-sitter/AST-grep alone are not semantic CPG substitutes.
- General automatic strict one-to-one C++/Go/Java/Python→Rust migration. None of the listed compilers proves the required bijection and behavior automatically.
- Proof that LLM-generated translations cannot be wrong; assurance comes from independently checkable constraints, source-derived tests, explicit incomplete coverage, and human signoff.

## Decision

**Do not replace Aegis's whole working Python harness with Rust or LangGraph at once.** Establish a constrained Rust service behind tested interfaces; accept it only after deterministic evidence demonstrates better reliability/cost without disrupting Blue or Destiny work.
